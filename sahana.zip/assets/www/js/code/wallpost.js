var Image_url_wallpost = "";
var userName_wallpost = "";
var device_Token = "";
var resellerInitial="";
var reseller='';
var flagforeditprofile=0;
var indexvalwall='';

var youhavebeenblocked_wallpost = 'You have been blocked';
var message_wallpost = 'Message';
var ok_wallpost = 'OK';
var namefieldcannotbeleftblank_wallpost = 'Name field cannot be left blank';
var uploadpic_wallpost = "Upload Pic";
var screenname_wallpost = "Screen Name";
var next_wallpost = "Next";
var enduserlicenseagreement_wallpost = "End User License Agreement";
var thisenduserlicenseagreement_wallpost = "This End User License Agreement ( Agreement ) is between you and "; 
var andgovernsuseof_wallpost = " and governs use of this app made available through the Apple App Store. By installing the ";
var apyouagree_wallpost = " App, you agree to be bound by this Agreement and understand that there is no tolerance for objectionable content. If you do not agree with the terms and conditions of this Agreement, you are not entitled to use the  ";  
var  appnordertoensure_wallpost = " App. <br><br> In order to ensure  "; 
var  providesthebestexperiencepossible_wallpost = " provides the best experience possible for everyone, we strongly enforce a no tolerance policy for objectionable content. If you see inappropriate content, please use the  Report as offensive  feature found under each post. <br><br> 1. Parties <br>This Agreement is between you and  ";  
var  onlandnopplenc_wallpost = " only, and not Apple, Inc. ( Apple ). Notwithstanding the foregoing, you acknowledge that Apple and its subsidiaries are third party beneficiaries of this Agreement and Apple has the right to enforce this Agreement against you.  "; 
var notappleis_wallpost = ", not Apple, is solely responsible for the  ";  
var  aappandits = " App and its content.<br><br> 2. Privacy <br> "; 
var  maycollectanduse_wallpost = " may collect and use information about your usage of the  "; 
var  appincludingcertaintypesof_wallpost = " App, including certain types of information from and about your device.  ";  
var  mayusethisinformationaslongas_wallpost = " may use this information, as long as it is in a form that does not personally identify you, to measure the use and performance of the  ";  
var  applimited = " App. <br><br> 3. Limited License <br> ";
var  grantsyoualimitednon = " grants you a limited, non-exclusive, non-transferable, revocable license to use the "; 
var  appyourpersonal_wallpost = " App for your personal, non-commercial purposes. You may only use the "; 
var  apponappledevices_wallpost = " App on Apple devices that you own or control and as permitted by the App Store Terms of Service. <br><br> 4. Age Restrictions <br>By using the  ";  
var  apprepresenwarrant_wallpost = " App, you represent and warrant that (a) you are 17 years of age or older and you agree to be bound by this Agreement; (b) if you are under 17 years of age, you have obtained verifiable consent from a parent or legal guardian; and (c) your use of the  ";  
var  apviolateapplicable_wallpost = " App does not violate any applicable law or regulation. Your access to the  ";  
var  appmaterminated_wallpost = " App may be terminated without warning if  ";  
var  believessole_wallpost = " believes, in its sole discretion, that you are under the age of 17 years and have not obtained verifiable consent from a parent or legal guardian. If you are a parent or legal guardian and you provide your consent to your child s use of the  ";  
var  youagreebound_wallpost = " App, you agree to be bound by this Agreement in respect to your child s use of the  ";  
var  objectionablecontentpolicy_wallpost = " App. <br><br> 5. Objectionable Content Policy <br> Content may not be submitted to  ";  
var whowillmoderateall_wallpost = ", who will moderate all content and ultimately decide whether or not to post a submission to the extent such content includes, is in conjunction with, or alongside any, Objectionable Content. Objectionable Content includes, but is not limited to: (i) sexually explicit materials; (ii) obscene, defamatory, libelous, slanderous, violent and/or unlawful content or profanity; (iii) content that infringes upon the rights of any third party, including copyright, trademark, privacy, publicity or other personal or proprietary right, or that is deceptive or fraudulent; (iv) content that promotes the use or sale of illegal or regulated substances, tobacco products, ammunition and/or firearms; and (v) gambling, including without limitation, any online casino, sports books, bingo or poker. <br><br> 6. Warranty <br> "; 
var  disclaimsallwarranties_walpost = " disclaims all warranties about the  ";  
var  fullestextentpermitted_wallpost = " App to the fullest extent permitted by law. To the extent any warranty exists under law that cannot be disclaimed,  ";  
var notappleshall_wallpost = ", not Apple, shall be solely responsible for such warranty. <br><br> 7. Maintenance and Support <br> "; 
var  doesprovideminimalmaintenance_wallpost = " does provide minimal maintenance or support for it but not to the extent that any maintenance or support is required by applicable law,  ";  
var appleshallobligatedfurnish_wallpost = ", not Apple, shall be obligated to furnish any such maintenance or support. <br><br> 8. Product Claims <br> "; 
var responsibladdressing_walpost = ", not Apple, is responsible for addressing any claims by you relating to the  " ; 
var includinglimited_wallpost = " App or use of it, including, but not limited to: (i) any product liability claim; (ii) any claim that the  ";  
var  failsapplicable_wallpost = " App fails to conform to any applicable legal or regulatory requirement; and (iii) any claim arising under consumer protection or similar legislation. Nothing in this Agreement shall be deemed an admission that you may have such claims. <br><br> 9. Third Party Intellectual Property Claims <br> "; 
var  shallobligatedindemnifydefend_wallpost = " shall not be obligated to indemnify or defend you with respect to any third party claim arising out or relating to the  ";  
var  theextent_wallpost = " App. To the extent  ";  
var  isprovideindemnification_wallpost = " is required to provide indemnification by applicable law,  ";  
var solelyinvestigation_wallpost = ", not Apple, shall be solely responsible for the investigation, defense, settlement and discharge of any claim that the  ";  
var useinfringe_wallpost = " App or your use of it infringes any third party intellectual property right.";
var aaccept_walpost = "Accept";
var ddecline_wallpost = "Decline";

var namefieldcannot_wallpost = ' Name field cannot be left blank';
var alert_wallpost = 'Alert';
var selectimagetoupload_wallpost = ' Select image to upload';
var selecupload_wallpost = 'Select from where you want to upload';
var loadmore_wallpost = 'Load More Post'; 
var updatestatus_walpost = 'Update Status';
var addphotovideo_wallpost = 'Add Photo/Video';
var saysomething_wallpost = 'Say something about this video';
var saysomethingimage_wallpost = 'Say something about this photo';
var post_wallpost = 'Post';
var uploadimage_wallpoast = 'Upload Image';
var uploadvideo_wallpost = 'Upload Video';
var showmore_wallpost = 'Show more';
var postedvideo_walpost = 'posted a new video';
var llike_wallpost = ' Like';
var rreportabuse_wallpost = ' Report Abuse';
var comment_walpost = ' Comment';
var viewall_wallpost = 'View All';
var postedphoto_wallpost = ' posted a new photo';
var postedstatus_wallpost = ' posted a new status';
var loadmorepost_wallpost = 'Load More Post';
var messagegg_walpost='Plese enter comment!';
var peoplelikegg_wallpost = 'People Who Like This';
var messagefff_wallpost = 'Please add text to upload!';
var messagesome_wallpost = 'Some Error try again!';
var warning_wallpost = 'Warning';

function getWallPost(index)
{
if(localStorage.getItem("appLanguageCheck") == "sa")
   {
      arabic();
   }
    checkupdateflag=1;
   // var xmldata=$.parseXML(window.localStorage.getItem("xml"));
    //console.log("XMLPRINT : " + localStorage.getItem("xml"));
    sessionStorage.setItem("indexValue",index);
    var html="";
    
    console.log("index--->"+index);
    $socialwallData=$(masterData).find("socialwall[indexval="+index+"]");
    console.log(" in loop condition nishant ---->");
   
   
    
    indexvalwall= $socialwallData.find("socialPageId").text();
                                       
    console.log(" in if condition indexValWall ---->"+indexvalwall);
   
    console.log("indexValWall ---->"+indexvalwall);
    if(!checkNetworkConnection())
    {
                $('.appypie-loader').hide();
    }
    else
    {
    reseller=window.localStorage.getItem("reseller");
       
     $('.appypie-loader').show();
        
    //window.location = "devicetoken:" + index;
    //devicetokenwall('123435467');
   // sessionStorage.setItem("indexValue", index);
        
        
               devicetokenwall(localStorage.getItem("deviceUUID"));
    }
}

function devicetokenwall(UUID) {
	
    if(UUID=="")
    {
        getWallPost(sessionStorage.getItem("indexValue"));
    }
    else
    {
        setTimeout(function(){
                   window.location = "iad:"+"hide";
                   //adsHideValue=1;
                   },1000);
    device_Token = UUID;
    localStorage.setItem("local_imageURI_wallpost", "");
    localStorage.setItem("Image_selection", "");
    if (localStorage.getItem(indexvalwall)) {
         $('.appypie-loader').hide();
        var wsUrll = "http://"+resellerInitial+reseller+"/services/socialwall-soap#getUser";
        var soapRequestt = '<?xml version="1.0" encoding="utf-8"?> <soap:Envelope xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"  xmlns:xsd="http://www.w3.org/2001/XMLSchema" xmlns:soap="http://schemas.xmlsoap.org/soap/envelope/"> <soap:Body><getUser xmlns=\"http://'+resellerInitial+reseller+'/services/socialwall-soap#getUser\"><appId>' + localStorage.getItem('applicationID') + '</appId><pageId>' + indexvalwall + '</pageId><deviceId>' + UUID + '</deviceId></getUser></soap:Body></soap:Envelope>';
        console.log("SoapRequest : " + soapRequestt);
        $.ajax({
               type: "POST",
               url: wsUrll,
               contentType: "text/xml",
               dataType: "text",
               data: soapRequestt,
               success: function(data, status, req) {
               var strJSON = $(req.responseText).find("return").text();
               console.log("success setting gaurav : " + strJSON);
               strJSON = JSON.parse(strJSON);
               if (strJSON.response.msg) {
               if(strJSON.response.msg=="Blocked User")
               {
               navigator.notification.alert(
            		   youhavebeenblocked_wallpost +'!',
                                            alertDismissed,
                                            message_wallpost,
                                            ok_wallpost
                                            );
               }
               else {
               openWall(true);
               }
               
               } else {
               Image_url_wallpost = strJSON.response.image;
               openWall(true);
               }
               },
               error: function(response, textStatus, errorThrown) {
               console.log("Error : " + JSON.stringify(response));
               console.log("Error : " + textStatus);
               console.log("Error : " + errorThrown.responseText);
               }
               });
        
    } else {
        var wsUrll = "http://"+resellerInitial+reseller+"/services/socialwall-soap#getUser";
        var soapRequestt = '<?xml version="1.0" encoding="utf-8"?> <soap:Envelope xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"  xmlns:xsd="http://www.w3.org/2001/XMLSchema" xmlns:soap="http://schemas.xmlsoap.org/soap/envelope/"> <soap:Body><getUser xmlns=\"http://'+resellerInitial+reseller+'/services/socialwall-soap#getUser\"><appId>' + localStorage.getItem('applicationID') + '</appId><pageId>' + indexvalwall + '</pageId><deviceId>' + UUID + '</deviceId></getUser></soap:Body></soap:Envelope>';
        console.log("SoapRequest : " + soapRequestt);
        $.ajax({
               type: "POST",
               url: wsUrll,
               contentType: "text/xml",
               dataType: "text",
               data: soapRequestt,
               success: function(data, status, req) {
               var strJSON = $(req.responseText).find("return").text();
               console.log("success setting gaurav : " + strJSON);
               strJSON = JSON.parse(strJSON);
               if (strJSON.response.msg) {
               if(strJSON.response.msg=="Blocked User")
               {
            	   navigator.notification.alert(
                		   youhavebeenblocked_wallpost +'!',
                                                alertDismissed,
                                                message_wallpost,
                                                ok_wallpost
                                                );
               $('.appypie-loader').hide();
               }
               else {
               editProfilePicture_wallpost(false);
               }
               
               } else {
               
               Image_url_wallpost = strJSON.response.image;
               userName_wallpost = strJSON.response.name;
               editProfilePicture_wallpost(true);
               }
               },
               error: function(response, textStatus, errorThrown) {
               console.log("Error : " + JSON.stringify(response));
               console.log("Error : " + textStatus);
               console.log("Error : " + errorThrown.responseText);
               }
               });
    }
           }
}

function myFunctionblur(idusername)
{
	
    
    if (document.getElementById(idusername).value == '') {
        navigator.notification.alert(
        		namefieldcannotbeleftblank_wallpost,
                                     alertDismissed,
                                     message_wallpost,
                                     ok_wallpost
                                     );
        
    }
    
}

function editProfilePicture_wallpost(value) {
	
	
	
	
	if (window.localStorage.getItem("layout") == "bottom") {
        $(".app_navigation_bottom").show();
    }
   
    var appName = window.localStorage.getItem("AppName");
    var profile = '<div class="appypie-wall-update" id="appypie-chat-update"><div class="wall-pic" onclick="selectPhoto_wallpost();">'+uploadpic_wallpost+'</div><div class="chat-pic-1" onclick="selectPhoto_wallpost();" style="display:none"><img id="set_Wall_pic"></div><input id="userName_wallpost" onblur="myFunctionblur(this.id)" data-role="none" type="text" placeholder="'+screenname_wallpost+'"><a onClick="updateInfo_wallpost();" '+primaryColor+'>'+next_wallpost+'</a></div><div id="light" class="white_content"> <h4 class="license-ttle">'+enduserlicenseagreement_wallpost+'</h4><div class="license-wrapper"><p align="justify">'+thisenduserlicenseagreement_wallpost+appName+ andgovernsuseof_wallpost+appName+apyouagree_wallpost +appName+appnordertoensure_wallpost+appName+providesthebestexperiencepossible_wallpost+appName+onlandnopplenc_wallpost+appName+notappleis_wallpost+appName+aappandits+appName+maycollectanduse_wallpost+appName+appincludingcertaintypesof_wallpost+appName+mayusethisinformationaslongas_wallpost+appName+applimited+appName+grantsyoualimitednon+appName+appyourpersonal_wallpost+appName+apponappledevices_wallpost+appName+apprepresenwarrant_wallpost+appName+apviolateapplicable_wallpost+appName+appmaterminated_wallpost+appName+believessole_wallpost+appName+youagreebound_wallpost+appName+objectionablecontentpolicy_wallpost+appName+whowillmoderateall_wallpost+appName+disclaimsallwarranties_walpost+appName+fullestextentpermitted_wallpost+appName+notappleshall_wallpost+appName+doesprovideminimalmaintenance_wallpost+appName+appleshallobligatedfurnish_wallpost+appName+responsibladdressing_walpost+appName+includinglimited_wallpost+appName+failsapplicable_wallpost+appName+shallobligatedindemnifydefend_wallpost+appName+theextent_wallpost+appName+isprovideindemnification_wallpost+appName+solelyinvestigation_wallpost+appName+useinfringe_wallpost+'</p></div><div class="license-clsBtn"><a href="#" class="accept" onclick="AcceptLicence();">'+aaccept_walpost+'</a><a href = "javascript:void(0)"  class="decline" onclick="DeclineLicence();">'+ddecline_wallpost+'</a></div></div><div id="fade" class="black_overlay"></div>';
    if(flagforeditprofile==0)
    {
    $('#contentHolder17').css('background', '#edf0f5');
     appendHtml(profile,17,1);
    }
    else
    {
        flagforeditprofile=0;
        //localStorage.setItem(indexvalwall, "Done3");
        sessionStorage.setItem("wallpageback","true");
        $('#contentHolder18').css('background', '#edf0f5');
        appendHtml(profile,18,2);
    }
    
    if (value == true) {
        var randomnumber2 = Math.floor((Math.random() * 100) + 1);
        Image_url_wallpost=Image_url_wallpost+'?'+randomnumber2;
        document.getElementById("set_Wall_pic").src = Image_url_wallpost;
        //
        localStorage.setItem("Image_selection", "Done");
        $(".appypie-wall-update .wall-pic").hide();
        $(".appypie-wall-update .chat-pic-1").show();
        $('#userName_wallpost').val(userName_wallpost);
    }
}

function AcceptLicence()
{
    localStorage.setItem(indexvalwall, "Done1");
     localStorage.setItem("EulaAccept", "Done");
    openWall(true);
}

function DeclineLicence()
{
    document.getElementById('light').style.display='none';
    document.getElementById('fade').style.display='none';
}

function updateInfo_wallpost() {
   

	
	
    var usernametemp=$('#userName_wallpost').val();
    usernametemp = usernametemp.trim();
    if (usernametemp == '') {
        navigator.notification.alert(
        		namefieldcannot_wallpost,
                                     alertDismissed,
                                     alert_wallpost,
                                     ok_wallpost
                                     );
    } else if (localStorage.getItem("Image_selection") == "") {
        navigator.notification.alert(
        		selectimagetoupload_wallpost,
                                     alertDismissed,
                                     alert_wallpost,
                                     ok_wallpost
                                     );
    } else {
         $('.appypie-loader').show();
        
        var mediaFiles = localStorage.local_imageURI_wallpost;
        mediaFiles = mediaFiles.trim();
        if (typeof mediaFiles != 'undefined' && mediaFiles!="") {
            var username = usernametemp;
            var globalusername="globalusername"+indexvalwall;
            localStorage.setItem(globalusername, username);
            var fileName = '23456.jpg';
            var fileURI;
            fileURI = mediaFiles;
            var ft = new FileTransfer();
            var options = new FileUploadOptions();
            options.fileKey = "file";
            options.fileName = fileName;
            options.mimeType = "text/plain";
            var params = new Object();
            params.appId = localStorage.getItem('applicationID');
            params.deviceId = device_Token;
            params.pageId = indexvalwall;
            params.name = username;
            options.params = params;
            ft.upload(fileURI, encodeURI("http://"+resellerInitial+reseller+"/socialwall/set-user"), successFn_profile_WallPost, errorFn_profile_WallPost, options);
            
        }
        else
        {
            var username = usernametemp;
            var globalusername="globalusername"+indexvalwall;
            localStorage.setItem(globalusername, username);
            var wsUrll = "http://"+resellerInitial+reseller+"/services/socialwall-soap#setUser";
            var soapRequestt = '<?xml version="1.0" encoding="utf-8"?> <soap:Envelope xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"  xmlns:xsd="http://www.w3.org/2001/XMLSchema" xmlns:soap="http://schemas.xmlsoap.org/soap/envelope/"> <soap:Body><setUser xmlns=\"http://'+resellerInitial+reseller+'/socialwall-soap#setUser\"><appId>' + localStorage.getItem('applicationID') + '</appId><deviceId>' + device_Token + '</deviceId><image>' + mediaFiles + '</image><pageId>' + indexvalwall + '</pageId><name>' + username + '</name></setUser></soap:Body></soap:Envelope>';
            console.log("SoapRequest : " + soapRequestt);
            $.ajax({
                   type: "POST",
                   url: wsUrll,
                   contentType: "text/xml",
                   dataType: "text",
                   data: soapRequestt,
                   success: function(data, status, req) {
                   var strJSON = $(req.responseText).find("return").text();
                   console.log("success setting gaurav : " + strJSON);
                   
                   if (strJSON == "Updated") {
                   if(localStorage.getItem("EulaAccept"))
                   {
                   localStorage.setItem(indexvalwall, "Done2");
                   localStorage.setItem("EulaAccept", "Done");
                   openWall(true);
                   }
                   else
                   {
                   document.getElementById('light').style.display='block';
                   document.getElementById('fade').style.display='block';
                   }
                   
                   $('.appypie-loader').hide();
                   
                   }
                   },
                   error: function(response, textStatus, errorThrown) {
                   $('.appypie-loader').hide();
                   console.log("Error : " + JSON.stringify(response));
                   console.log("Error : " + textStatus);
                   console.log("Error : " + errorThrown.responseText);
                   }
                   });
        }
    }
}
function successFn_profile_WallPost(r)
{
    if (r.response == "Updated") {
        if(localStorage.getItem("EulaAccept"))
        {
            localStorage.setItem(indexvalwall, "Done2");
            localStorage.setItem("EulaAccept", "Done");
            openWall(true);
        }
        else
        {
            document.getElementById('light').style.display='block';
            document.getElementById('fade').style.display='block';
        }
        
        $('.appypie-loader').hide();
        
    }
}
function errorFn_profile_WallPost(error)
{
    $('.appypie-loader').hide();
    console.log("upload error source " + error.source);
    console.log("upload error target " + error.target);
}
function selectPhoto_wallpost() {
	
    navigator.notification.confirm(
    		selecupload_wallpost+'!', // message
                                   onConfirm2_wallpost, // callback to invoke with index of button pressed
                                   message_wallpost, // title
                                   'Camera,Gallery,Cancel'
                                   );
}

function onConfirm2_wallpost(buttonIndex) {
    if (buttonIndex == 2) {
        var options = {
        quality: 50,
        sourceType: Camera.PictureSourceType.PHOTOLIBRARY,
        destinationType: navigator.camera.DestinationType.FILE_URI,
        }
        navigator.camera.getPicture(win_image_lib_wallpost, fail_wallpost, options);
    } else if (buttonIndex == 1){
        Image_capture_wallpost();
    }
    else
    {
        
    }
}

function fail_wallpost() {
    setTimeout(function(){ window.location="hidestatusbar:";},100);
    setTimeout(function() {
               
               checkupdate();
               }, 60000);
}

function win_image_lib_wallpost(imageURI) {
    setTimeout(function(){ window.location="hidestatusbar:";},100);
    localStorage.local_imageURI_wallpost = imageURI;
    show_image_on_box_wallpost();
}

function Image_capture_wallpost() {
    var options = {
    limit: 1
    };
    navigator.device.capture.captureImage(captureSuccess2_wallpost, captureError_wallpost, options);
}

function captureError_wallpost() {
    setTimeout(function(){ window.location="hidestatusbar:";},100);
    setTimeout(function() {
               
               checkupdate();
               }, 60000);
}

function captureSuccess2_wallpost(mediaFiles) {
    setTimeout(function(){ window.location="hidestatusbar:";},100);
    localStorage.local_imageURI_wallpost = mediaFiles[0].fullPath;
    //mediaFiles = goToNativeForRotation(mediaFiles[0].fullPath);
    localStorage.local_imageURI_wallpost = mediaFiles[0].fullPath;
    show_image_on_box_wallpost();
}

function goToNativeForRotation(str)
 {
    return toaster.CheckIamgeOrientation(str);
 }

function show_image_on_box_wallpost() {
    Image_url_wallpost = "";
    localStorage.setItem("Image_selection", "Done");
    var mediaFiles = localStorage.local_imageURI_wallpost;
    document.getElementById("set_Wall_pic").src = mediaFiles;
    $(".appypie-wall-update .wall-pic").hide();
    $(".appypie-wall-update .chat-pic-1").show();
}
var profile = '';
var lastcount=0;
var currentcount=0;
var checkupdateflag=1;

function checkupdate()
{
    if(checkupdateflag==1)
    {
    var wsUrll = "http://"+resellerInitial+reseller+"/services/socialwall-soap#getPosts";
    var soapRequestt = '<?xml version="1.0" encoding="utf-8"?> <soap:Envelope xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"  xmlns:xsd="http://www.w3.org/2001/XMLSchema" xmlns:soap="http://schemas.xmlsoap.org/soap/envelope/"> <soap:Body><getPosts xmlns=\"http://'+resellerInitial+reseller+'/services/socialwall-soap#getPosts\"><deviceId>' + device_Token + '</deviceId><appId>' + localStorage.getItem('applicationID') + '</appId><pageId>' + indexvalwall + '</pageId><page>'+pageno+'</page></getPosts></soap:Body></soap:Envelope>';
    console.log("SoapRequest : " + soapRequestt);
    $.ajax({
           type: "POST",
           url: wsUrll,
           contentType: "text/xml",
           dataType: "text",
           data: soapRequestt,
           success: function(data, status, req) {
           var strJSON = $(req.responseText).find("return").text();
           console.log("success setting gaurav : " + strJSON);
           
           var obj = JSON.parse(strJSON);
           currentcount= parseInt(obj.response.count);
           if ( currentcount>lastcount)
           {
           
                document.getElementById('wall_subheader').style.display='block';
           
           }
           else
           {
           
                document.getElementById('wall_subheader').style.display='none';
           }
           setTimeout(function() {
                      
                      checkupdate();
                      }, 60000);
           },
           error: function(response, textStatus, errorThrown) {
           setTimeout(function() {
                      
                      checkupdate();
                      }, 60000);
           $('.appypie-loader').hide();
           console.log("Error : " + JSON.stringify(response));
           console.log("Error : " + textStatus);
           console.log("Error : " + errorThrown.responseText);
           }
           });
    }
}
function updateWall()
{
		
    var mediaFilesforeditprofile;
    var srcforeditprofile;
    if(Image_url_wallpost=="")
    {
         mediaFilesforeditprofile= localStorage.local_imageURI_wallpost;
        srcforeditprofile=mediaFilesforeditprofile;
    }
    else
    {
        mediaFilesforeditprofile=Image_url_wallpost;
        srcforeditprofile=mediaFilesforeditprofile;
        var randomnumber2 = Math.floor((Math.random() * 100) + 1);
        srcforeditprofile=srcforeditprofile+'?'+randomnumber2;
    }
   
    document.getElementById('wall_load_more_image').style.display='block';
    document.getElementById('wall_load_more_text').style.display='none';
    pageno = 1;
    profile = '';
    
    var temp2 = "";
    //<div class='load-more' ><a href='#' id='wall_subheader'>Load More Post</a> <span><img src='images/loader.gif'></span></div>
    var globalusername="globalusername"+indexvalwall;
    var temp = "<div class='load-more' id='wall_subheader' onclick='updateWall();'><a href='#'   id='wall_load_more_text'>"+loadmore_wallpost+"</a> <span style='display:none;' id='wall_load_more_image'><img src='images/loader.gif'></span></div>\
    <section class='wallApp-container'>\
    <div class='social-clear'></div>\
    <div class='userProfiel-box' onclick='editprofile_from_wall();'>\
    <div class='app-image'><img src="+srcforeditprofile+" style='height:100%'></div>\
    <div class='proName'><span>"+localStorage.getItem(globalusername)+"</span></div>\
    <img src='images/arrows.png' class=''>\
    </div>\
    <div class='social-btn'> \
    <div class='buttonDiv'>\
    <ul>\
    <li id='updatestatus' onclick='select_for_status_update();'>"+updatestatus_walpost+"</li>\
    <li id='addphotovideo' class='sociel-active' onclick='select_for_post_upload();' >"+addphotovideo_wallpost+"</li>\
    </ul>\
    </div>\
    </div>\
    <div class='appPost-middlepan'>\
    <div class='wallApp-video' style='display:none;' id='video_add_wallpost'>\
    <div class='updatePhoto'>\
    <textarea name='' cols='' rows='' id='captionnnWallPost_video' placeholder="+saysomething_wallpost+"'...' style='font-size:16px;'></textarea>\
    <video width='100%' height='100%' id='video_add_wallPost_show' src='images/20140725_192046.mp4' controls>\
    </video> \
    <div class='post-box'><a onclick='PostUpload();' href='#'>"+post_wallpost+"</a></div>\
    </div>\
    </div>\
    <div class='appPost-box' style='display:none;' id='image_add_wallPost'>\
    <div class='updatePhoto'>\
    <textarea name='' cols='' rows='' id='captionnnWallPost_image' placeholder="+saysomething_wallpost+"'...' style='font-size:16px;'></textarea>\
    <div class='appPost-box'><img id='image_add_wallPost_show' src='images/post-img.png'></div>\
    <div class='post-box'><a href='#' onclick='PostUpload();'>"+post_wallpost+"</a></div>\
    </div>\
    </div>\
    <div class='socialUpload-file' id='photo_video_selection'  style='display:none;'>  \
    <div class='sUpload-pan'>\
    <div class='suploadFile' onclick='select_for_img_post_upload();'><a href='#'><img src='images/social-upload-img.png'></a> <span><a href='#'>"+uploadimage_wallpoast+"</a></span></div>\
    <div class='suploadFile suploadVideo' onclick='select_for_video_post_upload();'><a href='#'><img src='images/social-upload-video.png'></a> <span><a href='#'>"+uploadvideo_wallpost+"</a></span></div>\
    </div>\
    </div>\
    <div class='appPost-box' id='textUploadWall'>      	\
    <textarea name='' cols='' rows='' id='captionnnWallPost' style='font-size:16px;'></textarea>\
    <div class='post-box'><span></span> <a onclick='PostUpload();' href='#'>"+post_wallpost+"</a></div>\
    </div>";
    
    
    var wsUrll = "http://"+resellerInitial+reseller+"/services/socialwall-soap#getPosts";
    var soapRequestt = '<?xml version="1.0" encoding="utf-8"?> <soap:Envelope xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"  xmlns:xsd="http://www.w3.org/2001/XMLSchema" xmlns:soap="http://schemas.xmlsoap.org/soap/envelope/"> <soap:Body><getPosts xmlns=\"http://'+resellerInitial+reseller+'/services/socialwall-soap#getPosts\"><deviceId>' + device_Token + '</deviceId><appId>' + localStorage.getItem('applicationID') + '</appId><pageId>' + indexvalwall + '</pageId><page>1</page></getPosts></soap:Body></soap:Envelope>';
    console.log("SoapRequest : " + soapRequestt);
    $.ajax({
           type: "POST",
           url: wsUrll,
           contentType: "text/xml",
           dataType: "text",
           data: soapRequestt,
           success: function(data, status, req) {
           var strJSON = $(req.responseText).find("return").text();
           console.log("success setting gaurav : " + strJSON);
           
           var obj = JSON.parse(strJSON);
           lastcount= parseInt(obj.response.count);
           if (obj.response.data != null) {
           
           var randomnumber = Math.floor((Math.random() * 100) + 1);
           for (var i = 0; i < obj.response.data.length; i++) {
           
           if (obj.response.page > 1) {
           
           temp2 = "<div class='wallsection_post_div' style='margin-top:20px;'><div class='post-box' style='background: none; border: none; height: 45px; margin-top:0px; padding-top:0px;'  align='center'> <a href='#' style='font-size: 18px; float: none; font-weight: normal; padding: 5px 16px;' onclick='openWall2();'>"+showmore_wallpost+"</a></div></div></section>";
           }
           else
           {
           temp2="</section>";
           }
           if (obj.response.data[i].post_type == "video") {
           var profile_image=obj.response.data[i].profile_image+'?'+randomnumber;
           profile += "<div class='wallsection_post_div'>\
           <div class='app-image'><img src=" + profile_image + " style='height:100%'></div>\
           <div class='tpHead1'><span class='blueHead1'>" + obj.response.data[i].user + "</span>"+postedvideo_walpost+"</div>\
           <div class='postSection'>\
           <div class='postContainer border_none'>\
           <h2>" + obj.response.data[i].message + "</h2>\
           <div class='wallApp-video'>\
           <video width='100%' height='100%' controls>\
           <source src=" + obj.response.data[i].video + " type='video/mp4'>\
           </video>\
           </div>\
           </div>\
           <div class='social-like-comment'>\
           <div class='social_like'>";
           var iDforPostReport = "staticText$$$" + obj.response.data[i].postId;
           
           //alert(obj.response.data[i].count_like + llike_wallpost);
           
           if (obj.response.data[i].liked == 0) {
           profile += "<a href='#' id=" + obj.response.data[i].postId + " onclick='like_post_wall(this.id," + obj.response.data[i].count_like + ");' style='text-decoration:none; color: black;'><img src='images/sociel-like.png'> " + obj.response.data[i].count_like  +llike_wallpost+ " </a></div>\
           <div class='social_comment' onclick='Postpage_wall(" + obj.response.data[i].postId + ");'><img src='images/social-comment.png'>" + obj.response.data[i].count_comment + comment_walpost +"</div>\
            <div class='social_report' id=" + iDforPostReport + " onclick='reportpost(this.id);'><img src='images/sociel-report.png'>"+rreportabuse_wallpost+"</div>\
           </div>";
           
           //console.log("gou: " + profile);
           } else {
           profile += "<a href='#' id=" + obj.response.data[i].postId + " onclick='like_post_wall(this.id," + obj.response.data[i].count_like + ");' style='text-decoration:none; color: black;'><img src='images/sociel-liked.png'> " + obj.response.data[i].count_like + llike_wallpost+"</a></div>\
           <div class='social_comment' onclick='Postpage_wall(" + obj.response.data[i].postId + ");'><img src='images/social-comment.png'>" + obj.response.data[i].count_comment + comment_walpost +"</div>\
            <div class='social_report' id=" + iDforPostReport + " onclick='reportpost(this.id);'><img src='images/sociel-report.png'>"+rreportabuse_wallpost+"</div>\
           </div>";
           }
           if (obj.response.data[i].comments) {
           profile += "<div class='postContainer'>\
           <div class='socialComment'>\
           <ul>";
           var temp_for_loop = 5;
           if (obj.response.data[i].comments.length < 5) {
           temp_for_loop = obj.response.data[i].comments.length;
           }
           for (var j = 0; j < temp_for_loop; j++) {
           var id_4_comment = obj.response.data[i].postId + "$$$" + obj.response.data[i].comments[j].id;
           var profile_image_comment=obj.response.data[i].comments[j].profile_image+'?'+randomnumber;
           var iDforReport = "staticText$$$" + obj.response.data[i].comments[j].id;
           profile += "<li>\
           <div class='socialC-image'><img src=" + profile_image_comment + " style='height:100%;'></div>\
           <div class='socialcomment-txt'>\
           <div class='commentSocial'><span class='blueHead1'>" + obj.response.data[i].comments[j].user + "</span> " + obj.response.data[i].comments[j].message + " </div>\
           <div class='social_like'><a href='#' id=" + id_4_comment + " onclick='like_comment_wall(this.id," + obj.response.data[i].comments[j].count_like + ");' style='text-decoration:none; color: black;'>";
           if (obj.response.data[i].comments[j].liked == 0) {
           profile += "<img src='images/sociel-like.png'> " + obj.response.data[i].comments[j].count_like + llike_wallpost +" </a></div>\
           <div class='social_report'><a id=" + iDforReport + " onclick='reportcomment(this.id);'><img src='images/sociel-report.png'>"+rreportabuse_wallpost+"</a></div>\
           </div>\
           </li>";
           } else {
           profile += "<img src='images/sociel-liked.png'> " + obj.response.data[i].comments[j].count_like+ llike_wallpost+"</a></div>\
           <div class='social_report'><a  id=" + iDforReport + " onclick='reportcomment(this.id);'><img src='images/sociel-report.png'>"+rreportabuse_wallpost+"</a></div>\
           </div>\
           </li>";
           }
           }
           if (obj.response.data[i].comments.length > 5) {
           profile += "<div class='socialView-all' onclick='Postpage_wall(" + obj.response.data[i].postId + ");'><a href='#'>"+viewall_wallpost+"</a></div>";
           }
           profile+="</ul>\
           </div>\
           </div>";
           }
           profile+="</div>\
           </div> \
           </div>";
           }
           
           else if (obj.response.data[i].post_type == "image") {
           var profile_image=obj.response.data[i].profile_image+'?'+randomnumber;
           profile += "<div class='wallsection_post_div'>\
           <div class='app-image'><img src=" + profile_image + " style='height:100%'></div>\
           <div class='tpHead1'><span class='blueHead1'>" + obj.response.data[i].user + "</span>"+postedphoto_wallpost+"</div>\
           <div class='postSection'>\
           <div class='postContainer border_none'>\
           <h2>" + obj.response.data[i].message + "</h2>\
           <div class='appPost-box'><img src=" + obj.response.data[i].image + " id=" + obj.response.data[i].image + "  onclick='openLargeImage(this.id);'></div>\
           </div>\
           <div class='social-like-comment'>\
           <div class='social_like'>";
           var iDforPostReport = "staticText$$$" + obj.response.data[i].postId;
           if (obj.response.data[i].liked == 0) {
           profile += "<a href='#' id=" + obj.response.data[i].postId + " onclick='like_post_wall(this.id," + obj.response.data[i].count_like + ");' style='text-decoration:none; color: black;'><img src='images/sociel-like.png'> " + obj.response.data[i].count_like + llike_wallpost +"</a></div>\
           <div class='social_comment' onclick='Postpage_wall(" + obj.response.data[i].postId + ");'><img src='images/social-comment.png'>" + obj.response.data[i].count_comment + comment_walpost+"</div>\
           <div class='social_report' id=" + iDforPostReport + " onclick='reportpost(this.id);'><img src='images/sociel-report.png'>"+rreportabuse_wallpost+"</div>\
           </div>";
           } else {
           profile += "<a href='#' id=" + obj.response.data[i].postId + " onclick='like_post_wall(this.id," + obj.response.data[i].count_like + ");' style='text-decoration:none; color: black;'><img src='images/sociel-liked.png'> " + obj.response.data[i].count_like + llike_wallpost +"</a></div>\
           <div class='social_comment' onclick='Postpage_wall(" + obj.response.data[i].postId + ");'><img src='images/social-comment.png'>" + obj.response.data[i].count_comment + comment_walpost+"</div>\
           <div class='social_report' id=" + iDforPostReport + " onclick='reportpost(this.id);'><img src='images/sociel-report.png'>"+rreportabuse_wallpost+"</div>\
           </div>";
           }
           if (obj.response.data[i].comments) {
           profile += "<div class='postContainer'>\
           <div class='socialComment'>\
           <ul>";
           var temp_for_loop = 5;
           if (obj.response.data[i].comments.length < 5) {
           temp_for_loop = obj.response.data[i].comments.length;
           }
           for (var j = 0; j < temp_for_loop; j++) {
           var id_4_comment = obj.response.data[i].postId + "$$$" + obj.response.data[i].comments[j].id;
           var profile_image_comments=obj.response.data[i].comments[j].profile_image+'?'+randomnumber;
           var iDforReport = "staticText$$$" + obj.response.data[i].comments[j].id;
           profile += "<li>\
           <div class='socialC-image'><img src=" + profile_image_comments + " style='height:100%;'></div>\
           <div class='socialcomment-txt'>\
           <div class='commentSocial'><span class='blueHead1'>" + obj.response.data[i].comments[j].user + "</span> " + obj.response.data[i].comments[j].message + " </div>\
           <div class='social_like'><a href='#' id=" + id_4_comment + " onclick='like_comment_wall(this.id," + obj.response.data[i].comments[j].count_like + ");' style='text-decoration:none; color: black;'>";
           if (obj.response.data[i].comments[j].liked == 0) {
           profile += "<img src='images/sociel-like.png'> " + obj.response.data[i].comments[j].count_like + llike_wallpost +"</a></div>\
           <div class='social_report'><a  id=" + iDforReport + " onclick='reportcomment(this.id);'><img src='images/sociel-report.png'>"+rreportabuse_wallpost+"</a></div>\
           </div>\
           </li>";
           } else {
           profile += "<img src='images/sociel-liked.png'> " + obj.response.data[i].comments[j].count_like + llike_wallpost+" </a></div>\
           <div class='social_report'><a  id=" + iDforReport + " onclick='reportcomment(this.id);'><img src='images/sociel-report.png'>"+rreportabuse_wallpost+"</a></div>\
           </div>\
           </li>";
           }
           }
           if (obj.response.data[i].comments.length > 5) {
           profile += "<div class='socialView-all' onclick='Postpage_wall(" + obj.response.data[i].postId + ");'><a href='#'>"+viewall_wallpost+"</a></div>";
           }
           profile+="</ul>\
           </div>\
           </div>";
           }
           profile+="</div>\
           </div> \
           </div>";
           }
           
           else {
           var profile_image=obj.response.data[i].profile_image+'?'+randomnumber;
           profile += "<div class='wallsection_post_div'>\
           <div class='app-image'><img src=" + profile_image + " style='height:100%'></div>\
           <div class='tpHead1'><span class='blueHead1'>" + obj.response.data[i].user + "</span>"+postedstatus_wallpost+"</div>\
           <div class='postSection'>\
           <div class='postContainer border_none'>\
           <p class='capsHead'></p>\
           <div class='socialPost-text'>" + obj.response.data[i].message + "</div>\
           </div>\
           <div class='social-like-comment'>\
           <div class='social_like'>";
           var iDforPostReport = "staticText$$$" + obj.response.data[i].postId;
           if (obj.response.data[i].liked == 0) {
           profile += "<a href='#' id=" + obj.response.data[i].postId + " onclick='like_post_wall(this.id," + obj.response.data[i].count_like + ");' style='text-decoration:none; color: black;'><img src='images/sociel-like.png'> " + obj.response.data[i].count_like + llike_wallpost+" </a></div>\
           <div class='social_comment' onclick='Postpage_wall(" + obj.response.data[i].postId + ");'><img src='images/social-comment.png'>" + obj.response.data[i].count_comment + comment_walpost +"</div>\
            <div class='social_report' id=" + iDforPostReport + " onclick='reportpost(this.id);'><img src='images/sociel-report.png'>"+rreportabuse_wallpost+"</div>\
           </div>";
           } else {
           profile += "<a href='#' id=" + obj.response.data[i].postId + " onclick='like_post_wall(this.id," + obj.response.data[i].count_like + ");' style='text-decoration:none; color: black;'><img src='images/sociel-liked.png'> " + obj.response.data[i].count_like + llike_wallpost+" </a></div>\
           <div class='social_comment' onclick='Postpage_wall(" + obj.response.data[i].postId + ");'><img src='images/social-comment.png'>" + obj.response.data[i].count_comment + comment_walpost +"</div>\
            <div class='social_report' id=" + iDforPostReport + " onclick='reportpost(this.id);'><img src='images/sociel-report.png'>"+rreportabuse_wallpost+"</div>\
           </div>";
           
           }
           if (obj.response.data[i].comments) {
           profile += "<div class='postContainer'>\
           <div class='socialComment'>\
           <ul>";
           var temp_for_loop = 5;
           if (obj.response.data[i].comments.length < 5) {
           temp_for_loop = obj.response.data[i].comments.length;
           }
           for (var j = 0; j < temp_for_loop; j++) {
           var id_4_comment = obj.response.data[i].postId + "$$$" + obj.response.data[i].comments[j].id;
           var iDforReport = "staticText$$$" + obj.response.data[i].comments[j].id;
           var profile_image_comments=obj.response.data[i].comments[j].profile_image+'?'+randomnumber;
           profile += "<li>\
           <div class='socialC-image'><img src=" + profile_image_comments + " style='height:100%;'></div>\
           <div class='socialcomment-txt'>\
           <div class='commentSocial'><span class='blueHead1'>" + obj.response.data[i].comments[j].user + "</span> " + obj.response.data[i].comments[j].message + " </div>\
           <div class='social_like'><a href='#' id=" + id_4_comment + " onclick='like_comment_wall(this.id," + obj.response.data[i].comments[j].count_like + ");' style='text-decoration:none; color: black;'>";
           if (obj.response.data[i].comments[j].liked == 0) {
           profile += "<img src='images/sociel-like.png'> " + obj.response.data[i].comments[j].count_like + llike_wallpost+" </a></div>\
           <div class='social_report'><a  id=" + iDforReport + " onclick='reportcomment(this.id);'><img src='images/sociel-report.png'>"+rreportabuse_wallpost+"</a></div>\
           </div>\
           </li>";
           } else {
           profile += "<img src='images/sociel-liked.png'> " + obj.response.data[i].comments[j].count_like + llike_wallpost+" </a></div>\
           <div class='social_report'><a  id=" + iDforReport + " onclick='reportcomment(this.id);'><img src='images/sociel-report.png'>"+rreportabuse_wallpost+"</a></div>\
           </div>\
           </li>";
           }
           }
           if (obj.response.data[i].comments.length > 5) {
           profile += "<div class='socialView-all' onclick='Postpage_wall(" + obj.response.data[i].postId + ");'><a href='#'>"+viewall_wallpost+"</a></div>";
           }
           profile += "</ul>\
           </div>\
           </div>";
           }
           profile+="</div>\
           </div> \
           </div>";
           }
           }
           }
           
           $('#contentHolder17').css('background', '#edf0f5');
           appendHtml(temp + profile + temp2,17,1);
           localStorage.uploadtypeWallPost = 'text';
           document.getElementById("video_add_wallpost").style.display = 'none';
           document.getElementById("image_add_wallPost").style.display = 'none';
           document.getElementById('photo_video_selection').style.display = 'none';
           $('.appypie-loader').hide();
           
           document.getElementById('wall_subheader').style.display='none';
           setTimeout(function() {
                      
                      checkupdate();
                      }, 60000);
           },
           error: function(response, textStatus, errorThrown) {
           setTimeout(function() {
                      
                      checkupdate();
                      }, 60000);
           $('.appypie-loader').hide();
           console.log("Error : " + JSON.stringify(response));
           console.log("Error : " + textStatus);
           console.log("Error : " + errorThrown.responseText);
           }
           });
}
function openWall(value) {
	
	
	
    
    var mediaFilesforeditprofile;
    var srcforeditprofile;
    if(Image_url_wallpost=="")
    {
        mediaFilesforeditprofile= localStorage.local_imageURI_wallpost;
        srcforeditprofile= mediaFilesforeditprofile;
    }
    else
    {
        mediaFilesforeditprofile=Image_url_wallpost;
        srcforeditprofile=mediaFilesforeditprofile;
        var randomnumber2 = Math.floor((Math.random() * 100) + 1);
        srcforeditprofile=srcforeditprofile+'?'+randomnumber2;
    }
      $('.appypie-loader').show();
    pageno = 1;
    profile = '';
    var temp2 = "";
    //<div class='load-more' ><a href='#' id='wall_subheader'>Load More Post</a> <span><img src='images/loader.gif'></span></div>
    var globalusername="globalusername"+indexvalwall;
    var temp = "<div class='load-more' id='wall_subheader' onclick='updateWall();'><a href='#'   id='wall_load_more_text'>"+loadmorepost_wallpost+"</a> <span style='display:none;' id='wall_load_more_image'><img src='images/loader.gif'></span></div>\
    <section class='wallApp-container'>\
    <div class='social-clear'></div>\
    <div class='userProfiel-box' onclick='editprofile_from_wall();'>\
    <div class='app-image'><img src="+srcforeditprofile+" style='height:100%'></div>\
    <div class='proName'><span>"+localStorage.getItem(globalusername)+"</span></div>\
    <img src='images/arrows.png' class=''>\
    </div>\
    <div class='app-btn'>\
    <ul>\
    <li id='updatestatus' onclick='select_for_status_update();'>"+updatestatus_walpost+"</li>\
    <li id='addphotovideo' class='sociel-active' onclick='select_for_post_upload();' >"+addphotovideo_wallpost+"</li>\
    </ul>\
    </div>\
    <div class='appPost-middlepan'>\
    <div class='wallApp-video' style='display:none;' id='video_add_wallpost'>\
    <div class='updatePhoto'>\
    <textarea name='' cols='' rows='' id='captionnnWallPost_video' placeholder="+saysomething_wallpost+"'...' style='font-size:16px;'></textarea>\
    <video width='100%' height='100%' id='video_add_wallPost_show' src='images/20140725_192046.mp4' controls>\
    </video> \
    <div class='post-box'><a onclick='PostUpload();' href='#'>"+post_wallpost+"</a></div>\
    </div>\
    </div>\
    <div class='appPost-box' style='display:none;' id='image_add_wallPost'>\
    <div class='updatePhoto'>\
    <textarea name='' cols='' rows='' id='captionnnWallPost_image' placeholder="+saysomethingimage_wallpost+"'...' style='font-size:16px;'></textarea>\
    <div class='appPost-box'><img id='image_add_wallPost_show' src='images/post-img.png'></div>\
    <div class='post-box'><a href='#' onclick='PostUpload();'>"+post_wallpost+"</a></div>\
    </div>\
    </div>\
    <div class='socialUpload-file' id='photo_video_selection'  style='display:none;'>  \
    <div class='sUpload-pan'>\
    <div class='suploadFile' onclick='select_for_img_post_upload();'><a href='#'><img src='images/social-upload-img.png'></a> <span><a href='#'>"+uploadimage_wallpoast+"</a></span></div>\
    <div class='suploadFile suploadVideo' onclick='select_for_video_post_upload();'><a href='#'><img src='images/social-upload-video.png'></a> <span><a href='#'>"+uploadvideo_wallpost+"</a></span></div>\
    </div>\
    </div>\
    <div class='appPost-box' id='textUploadWall'>      	\
    <textarea name='' cols='' rows='' id='captionnnWallPost' style='font-size:16px;'></textarea>\
    <div class='post-box'><span></span> <a onclick='PostUpload();' href='#'>"+post_wallpost+"</a></div>\
    </div>";
    
    
    var wsUrll = "http://"+resellerInitial+reseller+"/services/socialwall-soap#getPosts";
    var soapRequestt = '<?xml version="1.0" encoding="utf-8"?> <soap:Envelope xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"  xmlns:xsd="http://www.w3.org/2001/XMLSchema" xmlns:soap="http://schemas.xmlsoap.org/soap/envelope/"> <soap:Body><getPosts xmlns=\"http://'+resellerInitial+reseller+'/services/socialwall-soap#getPosts\"><deviceId>' + device_Token + '</deviceId><appId>' + localStorage.getItem('applicationID') + '</appId><pageId>' + indexvalwall + '</pageId><page>1</page></getPosts></soap:Body></soap:Envelope>';
    console.log("SoapRequest : " + soapRequestt);
    $.ajax({
           type: "POST",
           url: wsUrll,
           contentType: "text/xml",
           dataType: "text",
           data: soapRequestt,
           success: function(data, status, req) {
           var strJSON = $(req.responseText).find("return").text();
           console.log("success setting gaurav : " + strJSON);
           
           var obj = JSON.parse(strJSON);
           lastcount= parseInt(obj.response.count);
           if (obj.response.data != null) {
           
           var randomnumber = Math.floor((Math.random() * 100) + 1);
           for (var i = 0; i < obj.response.data.length; i++) {
           
           if (obj.response.page > 1) {
           
          temp2 = "<div class='wallsection_post_div' style='margin-top:20px;'><div class='post-box' style='background: none; border: none; height: 45px; margin-top:0px; padding-top:0px;'  align='center'> <a href='#' style='font-size: 18px; float: none; font-weight: normal; padding: 5px 16px;' onclick='openWall2();'>"+showmore_wallpost+"</a></div></div></section>";
           }
           else
           {
           temp2="</section>";
           }
           if (obj.response.data[i].post_type == "video") {
           var profile_image=obj.response.data[i].profile_image+'?'+randomnumber;
           profile += "<div class='wallsection_post_div'>\
           <div class='app-image'><img src=" + profile_image + " style='height:100%'></div>\
           <div class='tpHead1'><span class='blueHead1'>" + obj.response.data[i].user + "</span>"+postedvideo_walpost+"</div>\
           <div class='postSection'>\
           <div class='postContainer border_none'>\
           <h2>" + obj.response.data[i].message + "</h2>\
           <div class='wallApp-video'>\
           <video width='100%' height='100%' controls>\
           <source src=" + obj.response.data[i].video + " type='video/mp4'>\
           </video>\
           </div>\
           </div>\
           <div class='social-like-comment'>\
           <div class='social_like'>";
           var iDforPostReport = "staticText$$$" + obj.response.data[i].postId;
           if (obj.response.data[i].liked == 0) {
           profile += "<a href='#' id=" + obj.response.data[i].postId + " onclick='like_post_wall(this.id," + obj.response.data[i].count_like + ");' style='text-decoration:none; color: black;'><img src='images/sociel-like.png'> " + obj.response.data[i].count_like + llike_wallpost+" </a></div>\
           <div class='social_comment' onclick='Postpage_wall(" + obj.response.data[i].postId + ");'><img src='images/social-comment.png'>" + obj.response.data[i].count_comment + comment_walpost+"</div>\
            <div class='social_report' id=" + iDforPostReport + " onclick='reportpost(this.id);'><img src='images/sociel-report.png'>"+rreportabuse_wallpost+"</div>\
           </div>";
           } else {
           profile += "<a href='#' id=" + obj.response.data[i].postId + " onclick='like_post_wall(this.id," + obj.response.data[i].count_like + ");' style='text-decoration:none; color: black;'><img src='images/sociel-liked.png'> " + obj.response.data[i].count_like + llike_wallpost+" </a></div>\
           <div class='social_comment' onclick='Postpage_wall(" + obj.response.data[i].postId + ");'><img src='images/social-comment.png'>" + obj.response.data[i].count_comment + comment_walpost+"</div>\
            <div class='social_report' id=" + iDforPostReport + " onclick='reportpost(this.id);'><img src='images/sociel-report.png'>"+rreportabuse_wallpost+"</div>\
           </div>";
           }
           if (obj.response.data[i].comments) {
           profile += "<div class='postContainer'>\
           <div class='socialComment'>\
           <ul>";
           var temp_for_loop = 5;
           if (obj.response.data[i].comments.length < 5) {
           temp_for_loop = obj.response.data[i].comments.length;
           }
           for (var j = 0; j < temp_for_loop; j++) {
           var id_4_comment = obj.response.data[i].postId + "$$$" + obj.response.data[i].comments[j].id;
           var profile_image_comment=obj.response.data[i].comments[j].profile_image+'?'+randomnumber;
           var iDforReport = "staticText$$$" + obj.response.data[i].comments[j].id;
           profile += "<li>\
           <div class='socialC-image'><img src=" + profile_image_comment + " style='height:100%;'></div>\
           <div class='socialcomment-txt'>\
           <div class='commentSocial'><span class='blueHead1'>" + obj.response.data[i].comments[j].user + "</span> " + obj.response.data[i].comments[j].message + " </div>\
           <div class='social_like'><a href='#' id=" + id_4_comment + " onclick='like_comment_wall(this.id," + obj.response.data[i].comments[j].count_like + ");' style='text-decoration:none; color: black;'>";
           if (obj.response.data[i].comments[j].liked == 0) {
           profile += "<img src='images/sociel-like.png'> " + obj.response.data[i].comments[j].count_like + llike_wallpost+" </a></div>\
           <div class='social_report'><a  id=" + iDforReport + " onclick='reportcomment(this.id);'><img src='images/sociel-report.png'>"+rreportabuse_wallpost+"</a></div>\
           </div>\
           </li>";
           } else {
           profile += "<img src='images/sociel-liked.png'> " + obj.response.data[i].comments[j].count_like + llike_wallpost+" </a> </div>\
           <div class='social_report'><a  id=" + iDforReport + " onclick='reportcomment(this.id);'><img src='images/sociel-report.png'>"+rreportabuse_wallpost+"</a></div>\
           </div>\
           </li>";
           }
           }
           if (obj.response.data[i].comments.length > 5) {
           profile += "<div class='socialView-all' onclick='Postpage_wall(" + obj.response.data[i].postId + ");'><a href='#'>"+viewall_wallpost+"</a></div>";
           }
           profile+="</ul>\
           </div>\
           </div>";
           }
           profile+="</div>\
           </div> \
           </div>";
           }
           
           else if (obj.response.data[i].post_type == "image") {
           var profile_image=obj.response.data[i].profile_image+'?'+randomnumber;
           profile += "<div class='wallsection_post_div'>\
           <div class='app-image'><img src=" + profile_image + " style='height:100%'></div>\
           <div class='tpHead1'><span class='blueHead1'>" + obj.response.data[i].user + "</span>"+postedphoto_wallpost+"</div>\
           <div class='postSection'>\
           <div class='postContainer border_none'>\
           <h2>" + obj.response.data[i].message + "</h2>\
           <div class='appPost-box'><img src=" + obj.response.data[i].image + " id=" + obj.response.data[i].image + "  onclick='openLargeImage(this.id);'></div>\
           </div>\
           <div class='social-like-comment'>\
           <div class='social_like'>";
           var iDforPostReport = "staticText$$$" + obj.response.data[i].postId;
           if (obj.response.data[i].liked == 0) {
           profile += "<a href='#' id=" + obj.response.data[i].postId + " onclick='like_post_wall(this.id," + obj.response.data[i].count_like + ");' style='text-decoration:none; color: black;'><img src='images/sociel-like.png'> " + obj.response.data[i].count_like + llike_wallpost+" </a></div>\
           <div class='social_comment' onclick='Postpage_wall(" + obj.response.data[i].postId + ");'><img src='images/social-comment.png'>" + obj.response.data[i].count_comment + comment_walpost+"</div>\
            <div class='social_report' id=" + iDforPostReport + " onclick='reportpost(this.id);'><img src='images/sociel-report.png'>"+rreportabuse_wallpost+"</div>\
           </div>";
           } else {
           profile += "<a href='#' id=" + obj.response.data[i].postId + " onclick='like_post_wall(this.id," + obj.response.data[i].count_like + ");' style='text-decoration:none; color: black;'><img src='images/sociel-liked.png'> " + obj.response.data[i].count_like + llike_wallpost+" </a></div>\
           <div class='social_comment' onclick='Postpage_wall(" + obj.response.data[i].postId + ");'><img src='images/social-comment.png'>" + obj.response.data[i].count_comment + comment_walpost+"</div>\
            <div class='social_report' id=" + iDforPostReport + " onclick='reportpost(this.id);'><img src='images/sociel-report.png'>"+rreportabuse_wallpost+"</div>\
           </div>";
           }
           if (obj.response.data[i].comments) {
           profile += "<div class='postContainer'>\
           <div class='socialComment'>\
           <ul>";
           var temp_for_loop = 5;
           if (obj.response.data[i].comments.length < 5) {
           temp_for_loop = obj.response.data[i].comments.length;
           }
           for (var j = 0; j < temp_for_loop; j++) {
           var id_4_comment = obj.response.data[i].postId + "$$$" + obj.response.data[i].comments[j].id;
           var profile_image_comments=obj.response.data[i].comments[j].profile_image+'?'+randomnumber;
           var iDforReport = "staticText$$$" + obj.response.data[i].comments[j].id;
           profile += "<li>\
           <div class='socialC-image'><img src=" + profile_image_comments + " style='height:100%;'></div>\
           <div class='socialcomment-txt'>\
           <div class='commentSocial'><span class='blueHead1'>" + obj.response.data[i].comments[j].user + "</span> " + obj.response.data[i].comments[j].message + " </div>\
           <div class='social_like'><a href='#' id=" + id_4_comment + " onclick='like_comment_wall(this.id," + obj.response.data[i].comments[j].count_like + ");' style='text-decoration:none; color: black;'>";
           if (obj.response.data[i].comments[j].liked == 0) {
           profile += "<img src='images/sociel-like.png'> " + obj.response.data[i].comments[j].count_like + llike_wallpost+" </a></div>\
           <div class='social_report'><a  id=" + iDforReport + " onclick='reportcomment(this.id);'><img src='images/sociel-report.png'>"+rreportabuse_wallpost+"</a></div>\
           </div>\
           </li>";
           } else {
           profile += "<img src='images/sociel-liked.png'> " + obj.response.data[i].comments[j].count_like + llike_wallpost+" </a></div>\
           <div class='social_report'><a  id=" + iDforReport + " onclick='reportcomment(this.id);'><img src='images/sociel-report.png'>"+rreportabuse_wallpost+"</a></div>\
           </div>\
           </li>";
           }
           }
           if (obj.response.data[i].comments.length > 5) {
           profile += "<div class='socialView-all' onclick='Postpage_wall(" + obj.response.data[i].postId + ");'><a href='#'>"+viewall_wallpost+"</a></div>";
           }
           profile+="</ul>\
           </div>\
           </div>";
           }
           profile+="</div>\
           </div> \
           </div>";
           }

           else {
           var profile_image=obj.response.data[i].profile_image+'?'+randomnumber;
           profile += "<div class='wallsection_post_div'>\
           <div class='app-image'><img src=" + profile_image + " style='height:100%'></div>\
           <div class='tpHead1'><span class='blueHead1'>" + obj.response.data[i].user + "</span>"+postedstatus_wallpost+"</div>\
           <div class='postSection'>\
           <div class='postContainer border_none'>\
           <p class='capsHead'></p>\
           <div class='socialPost-text'>" + obj.response.data[i].message + "</div>\
           </div>\
           <div class='social-like-comment'>\
           <div class='social_like'>";
           var iDforPostReport = "staticText$$$" + obj.response.data[i].postId;
           if (obj.response.data[i].liked == 0) {
           profile += "<a href='#' id=" + obj.response.data[i].postId + " onclick='like_post_wall(this.id," + obj.response.data[i].count_like + ");' style='text-decoration:none; color: black;'><img src='images/sociel-like.png'> " + obj.response.data[i].count_like + llike_wallpost+" </a></div>\
           <div class='social_comment' onclick='Postpage_wall(" + obj.response.data[i].postId + ");'><img src='images/social-comment.png'>" + obj.response.data[i].count_comment + comment_walpost+"</div>\
            <div class='social_report' id=" + iDforPostReport + " onclick='reportpost(this.id);'><img src='images/sociel-report.png'>"+rreportabuse_wallpost+"</div>\
           </div>";
           } else {
           profile += "<a href='#' id=" + obj.response.data[i].postId + " onclick='like_post_wall(this.id," + obj.response.data[i].count_like + ");' style='text-decoration:none; color: black;'><img src='images/sociel-liked.png'> " + obj.response.data[i].count_like + llike_wallpost+" </a></div>\
           <div class='social_comment' onclick='Postpage_wall(" + obj.response.data[i].postId + ");'><img src='images/social-comment.png'>" + obj.response.data[i].count_comment + comment_walpost+"</div>\
            <div class='social_report' id=" + iDforPostReport + " onclick='reportpost(this.id);'><img src='images/sociel-report.png'>"+rreportabuse_wallpost+"</div>\
           </div>";
           
           }
           if (obj.response.data[i].comments) {
           profile += "<div class='postContainer'>\
           <div class='socialComment'>\
           <ul>";
           var temp_for_loop = 5;
           if (obj.response.data[i].comments.length < 5) {
           temp_for_loop = obj.response.data[i].comments.length;
           }
           for (var j = 0; j < temp_for_loop; j++) {
           var id_4_comment = obj.response.data[i].postId + "$$$" + obj.response.data[i].comments[j].id;
            var profile_image_comments=obj.response.data[i].comments[j].profile_image+'?'+randomnumber;
           var iDforReport = "staticText$$$" + obj.response.data[i].comments[j].id;
           profile += "<li>\
           <div class='socialC-image'><img src=" + profile_image_comments + "></div>\
           <div class='socialcomment-txt'>\
           <div class='commentSocial'><span class='blueHead1'>" + obj.response.data[i].comments[j].user + "</span> " + obj.response.data[i].comments[j].message + " </div>\
           <div class='social_like'><a href='#' id=" + id_4_comment + " onclick='like_comment_wall(this.id," + obj.response.data[i].comments[j].count_like + ");' style='text-decoration:none; color: black;'>";
           if (obj.response.data[i].comments[j].liked == 0) {
           profile += "<img src='images/sociel-like.png'> " + obj.response.data[i].comments[j].count_like + llike_wallpost +" </a></div>\
           <div class='social_report'><a  id=" + iDforReport + " onclick='reportcomment(this.id);'><img src='images/sociel-report.png'>"+rreportabuse_wallpost+"</a></div>\
           </div>\
           </li>";
           } else {
           profile += "<img src='images/sociel-liked.png'> " + obj.response.data[i].comments[j].count_like + llike_wallpost +" </a></div>\
           <div class='social_report'><a  id=" + iDforReport + " onclick='reportcomment(this.id);'><img src='images/sociel-report.png'>"+rreportabuse_wallpost+"</a></div>\
           </div>\
           </li>";
           }
           }
           if (obj.response.data[i].comments.length > 5) {
           profile += "<div class='socialView-all' onclick='Postpage_wall(" + obj.response.data[i].postId + ");'><a href='#'>"+viewall_wallpost+"</a></div>";
           }
           profile += "</ul>\
           </div>\
           </div>";
           }
           profile+="</div>\
           </div> \
           </div>";
           }
           }
           }
           
           $('#contentHolder17').css('background', '#edf0f5');
           appendHtml(temp + profile + temp2,17,1);
           localStorage.uploadtypeWallPost = 'text';
           document.getElementById("video_add_wallpost").style.display = 'none';
           document.getElementById("image_add_wallPost").style.display = 'none';
           document.getElementById('photo_video_selection').style.display = 'none';
             $('.appypie-loader').hide();
           document.getElementById('wall_subheader').style.display='none';
           setTimeout(function() {
                      
                      checkupdate();
                      }, 60000);
           },
           error: function(response, textStatus, errorThrown) {
           setTimeout(function() {
                      
                      checkupdate();
                      }, 60000);
           $('.appypie-loader').hide();
           console.log("Error : " + JSON.stringify(response));
           console.log("Error : " + textStatus);
           console.log("Error : " + errorThrown.responseText);
           }
           });
    
}
var pageno = 1;

function openWall2(value) {
    var mediaFilesforeditprofile;
    var srcforeditprofile;
    if(Image_url_wallpost=="")
    {
        mediaFilesforeditprofile= localStorage.local_imageURI_wallpost;
        srcforeditprofile= mediaFilesforeditprofile;
    }
    else
    {
        mediaFilesforeditprofile=Image_url_wallpost;
        srcforeditprofile=mediaFilesforeditprofile;
        var randomnumber2 = Math.floor((Math.random() * 100) + 1);
        srcforeditprofile=srcforeditprofile+'?'+randomnumber2;
    }
    
    $('.appypie-loader').show();
    pageno += 1;
    var temp2 = "";
    var globalusername="globalusername"+indexvalwall;
      var temp = "<div class='load-more' id='wall_subheader' onclick='updateWall();'><a href='#'   id='wall_load_more_text'><b>"+loadmorepost_wallpost+"</b></a> <span style='display:none;' id='wall_load_more_image'><img src='images/loader.gif'></span></div>\
    <section class='wallApp-container'>\
    <div class='social-clear'></div>\
    <div class='userProfiel-box' onclick='editprofile_from_wall();'>\
    <div class='app-image'><img src="+srcforeditprofile+" style='height:100%'></div>\
    <div class='proName'><span>"+localStorage.getItem(globalusername)+"</span></div>\
    <img src='images/arrows.png' class=''>\
    </div>\
    <div class='social-btn'> \
    <div class='buttonDiv'>\
    <ul>\
    <li id='updatestatus' onclick='select_for_status_update();'>"+updatestatus_walpost+"</li>\
    <li id='addphotovideo' class='sociel-active' onclick='select_for_post_upload();' >"+addphotovideo_wallpost+"</li>\
    </ul>\
    </div>\
    </div>\
    <div class='appPost-middlepan'>\
    <div class='wallApp-video' style='display:none;' id='video_add_wallpost'>\
    <div class='updatePhoto'>\
    <textarea name='' cols='' rows='' id='captionnnWallPost_video' placeholder="+saysomething_wallpost+"'...' style='font-size:16px;'></textarea>\
    <video width='100%' height='100%' id='video_add_wallPost_show' src='images/20140725_192046.mp4' controls>\
    </video> \
    <div class='post-box'><a onclick='PostUpload();' href='#'>"+post_wallpost+"</a></div>\
    </div>\
    </div>\
    <div class='appPost-box' style='display:none;' id='image_add_wallPost'>\
    <div class='updatePhoto'>\
    <textarea name='' cols='' rows='' id='captionnnWallPost_image' placeholder="+saysomethingimage_wallpost+"'...' style='font-size:16px;'></textarea>\
    <div class='appPost-box'><img id='image_add_wallPost_show' src='images/post-img.png'></div>\
    <div class='post-box'><a href='#' onclick='PostUpload();'>"+post_wallpost+"</a></div>\
    </div>\
    </div>\
    <div class='socialUpload-file' id='photo_video_selection'  style='display:none;'>  \
    <div class='sUpload-pan'>\
    <div class='suploadFile' onclick='select_for_img_post_upload();'><a href='#'><img src='images/social-upload-img.png'></a> <span><a href='#'>"+uploadimage_wallpoast+"</a></span></div>\
    <div class='suploadFile suploadVideo' onclick='select_for_video_post_upload();'><a href='#'><img src='images/social-upload-video.png'></a> <span><a href='#'>"+uploadvideo_wallpost+"</a></span></div>\
    </div>\
    </div>\
    <div class='appPost-box' id='textUploadWall'>      	\
    <textarea name='' cols='' rows='' id='captionnnWallPost' style='font-size:16px;'></textarea>\
    <div class='post-box'><span></span> <a onclick='PostUpload();' href='#'>"+post_wallpost+"</a></div>\
    </div>";
    
    
    var wsUrll = "http://"+resellerInitial+reseller+"/services/socialwall-soap#getPosts";
    var soapRequestt = '<?xml version="1.0" encoding="utf-8"?> <soap:Envelope xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"  xmlns:xsd="http://www.w3.org/2001/XMLSchema" xmlns:soap="http://schemas.xmlsoap.org/soap/envelope/"> <soap:Body><getPosts xmlns=\"http://'+resellerInitial+reseller+'/services/socialwall-soap#getPosts\"><deviceId>' + device_Token + '</deviceId><appId>' + localStorage.getItem('applicationID') + '</appId><pageId>' + indexvalwall + '</pageId><page>'+pageno+'</page></getPosts></soap:Body></soap:Envelope>';
    console.log("SoapRequest : " + soapRequestt);
    $.ajax({
           type: "POST",
           url: wsUrll,
           contentType: "text/xml",
           dataType: "text",
           data: soapRequestt,
           success: function(data, status, req) {
           var strJSON = $(req.responseText).find("return").text();
           console.log("success setting gaurav : " + strJSON);
           
           var obj = JSON.parse(strJSON);
           if (obj.response.data != null) {
           var randomnumber = Math.floor((Math.random() * 100) + 1);
           for (var i = 0; i < obj.response.data.length; i++) {
           
           if (obj.response.page > pageno) {
           
           temp2 = "<div class='wallsection_post_div' style='margin-top:20px;'><div class='post-box' style='background: none; border: none; height: 45px; margin-top:0px; padding-top:0px;'  align='center'> <a href='#' style='font-size: 18px; float: none; font-weight: normal; padding: 5px 16px;' onclick='openWall2();'>"+showmore_wallpost+"</a></div></div></section>";
           }
           else
           {
           temp2="</section>";
           }
           if (obj.response.data[i].post_type == "video") {
           var profile_image=obj.response.data[i].profile_image+'?'+randomnumber;
           profile += "<div class='wallsection_post_div'>\
           <div class='app-image'><img src=" + profile_image + " style='height:100%'></div>\
           <div class='tpHead1'><span class='blueHead1'>" + obj.response.data[i].user + "</span>"+postedvideo_walpost+"</div>\
           <div class='postSection'>\
           <div class='postContainer border_none'>\
           <h2>" + obj.response.data[i].message + "</h2>\
           <div class='wallApp-video'>\
           <video width='100%' height='100%' controls>\
           <source src=" + obj.response.data[i].video + " type='video/mp4'>\
           </video>\
           </div>\
           </div>\
           <div class='social-like-comment'>\
           <div class='social_like'>";
           var iDforPostReport = "staticText$$$" + obj.response.data[i].postId;
           if (obj.response.data[i].liked == 0) {
           profile += "<a href='#' id=" + obj.response.data[i].postId + " onclick='like_post_wall(this.id," + obj.response.data[i].count_like + ");' style='text-decoration:none; color: black;'><img src='images/sociel-like.png'> " + obj.response.data[i].count_like + llike_wallpost+" </a></div>\
           <div class='social_comment' onclick='Postpage_wall(" + obj.response.data[i].postId + ");'><img src='images/social-comment.png'>" + obj.response.data[i].count_comment + comment_walpost+"</div>\
            <div class='social_report' id=" + iDforPostReport + " onclick='reportpost(this.id);'><img src='images/sociel-report.png'>"+rreportabuse_wallpost+"</div>\
           </div>";
           } else {
           profile += "<a href='#' id=" + obj.response.data[i].postId + " onclick='like_post_wall(this.id," + obj.response.data[i].count_like + ");' style='text-decoration:none; color: black;'><img src='images/sociel-liked.png'> " + obj.response.data[i].count_like + llike_wallpost+" </a></div>\
           <div class='social_comment' onclick='Postpage_wall(" + obj.response.data[i].postId + ");'><img src='images/social-comment.png'>" + obj.response.data[i].count_comment + comment_walpost+"</div>\
            <div class='social_report' id=" + iDforPostReport + " onclick='reportpost(this.id);'><img src='images/sociel-report.png'>"+rreportabuse_wallpost+"</div>\
           </div>";
           }
           if (obj.response.data[i].comments) {
           profile += "<div class='postContainer'>\
           <div class='socialComment'>\
           <ul>";
           var temp_for_loop = 5;
           if (obj.response.data[i].comments.length < 5) {
           temp_for_loop = obj.response.data[i].comments.length;
           }
           for (var j = 0; j < temp_for_loop; j++) {
           var id_4_comment = obj.response.data[i].postId + "$$$" + obj.response.data[i].comments[j].id;
           var profile_image_comments=obj.response.data[i].comments[j].profile_image+'?'+randomnumber;
           var iDforReport = "staticText$$$" + obj.response.data[i].comments[j].id;
           profile += "<li>\
           <div class='socialC-image'><img src=" + profile_image_comments + "></div>\
           <div class='socialcomment-txt'>\
           <div class='commentSocial'><span class='blueHead1'>" + obj.response.data[i].comments[j].user + "</span> " + obj.response.data[i].comments[j].message + " </div>\
           <div class='social_like'><a href='#' id=" + id_4_comment + " onclick='like_comment_wall(this.id," + obj.response.data[i].comments[j].count_like + ");' style='text-decoration:none; color: black;'>";
           if (obj.response.data[i].comments[j].liked == 0) {
           profile += "<img src='images/sociel-like.png'> " + obj.response.data[i].comments[j].count_like + llike_wallpost+" </a></div>\
           <div class='social_report'><a  id=" + iDforReport + " onclick='reportcomment(this.id);'><img src='images/sociel-report.png'>"+rreportabuse_wallpost+"</a></div>\
           </div>\
           </li>";
           } else {
           profile += "<img src='images/sociel-liked.png'>  " + obj.response.data[i].comments[j].count_like + llike_wallpost+" </a></div>\
           <div class='social_report'><a  id=" + iDforReport + " onclick='reportcomment(this.id);'><img src='images/sociel-report.png'>"+rreportabuse_wallpost+"</a></div>\
           </div>\
           </li>";
           }
           }
           if (obj.response.data[i].comments.length > 5) {
           profile += "<div class='socialView-all' onclick='Postpage_wall(" + obj.response.data[i].postId + ");'><a href='#'>"+viewall_wallpost+"</a></div>";
           }
           profile+="</ul>\
           </div>\
           </div>";
           }
           profile+="</div>\
           </div> \
           </div>";
           }
           
           else if (obj.response.data[i].post_type == "image") {
           var profile_image=obj.response.data[i].profile_image+'?'+randomnumber;
           profile += "<div class='wallsection_post_div'>\
           <div class='app-image'><img src=" + profile_image + " style='height:100%'></div>\
           <div class='tpHead1'><span class='blueHead1'>" + obj.response.data[i].user + "</span>"+postedphoto_wallpost+"</div>\
           <div class='postSection'>\
           <div class='postContainer border_none'>\
           <h2>" + obj.response.data[i].message + "</h2>\
           <div class='appPost-box'><img src=" + obj.response.data[i].image + "></div>\
           </div>\
           <div class='social-like-comment'>\
           <div class='social_like'>";
           var iDforPostReport = "staticText$$$" + obj.response.data[i].postId;
           if (obj.response.data[i].liked == 0) {
           profile += "<a href='#' id=" + obj.response.data[i].postId + " onclick='like_post_wall(this.id," + obj.response.data[i].count_like + ");' style='text-decoration:none; color: black;'><img src='images/sociel-like.png'> " + obj.response.data[i].count_like + llike_wallpost+" </a></div>\
           <div class='social_comment' onclick='Postpage_wall(" + obj.response.data[i].postId + ");'><img src='images/social-comment.png'>" + obj.response.data[i].count_comment + comment_walpost+"</div>\
            <div class='social_report' id=" + iDforPostReport + " onclick='reportpost(this.id);'><img src='images/sociel-report.png'>"+rreportabuse_wallpost+"</div>\
           </div>";
           } else {
           profile += "<a href='#' id=" + obj.response.data[i].postId + " onclick='like_post_wall(this.id," + obj.response.data[i].count_like + ");' style='text-decoration:none; color: black;'><img src='images/sociel-liked.png'> " + obj.response.data[i].count_like + llike_wallpost+" </a></div>\
           <div class='social_comment' onclick='Postpage_wall(" + obj.response.data[i].postId + ");'><img src='images/social-comment.png'>" + obj.response.data[i].count_comment + comment_walpost+"</div>\
            <div class='social_report' id=" + iDforPostReport + " onclick='reportpost(this.id);'><img src='images/sociel-report.png'>"+rreportabuse_wallpost+"</div>\
           </div>";
           }
           if (obj.response.data[i].comments) {
           profile += "<div class='postContainer'>\
           <div class='socialComment'>\
           <ul>";
           var temp_for_loop = 5;
           if (obj.response.data[i].comments.length < 5) {
           temp_for_loop = obj.response.data[i].comments.length;
           }
           for (var j = 0; j < temp_for_loop; j++) {
           var id_4_comment = obj.response.data[i].postId + "$$$" + obj.response.data[i].comments[j].id;
           var profile_image_comments=obj.response.data[i].comments[j].profile_image+'?'+randomnumber;
           var iDforReport = "staticText$$$" + obj.response.data[i].comments[j].id;
           profile += "<li>\
           <div class='socialC-image'><img src=" + profile_image_comments + "></div>\
           <div class='socialcomment-txt'>\
           <div class='commentSocial'><span class='blueHead1'>" + obj.response.data[i].comments[j].user + "</span> " + obj.response.data[i].comments[j].message + " </div>\
           <div class='social_like'><a href='#' id=" + id_4_comment + " onclick='like_comment_wall(this.id," + obj.response.data[i].comments[j].count_like + ");' style='text-decoration:none; color: black;'>";
           if (obj.response.data[i].comments[j].liked == 0) {
           profile += "<img src='images/sociel-like.png'> " + obj.response.data[i].comments[j].count_like + llike_wallpost+" </a></div>\
           <div class='social_report'><a  id=" + iDforReport + " onclick='reportcomment(this.id);'><img src='images/sociel-report.png'>"+rreportabuse_wallpost+"</a></div>\
           </div>\
           </li>";
           } else {
           profile += "<img src='images/sociel-liked.png'>  " + obj.response.data[i].comments[j].count_like + llike_wallpost+" </a></div>\
           <div class='social_report'><a  id=" + iDforReport + " onclick='reportcomment(this.id);'><img src='images/sociel-report.png'>"+rreportabuse_wallpost+"</a></div>\
           </div>\
           </li>";
           }
           }
           if (obj.response.data[i].comments.length > 5) {
           profile += "<div class='socialView-all' onclick='Postpage_wall(" + obj.response.data[i].postId + ");'><a href='#'>"+viewall_wallpost+"</a></div>";
           }
           profile+="</ul>\
           </div>\
           </div>";
           }
           profile+="</div>\
           </div> \
           </div>";
           }
           
           
           else {
           var profile_image=obj.response.data[i].profile_image+'?'+randomnumber;
           profile += "<div class='wallsection_post_div'>\
           <div class='app-image'><img src=" + profile_image + " style='height:100%'></div>\
           <div class='tpHead1'><span class='blueHead1'>" + obj.response.data[i].user + "</span>"+postedstatus_wallpost+"</div>\
           <div class='postSection'>\
           <div class='postContainer border_none'>\
           <p class='capsHead'></p>\
           <div class='socialPost-text'>" + obj.response.data[i].message + "</div>\
           </div>\
           <div class='social-like-comment'>\
           <div class='social_like'>";
           var iDforPostReport = "staticText$$$" + obj.response.data[i].postId;
           if (obj.response.data[i].liked == 0) {
           profile += "<a href='#' id=" + obj.response.data[i].postId + " onclick='like_post_wall(this.id," + obj.response.data[i].count_like + ");' style='text-decoration:none; color: black;'><img src='images/sociel-like.png'> " + obj.response.data[i].count_like + llike_wallpost+" </a></div>\
           <div class='social_comment' onclick='Postpage_wall(" + obj.response.data[i].postId + ");'><img src='images/social-comment.png'>" + obj.response.data[i].count_comment + comment_walpost+"</div>\
            <div class='social_report' id=" + iDforPostReport + " onclick='reportpost(this.id);'><img src='images/sociel-report.png'>"+rreportabuse_wallpost+"</div>\
           </div>";
           }
           else {
           profile += "<a href='#' id=" + obj.response.data[i].postId + " onclick='like_post_wall(this.id," + obj.response.data[i].count_like + ");' style='text-decoration:none; color: black;'><img src='images/sociel-liked.png'> " + obj.response.data[i].count_like + llike_wallpost+" </a></div>\
           <div class='social_comment' onclick='Postpage_wall(" + obj.response.data[i].postId + ");'><img src='images/social-comment.png'>" + obj.response.data[i].count_comment + comment_walpost+"</div>\
            <div class='social_report' id=" + iDforPostReport + " onclick='reportpost(this.id);'><img src='images/sociel-report.png'>"+rreportabuse_wallpost+"</div>\
           </div>";
           }
           
           if (obj.response.data[i].comments) {
           profile += "<div class='postContainer'>\
           <div class='socialComment'>\
           <ul>";
           var temp_for_loop = 5;
           if (obj.response.data[i].comments.length < 5) {
           temp_for_loop = obj.response.data[i].comments.length;
           }
           for (var j = 0; j < temp_for_loop; j++) {
           var id_4_comment = obj.response.data[i].postId + "$$$" + obj.response.data[i].comments[j].id;
           var profile_image_comments=obj.response.data[i].comments[j].profile_image+'?'+randomnumber;
           var iDforReport = "staticText$$$" + obj.response.data[i].comments[j].id;
           profile += "<li>\
           <div class='socialC-image'><img src=" + profile_image_comments + "></div>\
           <div class='socialcomment-txt'>\
           <div class='commentSocial'><span class='blueHead1'>" + obj.response.data[i].comments[j].user + "</span> " + obj.response.data[i].comments[j].message + " </div>\
           <div class='social_like'><a href='#' id=" + id_4_comment + " onclick='like_comment_wall(this.id," + obj.response.data[i].comments[j].count_like + ");' style='text-decoration:none; color: black;'>";
           if (obj.response.data[i].comments[j].liked == 0) {
           profile += "<img src='images/sociel-like.png'>  " + obj.response.data[i].comments[j].count_like + llike_wallpost+" </a></div>\
           <div class='social_report'><a  id=" + iDforReport + " onclick='reportcomment(this.id);'><img src='images/sociel-report.png'>"+rreportabuse_wallpost+"</a></div>\
           </div>\
           </li>";
           } else {
           profile += "<img src='images/sociel-liked.png'>  " + obj.response.data[i].comments[j].count_like + llike_wallpost+" </a></div>\
           <div class='social_report'><a  id=" + iDforReport + " onclick='reportcomment(this.id);'><img src='images/sociel-report.png'>"+rreportabuse_wallpost+"</a></div>\
           </div>\
           </li>";
           }
           }
           if (obj.response.data[i].comments.length > 5) {
           profile += "<div class='socialView-all' onclick='Postpage_wall(" + obj.response.data[i].postId + ");'><a href='#'>"+viewall_wallpost+"</a></div>";
           }
           profile+="</ul>\
           </div>\
           </div>";
           }
           profile+="</div>\
           </div> \
           </div>";
           }
           }
           }
           $('#contentHolder17').css('background', '#edf0f5');
           appendHtml(temp + profile + temp2,17,1);
           localStorage.uploadtypeWallPost = 'text';
           document.getElementById("video_add_wallpost").style.display = 'none';
           document.getElementById("image_add_wallPost").style.display = 'none';
           document.getElementById('photo_video_selection').style.display = 'none';
           $('.appypie-loader').hide();
           document.getElementById('wall_subheader').style.display='none';
           setTimeout(function() {
                      
                      checkupdate();
                      }, 60000);
           },
           error: function(response, textStatus, errorThrown) {
           setTimeout(function() {
                      
                      checkupdate();
                      }, 60000);
           $('.appypie-loader').hide();
           console.log("Error : " + JSON.stringify(response));
           console.log("Error : " + textStatus);
           console.log("Error : " + errorThrown.responseText);
           }
           });
    
}

function openLargeImage(url)
{
    console.log("image url---->");
    
    
    
    var imagesURL=url;
    //sessionStorage.removeItem('largeImageUrlWall');
    var position=0;
    console.log(imagesURL);
    var appName=localStorage.getItem("AppName");
    
    plugin_custom_var.getToken(
                               
                               [position,imagesURL,appName,'gallery'],
                               
                               function(token) {
                               
                              // alert(token);
                               
                               },
                               
                               function(error) {
                               
                               console.log("Error : \r\n"+error);
                               
                               }
                               
                               );
}

function Postpage_wall(postid) {
   
   
      $('.appypie-loader').show();
    var wsUrll = "http://"+resellerInitial+reseller+"/services/socialwall-soap#getPostDetail";
    var soapRequestt = '<?xml version="1.0" encoding="utf-8"?> <soap:Envelope xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"  xmlns:xsd="http://www.w3.org/2001/XMLSchema" xmlns:soap="http://schemas.xmlsoap.org/soap/envelope/"> <soap:Body><getPostDetail xmlns=\"http://'+resellerInitial+reseller+'/services/socialwall-soap#getPostDetail\"><deviceId>' + device_Token + '</deviceId><appId>' + localStorage.getItem('applicationID') + '</appId><pageId>' + indexvalwall + '</pageId><postId>' + postid + '</postId></getPostDetail></soap:Body></soap:Envelope>';
    console.log("SoapRequest : " + soapRequestt);
    $.ajax({
           type: "POST",
           url: wsUrll,
           contentType: "text/xml",
           dataType: "text",
           data: soapRequestt,
           success: function(data, status, req) {
           var strJSON = $(req.responseText).find("return").text();
           console.log("success setting gaurav : " + strJSON);
           sessionStorage.setItem("wallpageback","true");
           $('.appypie-loader').hide();
           var obj = JSON.parse(strJSON);
           var postpage = "";
          
           if (obj.response.data != null) {
            var randomnumber = Math.floor((Math.random() * 100) + 1);
           if (obj.response.data.post_type == "video") {
           var profile_image=obj.response.data.profile_image+'?'+randomnumber;
           postpage += "<section class='wallApp-container'>\
           <div class='wallsection_post_div'>\
           <div class='app-image'><img src=" + profile_image + " style='height:100%'></div>\
           <div class='tpHead1'><span class='blueHead1'>" + obj.response.data.user + "</span>"+postedvideo_walpost+"</div>\
           <div class='postSection'>\
           <div class='postContainer border_none'>\
           <h2>" + obj.response.data.message + "</h2>\
           <div class='wallApp-video'>\
           <video width='100%' height='100%' controls>\
           <source src=" + obj.response.data.video + " type='video/mp4'>\
           </video>\
           </div>\
           </div>\
           <div class='social-like-comment'>\
           <div class='social_like'>";
           var iDforPostReport = "staticTextPostPage$$$" + obj.response.data.postId;
           if (obj.response.data.liked == 0) {
           postpage += "<a href='#' id=" + obj.response.data.postId + " onclick='like_post_wall_postpage(this.id);' style='text-decoration:none; color: black;'><img src='images/sociel-like.png'></a><a id='postpage' href='#' onclick='getPeoplePostLike_postpage(this.id,"+obj.response.data.postId+");' style='text-decoration:none; color: black;'> " + obj.response.data.count_like + llike_wallpost+" </a></div><div class='social_comment' ><img src='images/social-comment.png'>" + obj.response.data.count_comment + comment_walpost+"</div><div class='social_report' id=" + iDforPostReport + " onclick='reportpostPostPage(this.id);'><img src='images/sociel-report.png'>"+rreportabuse_wallpost+"</div>\
           </div>\
           <div class='postContainer'>\
           <div class='socialComment'>\
           <ul>";
           } else {
           
           postpage += "<a href='#' id=" + obj.response.data.postId + " onclick='like_post_wall_postpage(this.id);' style='text-decoration:none; color: black;'><img src='images/sociel-liked.png'></a><a id='postpage' href='#' onclick='getPeoplePostLike_postpage(this.id,"+obj.response.data.postId+");' style='text-decoration:none; color: black;'> " + obj.response.data.count_like + llike_wallpost+" </a></div><div class='social_comment' ><img src='images/social-comment.png'>" + obj.response.data.count_comment + comment_walpost+"</div><div class='social_report' id=" + iDforPostReport + " onclick='reportpostPostPage(this.id);'><img src='images/sociel-report.png'>"+rreportabuse_wallpost+"</div>\
           </div>\
           <div class='postContainer'>\
           <div class='socialComment'>\
           <ul>";
           }
           if (obj.response.data.comments) {
           for (var j = 0; j < obj.response.data.comments.length; j++) {
           var profile_image_comments=obj.response.data.comments[j].profile_image+'?'+randomnumber;
           postpage += "<li>\
           <div class='socialC-image'><img src=" + profile_image_comments + "></div>\
           <div class='socialcomment-txt'>\
           <div class='commentSocial'><span class='blueHead1'>" + obj.response.data.comments[j].user + "</span> " + obj.response.data.comments[j].message + " </div>\
           <div class='social_like'><a href='#' id=" + obj.response.data.comments[j].id + " onclick='like_comment_wall_postpage(this.id," + obj.response.data.postId + ");' style='text-decoration:none; color: black;'>";
           var iDforReport = "staticTextPostPage$$$" + obj.response.data.comments[j].id;
           if (obj.response.data.comments[j].liked == 0) {
           postpage += "<img src='images/sociel-like.png'></a><a id='postpage' href='#' onclick='getPeopleCommentLike_postpage(this.id,"+obj.response.data.comments[j].id+");' style='text-decoration:none; color: black;'>  " + obj.response.data.comments[j].count_like + llike_wallpost+" </a></div>\
           <div class='social_report'><a  id=" + iDforReport + " onclick='reportcommentPostPage(this.id);'><img src='images/sociel-report.png'>"+rreportabuse_wallpost+"</a></div>\
           </div>\
           </li>";
           } else {
           postpage += "<img src='images/sociel-liked.png'></a><a id='postpage' href='#' onclick='getPeopleCommentLike_postpage(this.id,"+obj.response.data.comments[j].id+");' style='text-decoration:none; color: black;'>  " + obj.response.data.comments[j].count_like + llike_wallpost+" </a></div>\
           <div class='social_report'><a  id=" + iDforReport + " onclick='reportcommentPostPage(this.id);'><img src='images/sociel-report.png'>"+rreportabuse_wallpost+"</a></div>\
           </div>\
           </li>";
           }
           }
           
           }
           postpage+="</ul>\
           </div>\
           <div class='swrithcomment'>\
           <textarea name='' id='commentsTextareaPostpage_wallpage' cols='' rows=''   ></textarea>\
           </div>\
           <div class='post-box'> <a href='#' onclick='comment_wall_post("+obj.response.data.postId+");'>"+post_wallpost+"</a></div> \
           </div>\
           </div>\
           </div> \
           </div></section>";
           } else if (obj.response.data.post_type == "image") {
           
           
           console.log("post page image--->");
           var profile_image=obj.response.data.profile_image+'?'+randomnumber;
           
           var gaurav_url=obj.response.data.image;
           postpage += "<section class='wallApp-container'>\
           <div class='wallsection_post_div'>\
           <div class='app-image'><img src=" + profile_image + " style='height:100%'></div>\
           <div class='tpHead1'><span class='blueHead1'>" + obj.response.data.user + "</span>"+postedphoto_wallpost+"</div>\
           <div class='postSection'>\
           <div class='postContainer border_none'>\
           <h2>" + obj.response.data.message + "</h2>\
           <div class='appPost-box' ><img src=" + obj.response.data.image + " id=" + obj.response.data.image + "  onclick='openLargeImage(this.id);'></div>\
           </div>\
           <div class='social-like-comment'>\
           <div class='social_like'>";
           var iDforPostReport = "staticTextPostPage$$$" + obj.response.data.postId;
           if (obj.response.data.liked == 0) {
           postpage += "<a href='#' id=" + obj.response.data.postId + " onclick='like_post_wall_postpage(this.id);' style='text-decoration:none; color: black;'><img src='images/sociel-like.png'></a><a id='postpage' href='#' onclick='getPeoplePostLike_postpage(this.id,"+obj.response.data.postId+");' style='text-decoration:none; color: black;'> " + obj.response.data.count_like + llike_wallpost+" </a></div><div class='social_comment' ><img src='images/social-comment.png'>" + obj.response.data.count_comment + comment_walpost+"</div><div class='social_report' id=" + iDforPostReport + " onclick='reportpostPostPage(this.id);'><img src='images/sociel-report.png'>"+rreportabuse_wallpost+"</div>\
           </div>\
           <div class='postContainer'>\
           <div class='socialComment'>\
           <ul>";
           
            console.log("post page image--->"+postpage);
           } else {
           postpage += "<a href='#' id=" + obj.response.data.postId + " onclick='like_post_wall_postpage(this.id);' style='text-decoration:none; color: black;'><img src='images/sociel-liked.png'></a><a id='postpage' href='#' onclick='getPeoplePostLike_postpage(this.id,"+obj.response.data.postId+");' style='text-decoration:none; color: black;'> " + obj.response.data.count_like + llike_wallpost+" </a></div><div class='social_comment' ><img src='images/social-comment.png'>" + obj.response.data.count_comment + comment_walpost+"</div><div class='social_report' id=" + iDforPostReport + " onclick='reportpostPostPage(this.id);'><img src='images/sociel-report.png'>"+rreportabuse_wallpost+"</div>\
           </div>\
           <div class='postContainer'>\
           <div class='socialComment'>\
           <ul>";
           }
           if (obj.response.data.comments) {
           
           for (var j = 0; j < obj.response.data.comments.length; j++) {
           var profile_image_comments=obj.response.data.comments[j].profile_image+'?'+randomnumber;
           postpage += "<li>\
           <div class='socialC-image'><img src=" + profile_image_comments + "></div>\
           <div class='socialcomment-txt'>\
           <div class='commentSocial'><span class='blueHead1'>" + obj.response.data.comments[j].user + "</span> " + obj.response.data.comments[j].message + " </div>\
           <div class='social_like'><a href='#' id=" + obj.response.data.comments[j].id + " onclick='like_comment_wall_postpage(this.id," + obj.response.data.postId + ");' style='text-decoration:none; color: black;'>";
           var iDforReport = "staticTextPostPage$$$" + obj.response.data.comments[j].id;
           if (obj.response.data.comments[j].liked == 0) {
           postpage += "<img src='images/sociel-like.png'></a><a id='postpage' href='#' onclick='getPeopleCommentLike_postpage(this.id,"+obj.response.data.comments[j].id+");' style='text-decoration:none; color: black;'>  " + obj.response.data.comments[j].count_like + llike_wallpost+" </a></div>\
           <div class='social_report'><a  id=" + iDforReport + " onclick='reportcommentPostPage(this.id);'><img src='images/sociel-report.png'>"+rreportabuse_wallpost+"</a></div>\
           </div>\
           </li>";
           } else {
           postpage += "<img src='images/sociel-liked.png'></a><a id='postpage' href='#' onclick='getPeopleCommentLike_postpage(this.id,"+obj.response.data.comments[j].id+");' style='text-decoration:none; color: black;'>  " + obj.response.data.comments[j].count_like + llike_wallpost+" </a></div>\
           <div class='social_report'><a  id=" + iDforReport + " onclick='reportcommentPostPage(this.id);'><img src='images/sociel-report.png'>"+rreportabuse_wallpost+"</a></div>\
           </div>\
           </li>";
           }
           }
           }
           postpage+="</ul>\
           </div>\
           <div class='swrithcomment'>\
           <textarea name='' id='commentsTextareaPostpage_wallpage' cols='' rows='' style='font-size:16px;'></textarea>\
           </div>\
           <div class='post-box'> <a href='#' onclick='comment_wall_post("+obj.response.data.postId+");'>"+post_wallpost+"</a></div> \
           </div>\
           </div>\
           </div> \
           </div></section>";
           }
           else {
           
           var profile_image=obj.response.data.profile_image+'?'+randomnumber;
           postpage += "<section class='wallApp-container'>\
           <div class='wallsection_post_div'>\
           <div class='app-image'><img src=" + profile_image + " style='height:100%'></div>\
           <div class='tpHead1'><span class='blueHead1'>" + obj.response.data.user + "</span>"+postedstatus_wallpost+"</div>\
           <div class='postSection'>\
           <div class='postContainer border_none'>\
           <p class='capsHead'></p>\
           <div class='socialPost-text'>" + obj.response.data.message + "</div>\
           </div>\
           <div class='social-like-comment'>\
           <div class='social_like'>";
           
           var iDforPostReport = "staticTextPostPage$$$" + obj.response.data.postId;
           if (obj.response.data.liked == 0) {
           postpage += "<a href='#' id=" + obj.response.data.postId + " onclick='like_post_wall_postpage(this.id);' style='text-decoration:none; color: black;'><img src='images/sociel-like.png'></a><a id='postpage' href='#' onclick='getPeoplePostLike_postpage(this.id,"+obj.response.data.postId+");' style='text-decoration:none; color: black;'> " + obj.response.data.count_like + llike_wallpost+" </a></a></div><div class='social_comment' ><img src='images/social-comment.png'>" + obj.response.data.count_comment + comment_walpost+"</div><div class='social_report' id=" + iDforPostReport + " onclick='reportpostPostPage(this.id);'><img src='images/sociel-report.png'>"+rreportabuse_wallpost+"</div>\
           </div>\
           <div class='postContainer'>\
           <div class='socialComment'>\
           <ul>";
           } else {
           postpage += "<a href='#' id=" + obj.response.data.postId + " onclick='like_post_wall_postpage(this.id);' style='text-decoration:none; color: black;'><img src='images/sociel-liked.png'></a><a id='postpage' href='#' onclick='getPeoplePostLike_postpage(this.id,"+obj.response.data.postId+");' style='text-decoration:none; color: black;'> " + obj.response.data.count_like + llike_wallpost+"</a></div><div class='social_comment'><img src='images/social-comment.png'>" + obj.response.data.count_comment + comment_walpost+"</div><div class='social_report' id=" + iDforPostReport + " onclick='reportpostPostPage(this.id);'><img src='images/sociel-report.png'>"+rreportabuse_wallpost+"</div>\
           </div>\
           <div class='postContainer'>\
           <div class='socialComment'>\
           <ul>";
           }
           if (obj.response.data.comments) {
           for (var j = 0; j < obj.response.data.comments.length; j++) {
            var profile_image_comments=obj.response.data.comments[j].profile_image+'?'+randomnumber;
           postpage += "<li>\
           <div class='socialC-image'><img src=" + profile_image_comments + "></div>\
           <div class='socialcomment-txt'>\
           <div class='commentSocial'><span class='blueHead1'>" + obj.response.data.comments[j].user + "</span> " + obj.response.data.comments[j].message + " </div>\
           <div class='social_like'><a href='#' id=" + obj.response.data.comments[j].id + " onclick='like_comment_wall_postpage(this.id," + obj.response.data.postId + ");' style='text-decoration:none; color: black;'>";
           var iDforReport = "staticTextPostPage$$$" + obj.response.data.comments[j].id;
               if (obj.response.data.comments[j].liked == 0) {
               postpage += "<img src='images/sociel-like.png'></a><a id='postpage' href='#' onclick='getPeopleCommentLike_postpage(this.id,"+obj.response.data.comments[j].id+");' style='text-decoration:none; color: black;'>  " + obj.response.data.comments[j].count_like + llike_wallpost+"</a></div>\
           <div class='social_report'><a  id=" + iDforReport + " onclick='reportcommentPostPage(this.id);'><img src='images/sociel-report.png'>"+rreportabuse_wallpost+"</a></div>\
               </div>\
               </li>";
               } else {
               postpage += "<img src='images/sociel-liked.png'></a><a id='postpage' href='#' onclick='getPeopleCommentLike_postpage(this.id,"+obj.response.data.comments[j].id+");' style='text-decoration:none; color: black;'>  " + obj.response.data.comments[j].count_like + llike_wallpost+"</a></div>\
           <div class='social_report'><a  id=" + iDforReport + " onclick='reportcommentPostPage(this.id);'><img src='images/sociel-report.png'>"+rreportabuse_wallpost+"</a></div>\
               </div>\
               </li>";
               }
           }

           }
           postpage+="</ul>\
           </div>\
           <div class='swrithcomment'>\
           <textarea name='' id='commentsTextareaPostpage_wallpage' cols='' rows='' style='font-size:16px;'></textarea>\
           </div>\
           <div class='post-box'> <a href='#' onclick='comment_wall_post("+obj.response.data.postId+");'>"+post_wallpost+"</a></div> \
           </div>\
           </div>\
           </div> \
           </div></section>";
           }
           }
           if(globalbackaftercomment==0)
           {
           $('#contentHolder18').css('background', '#edf0f5');
            appendHtml(postpage,18,2);
           }
           else{
           globalbackaftercomment=0;
           $("#contentHolder18").empty();
           $("#contentHolder18").append(postpage);
           }
           
           },
           error: function(response, textStatus, errorThrown) {
           sessionStorage.setItem("wallpageback","true");
           $('.appypie-loader').hide();
           console.log("Error : " + JSON.stringify(response));
           console.log("Error : " + textStatus);
           console.log("Error : " + errorThrown.responseText);
           }
           });
}
var globalbackaftercomment=0;
function comment_wall_post(postid)
{
    var commentsTextareaPostpage_wallpage=document.getElementById("commentsTextareaPostpage_wallpage").value;
    commentsTextareaPostpage_wallpage=$.trim(commentsTextareaPostpage_wallpage);
    if(commentsTextareaPostpage_wallpage!="")
    {
        $('.appypie-loader').show();
        var wsUrll = "http://"+resellerInitial+reseller+"/services/socialwall-soap#saveComment";
        var soapRequestt = '<?xml version="1.0" encoding="utf-8"?> <soap:Envelope xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"  xmlns:xsd="http://www.w3.org/2001/XMLSchema" xmlns:soap="http://schemas.xmlsoap.org/soap/envelope/"> <soap:Body><saveComment xmlns=\"http://'+resellerInitial+reseller+'/services/socialwall-soap#saveComment\"><deviceId>' + device_Token + '</deviceId><appId>' + localStorage.getItem('applicationID') + '</appId><pageId>' + indexvalwall + '</pageId><postId>' + postid + '</postId><message>'+document.getElementById("commentsTextareaPostpage_wallpage").value+'</message></saveComment></soap:Body></soap:Envelope>';
        
        console.log("SoapRequest : "+ soapRequestt);
        $.ajax({
               type: "POST",
               url: wsUrll,
               contentType: "text/xml",
               dataType: "text",
               data: soapRequestt,
               success: function(data, status, req)
               {
               var strJSON = $(req.responseText).find("return").text();
               console.log("success postpage gaurav : "+req);
               window.scrollTo(document.body.scrollLeft, document.body.scrollTop);
               globalbackaftercomment=1;
               Postpage_wall(postid);
               setTimeout(function() {
                          
                          checkupdate();
                          }, 60000);
               },
               error: function(response, textStatus, errorThrown)
               {
               setTimeout(function() {
                          
                          checkupdate();
                          }, 60000);
               $('.appypie-loader').hide();
               console.log("Error : "+JSON.stringify(response));
               console.log("Error : "+textStatus);
               console.log("Error : "+errorThrown.responseText);
               }
               });
    }
    else
    {
       
        navigator.notification.alert(
                                     message,  // message
                                     alertDismissed,         // callback
                                     message_wallpost,            // title
                                     ok_wallpost                  // buttonName
                                     );
        setTimeout(function() {
                   
                   checkupdate();
                   }, 60000);
    }
    
}
function like_post_wall(postid, nooflikes) {
    var wsUrll ="http://"+resellerInitial+reseller+"/services/socialwall-soap#saveLike";
    var soapRequestt = '<?xml version="1.0" encoding="utf-8"?> <soap:Envelope xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"  xmlns:xsd="http://www.w3.org/2001/XMLSchema" xmlns:soap="http://schemas.xmlsoap.org/soap/envelope/"> <soap:Body><saveLike xmlns=\"http://'+resellerInitial+reseller+'/services/socialwall-soap#saveLike\"><deviceId>' + device_Token + '</deviceId><appId>' + localStorage.getItem('applicationID') + '</appId><pageId>' + indexvalwall + '</pageId><postId>' + postid + '</postId></saveLike></soap:Body></soap:Envelope>';
    console.log("SoapRequest : " + soapRequestt);
    $.ajax({
           type: "POST",
           url: wsUrll,
           contentType: "text/xml",
           dataType: "text",
           data: soapRequestt,
           success: function(data, status, req) {
           var strJSON = $(req.responseText).find("return").text();
           console.log("success setting gaurav : " + strJSON);
           
           var obj = JSON.parse(strJSON);
           
           if (obj.msg == "liked") {
           
           var temp_likes = document.getElementById(postid).innerHTML;
           var temp_likes2 = temp_likes.split("> ");
           var temp_likes3 = temp_likes2[1].split(" ");
           nooflikes = temp_likes3[0];
           nooflikes = parseInt(nooflikes);
           nooflikes = nooflikes + 1;
           document.getElementById(postid).innerHTML = "<img src='images/sociel-liked.png'> " + nooflikes + llike_wallpost;
           } else {
           var temp_likes = document.getElementById(postid).innerHTML;
           var temp_likes2 = temp_likes.split("> ");
           var temp_likes3 = temp_likes2[1].split(" ");
           nooflikes = temp_likes3[0];
           nooflikes = parseInt(nooflikes);
           nooflikes = nooflikes - 1;
           document.getElementById(postid).innerHTML = "<img src='images/sociel-like.png'> " + nooflikes + llike_wallpost;
           }
           setTimeout(function() {
                      
                      checkupdate();
                      }, 60000);
           },
           error: function(response, textStatus, errorThrown) {
           setTimeout(function() {
                      
                      checkupdate();
                      }, 60000);
           console.log("Error : " + JSON.stringify(response));
           console.log("Error : " + textStatus);
           console.log("Error : " + errorThrown.responseText);
           }
           });
}

function like_comment_wall(mergeid, nooflikes) {
    var commentid = mergeid.split("$$$");
    var wsUrll = "http://"+resellerInitial+reseller+"/services/socialwall-soap#saveCommentLike";
    var soapRequestt = '<?xml version="1.0" encoding="utf-8"?> <soap:Envelope xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"  xmlns:xsd="http://www.w3.org/2001/XMLSchema" xmlns:soap="http://schemas.xmlsoap.org/soap/envelope/"> <soap:Body><saveCommentLike xmlns=\"http://'+resellerInitial+reseller+'/services/socialwall-soap#saveCommentLike\"><deviceId>' + device_Token + '</deviceId><appId>' + localStorage.getItem('applicationID') + '</appId><pageId>' + indexvalwall + '</pageId><commentId>' + commentid[1] + '</commentId></saveCommentLike></soap:Body></soap:Envelope>';
    console.log("SoapRequest : " + soapRequestt);
    $.ajax({
           type: "POST",
           url: wsUrll,
           contentType: "text/xml",
           dataType: "text",
           data: soapRequestt,
           success: function(data, status, req) {
           var strJSON = $(req.responseText).find("return").text();
           console.log("success setting gaurav : " + strJSON);
           
           var obj = JSON.parse(strJSON);
           
           if (obj.msg == "liked") {
           
           var temp_likes = document.getElementById(mergeid).innerHTML;
           var temp_likes2 = temp_likes.split("> ");
           var temp_likes3 = temp_likes2[1].split(" ");
           nooflikes = temp_likes3[0];
           nooflikes = parseInt(nooflikes)
           nooflikes = nooflikes + 1;
           document.getElementById(mergeid).innerHTML = "<img src='images/sociel-liked.png'> " + nooflikes + llike_wallpost;
           } else {
           var temp_likes = document.getElementById(mergeid).innerHTML;
           var temp_likes2 = temp_likes.split("> ");
           var temp_likes3 = temp_likes2[1].split(" ");
           nooflikes = temp_likes3[0];
           nooflikes = parseInt(nooflikes)
           nooflikes = nooflikes - 1;
           document.getElementById(mergeid).innerHTML = "<img src='images/sociel-like.png'> " + nooflikes + llike_wallpost;
           }
           setTimeout(function() {
                      
                      checkupdate();
                      }, 60000);
           },
           error: function(response, textStatus, errorThrown) {
           setTimeout(function() {
                      
                      checkupdate();
                      }, 60000);
           console.log("Error : " + JSON.stringify(response));
           console.log("Error : " + textStatus);
           console.log("Error : " + errorThrown.responseText);
           }
           });
}
function like_post_wall_postpage(postid) {
    var wsUrll = "http://"+resellerInitial+reseller+"/services/socialwall-soap#saveLike";
    var soapRequestt = '<?xml version="1.0" encoding="utf-8"?> <soap:Envelope xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"  xmlns:xsd="http://www.w3.org/2001/XMLSchema" xmlns:soap="http://schemas.xmlsoap.org/soap/envelope/"> <soap:Body><saveLike xmlns=\"http://'+resellerInitial+reseller+'/services/socialwall-soap#saveLike\"><deviceId>' + device_Token + '</deviceId><appId>' + localStorage.getItem('applicationID') + '</appId><pageId>' + indexvalwall + '</pageId><postId>' + postid + '</postId></saveLike></soap:Body></soap:Envelope>';
    console.log("SoapRequest : " + soapRequestt);
    $.ajax({
           type: "POST",
           url: wsUrll,
           contentType: "text/xml",
           dataType: "text",
           data: soapRequestt,
           success: function(data, status, req) {
           var strJSON = $(req.responseText).find("return").text();
           console.log("success setting gaurav : " + strJSON);
           
           var obj = JSON.parse(strJSON);
           
           Postpage_wall(postid);
           },
           error: function(response, textStatus, errorThrown) {
           console.log("Error : " + JSON.stringify(response));
           console.log("Error : " + textStatus);
           console.log("Error : " + errorThrown.responseText);
           }
           });
}

function like_comment_wall_postpage(commentid,postid) {
    var wsUrll = "http://"+resellerInitial+reseller+"/services/socialwall-soap#saveCommentLike";
    var soapRequestt = '<?xml version="1.0" encoding="utf-8"?> <soap:Envelope xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"  xmlns:xsd="http://www.w3.org/2001/XMLSchema" xmlns:soap="http://schemas.xmlsoap.org/soap/envelope/"> <soap:Body><saveCommentLike xmlns=\"http://'+resellerInitial+reseller+'/services/socialwall-soap#saveCommentLike\"><deviceId>' + device_Token + '</deviceId><appId>' + localStorage.getItem('applicationID') + '</appId><pageId>' + indexvalwall + '</pageId><commentId>' + commentid + '</commentId></saveCommentLike></soap:Body></soap:Envelope>';
    console.log("SoapRequest : " + soapRequestt);
    $.ajax({
           type: "POST",
           url: wsUrll,
           contentType: "text/xml",
           dataType: "text",
           data: soapRequestt,
           success: function(data, status, req) {
           var strJSON = $(req.responseText).find("return").text();
           console.log("success setting gaurav : " + strJSON);
           
           var obj = JSON.parse(strJSON);
           
           if (obj.msg == "liked") {
           Postpage_wall(postid);
           } else {
           Postpage_wall(postid);
           }
           },
           error: function(response, textStatus, errorThrown) {
           console.log("Error : " + JSON.stringify(response));
           console.log("Error : " + textStatus);
           console.log("Error : " + errorThrown.responseText);
           }
           });
}

function getPeoplePostLike_postpage(tempvar,postid)
{
	
	
     
    $('.appypie-loader').show();
    var wsUrll = "http://"+resellerInitial+reseller+"/services/socialwall-soap#getPeoplePostLike";
    var soapRequestt = '<?xml version="1.0" encoding="utf-8"?> <soap:Envelope xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"  xmlns:xsd="http://www.w3.org/2001/XMLSchema" xmlns:soap="http://schemas.xmlsoap.org/soap/envelope/"> <soap:Body><getPeoplePostLike xmlns=\"http://'+resellerInitial+reseller+'/services/socialwall-soap#getPeoplePostLike\"><deviceId>' + device_Token + '</deviceId><appId>' + localStorage.getItem('applicationID') + '</appId><pageId>' + indexvalwall + '</pageId><postId>'+postid+'</postId></getPeoplePostLike></soap:Body></soap:Envelope>';
    console.log("SoapRequest : " + soapRequestt);
    $.ajax({
           type: "POST",
           url: wsUrll,
           contentType: "text/xml",
           dataType: "text",
           data: soapRequestt,
           success: function(data, status, req) {
           var strJSON = $(req.responseText).find("return").text();
           console.log("success setting gaurav : " + strJSON);
           $('.appypie-loader').hide();
           var userslike="";
           strJSON = JSON.parse(strJSON);
           userslike +="<div class='socialWall-main-layout'>\
           <section class='wallApp-container'>\
           <div class='appPost-middlepan'>\
           <div class='wallsection_post_div section_list_page'>\
           <h2>"+peoplelikegg_wallpost+"</h2>\
           <div class='postSection'>\
           <div class='postContainer'>\
           <div class='socialComment'>\
           <ul>";
           for(var i=0;i<strJSON.length;i++)
           {
               userslike +="<li>\
               <div class='socialC-image'><img src="+strJSON[i].profileImage+"></div>\
               <div class='socialcomment-txt'>\
               <div class='commentSocial'><span class='blueHead1'>"+strJSON[i].name+"</span></div>\
               </div>\
               </li>";
           }

          userslike +=" </ul>\
           </div>\
           </div></div></div></div>\
           </section>\
           </div>";
           if(tempvar=="postpage")
           {
           $('#contentHolder19').css('background', '#edf0f5');
           appendHtml(userslike,19,3);
           }
           else
           {
           $('#contentHolder18').css('background', '#edf0f5');
           appendHtml(userslike,18,3);
           }
           sessionStorage.setItem("wallpageback","false");
           sessionStorage.setItem("wallpageback_like","true");
           },
           error: function(response, textStatus, errorThrown) {
           
           $('.appypie-loader').hide();
           console.log("Error : " + JSON.stringify(response));
           console.log("Error : " + textStatus);
           console.log("Error : " + errorThrown.responseText);
           }
           });
}

function getPeopleCommentLike_postpage(tempvar,commentid)
{
    $('.appypie-loader').show();
    var wsUrll = "http://"+resellerInitial+reseller+"/services/socialwall-soap#getPeopleCommentLike";
    var soapRequestt = '<?xml version="1.0" encoding="utf-8"?> <soap:Envelope xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"  xmlns:xsd="http://www.w3.org/2001/XMLSchema" xmlns:soap="http://schemas.xmlsoap.org/soap/envelope/"> <soap:Body><getPeopleCommentLike xmlns=\"http://'+resellerInitial+reseller+'/services/socialwall-soap#getPeopleCommentLike\"><deviceId>' + device_Token + '</deviceId><appId>' + localStorage.getItem('applicationID') + '</appId><pageId>' + indexvalwall + '</pageId><commentId>'+commentid+'</commentId></getPeopleCommentLike></soap:Body></soap:Envelope>';
    console.log("SoapRequest : " + soapRequestt);
    $.ajax({
           type: "POST",
           url: wsUrll,
           contentType: "text/xml",
           dataType: "text",
           data: soapRequestt,
           success: function(data, status, req) {
           var strJSON = $(req.responseText).find("return").text();
           console.log("success setting gaurav : " + strJSON);
           $('.appypie-loader').hide();
           var userslike="";
           strJSON = JSON.parse(strJSON);
           userslike +="<div class='socialWall-main-layout'>\
           <section class='wallApp-container'>\
           <div class='appPost-middlepan'>\
           <div class='wallsection_post_div section_list_page'>\
           <h2>"+peoplelikegg_wallpost+"</h2>\
           <div class='postSection'>\
           <div class='postContainer'>\
           <div class='socialComment'>\
           <ul>";
           for(var i=0;i<strJSON.length;i++)
           {
           userslike +="<li>\
           <div class='socialC-image'><img src="+strJSON[i].profileImage+"></div>\
           <div class='socialcomment-txt'>\
           <div class='commentSocial'><span class='blueHead1'>"+strJSON[i].name+"</span></div>\
           </div>\
           </li>";
           }
           
           userslike +=" </ul>\
           </div>\
           </div></div></div></div>\
           </section>\
           </div>";
           if(tempvar=="postpage")
           {
           $('#contentHolder19').css('background', '#edf0f5');
           appendHtml(userslike,19,3);
           }
           else
           {
           $('#contentHolder18').css('background', '#edf0f5');
           appendHtml(userslike,18,3);
           }
           sessionStorage.setItem("wallpageback","false");
            sessionStorage.setItem("wallpageback_like","true");
           
           },
           error: function(response, textStatus, errorThrown) {
           $('.appypie-loader').hide();
           console.log("Error : " + JSON.stringify(response));
           console.log("Error : " + textStatus);
           console.log("Error : " + errorThrown.responseText);
           }
           });
}

function select_for_post_upload() {
    
     $("#updatestatus").addClass("sociel-active")
    $("#addphotovideo").removeClass();
    document.getElementById('photo_video_selection').style.display = 'block';
    document.getElementById("textUploadWall").style.display = 'none';
    document.getElementById("video_add_wallpost").style.display = 'none';
    document.getElementById("image_add_wallPost").style.display = 'none';
    
}
function select_for_status_update() {
    
    localStorage.uploadtypeWallPost = 'text';
    $("#addphotovideo").addClass("sociel-active")
    $("#updatestatus").removeClass();
    document.getElementById("textUploadWall").style.display = 'block';
    document.getElementById('photo_video_selection').style.display = 'none';
    document.getElementById("video_add_wallpost").style.display = 'none';
    document.getElementById("image_add_wallPost").style.display = 'none';
    
}

//upload post
function select_for_img_post_upload() {
    navigator.notification.confirm(
    		selecupload_wallpost+'!', // message
                                   onConfirm_img_for_post_upload, // callback to invoke with index of button pressed
                                   message_wallpost, // title
                                   'Camera,Gallery,Cancel'
                                   );
}

function onConfirm_img_for_post_upload(buttonIndex) {
    if (buttonIndex == 2) {
        var options = {
        quality: 50,
        sourceType: Camera.PictureSourceType.PHOTOLIBRARY,
        destinationType: navigator.camera.DestinationType.FILE_URI,
        }
        navigator.camera.getPicture(win_lib_image_post_upload, fail_wallpost, options);
    } else if (buttonIndex == 1) {
        Image_capture_post_upload();
    }
    else
    {
        
    }
}

function win_lib_image_post_upload(imageURI) {
    setTimeout(function(){ window.location="hidestatusbar:";},100);
    localStorage.local_imageURI_wallPost_post = imageURI;
    show_image_on_box_wallpost_post();
}

function Image_capture_post_upload() {
    var options = {
    limit: 1
    };
    navigator.device.capture.captureImage(captureSuccess_img_post_upload, captureError_wallpost, options);
}
function captureSuccess_img_post_upload(mediaFiles) {
   // setTimeout(function(){ window.location="hidestatusbar:";},100);
   mediaFiles = goToNativeForRotation(mediaFiles[0].fullPath);
    localStorage.local_imageURI_wallPost_post = mediaFiles;
	 show_image_on_box_wallpost_post();
}

function show_image_on_box_wallpost_post() {
    localStorage.uploadtypeWallPost = 'image';
    //setTimeout(function(){ window.location="hidestatusbar:";},100);
    var mediaFiles = goToNativeForRotation(localStorage.local_imageURI_wallPost_post);
    document.getElementById("video_add_wallpost").style.display = 'none';
    document.getElementById("image_add_wallPost").style.display = 'block';
    document.getElementById('photo_video_selection').style.display = 'none';
    document.getElementById('image_add_wallPost_show').src = mediaFiles;
}

function select_for_video_post_upload() {
    navigator.notification.confirm(
    		selecupload_wallpost+'!', // message
                                   onConfirm_video_for_post_upload, // callback to invoke with index of button pressed
                                   message_wallpost, // title
                                   'Camera,Gallery,Cancel'
                                   );
}

function onConfirm_video_for_post_upload(buttonIndex) {
    if (buttonIndex == 2) {
        
        var options = {
        quality: 100,
        destinationType: navigator.camera.DestinationType.FILE_URI,
        sourceType: navigator.camera.PictureSourceType.PHOTOLIBRARY,
        mediaType: navigator.camera.MediaType.VIDEO
        }
        navigator.camera.getPicture(win_lib_video_post_upload, fail_wallpost, options);
    } else if (buttonIndex == 1){
        video_capture_post_upload();
    }
    else{
        
    }
}

function win_lib_video_post_upload(videoURI) {
    setTimeout(function(){ window.location="hidestatusbar:";},100);
    localStorage.local_mediaFiles_WallPost = videoURI;
    show_video_on_box_wallPost();
}

function video_capture_post_upload() {
    var options = {
    correctOrientation: false,
    destinationType: Camera.DestinationType.DATA_URL,
    duration: 30
    };
    navigator.device.capture.captureVideo(captureSuccess_video_post_upload, captureError_wallpost, options);
}

function captureSuccess_video_post_upload(mediaFiles) {
    setTimeout(function(){ window.location="hidestatusbar:";},100);
    localStorage.local_mediaFiles_WallPost = mediaFiles[0].fullPath;
    show_video_on_box_wallPost();
}

function show_video_on_box_wallPost() {
    localStorage.uploadtypeWallPost = 'video';
    var mediaFiles = localStorage.local_mediaFiles_WallPost;
    document.getElementById("image_add_wallPost").style.display = 'none';
    document.getElementById("video_add_wallpost").style.display = 'block';
    document.getElementById('photo_video_selection').style.display = 'none';
    document.getElementById('video_add_wallPost_show').src = mediaFiles;
}

function PostUpload() {
    
    $('.appypie-loader').show();
    if (localStorage.getItem('uploadtypeWallPost') == 'video') {
        
            var mediaFiles = localStorage.local_mediaFiles_WallPost;
            var fileName = '23456.mp4';
            var fileURI = mediaFiles;
            var ft = new FileTransfer();
            var options = new FileUploadOptions();
            options.fileKey = "file";
            options.fileName = fileName;
            options.mimeType = "text/plain";
            var params = new Object();
            params.appId = localStorage.getItem('applicationID');
            params.deviceId = device_Token;
            params.pageId = indexvalwall;
            params.caption = document.getElementById('captionnnWallPost_video').value;
            params.type = 'video';
            options.params = params;
            ft.upload(fileURI, encodeURI("http://"+resellerInitial+reseller+"/socialwall/savepostvideo"), successFn, errorFn, options);
        
    } else if (localStorage.getItem('uploadtypeWallPost') == 'image') {
            var mediaFiles = localStorage.local_imageURI_wallPost_post;
            var fileName = '23456.jpg';
            var fileURI;
            fileURI = mediaFiles;
            var ft = new FileTransfer();
            var options = new FileUploadOptions();
            options.fileKey = "file";
            options.fileName = fileName;
            options.mimeType = "text/plain";
            var params = new Object();
            params.appId = localStorage.getItem('applicationID');
            params.deviceId = device_Token;
            params.pageId = indexvalwall;
            params.caption = document.getElementById('captionnnWallPost_image').value;
            params.type = 'image';
            options.params = params;
            ft.upload(fileURI, encodeURI("http://"+resellerInitial+reseller+"/socialwall/savepostvideo"), successFn_image, errorFn, options);
    } else {
        
        var tempcaptionnnWallPost=document.getElementById('captionnnWallPost').value;
        tempcaptionnnWallPost=$.trim(tempcaptionnnWallPost);		
		var captionnnWallPost=tempcaptionnnWallPost.split("&").join("$$$");
		
        if (captionnnWallPost != "") {
            
            var wsUrll = "http://"+resellerInitial+reseller+"/services/socialwall-soap#savePost";
            var soapRequestt = '<?xml version="1.0" encoding="utf-8"?> <soap:Envelope xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"  xmlns:xsd="http://www.w3.org/2001/XMLSchema" xmlns:soap="http://schemas.xmlsoap.org/soap/envelope/"> <soap:Body><savePost xmlns=\"http://'+resellerInitial+reseller+'/services/socialwall-soap#savePost\"><deviceId>' + device_Token + '</deviceId><appId>' + localStorage.getItem('applicationID') + '</appId><pageId>' + indexvalwall + '</pageId><message>' + captionnnWallPost + '</message></savePost></soap:Body></soap:Envelope>';
            console.log("SoapRequest : " + soapRequestt);
            $.ajax({
                   type: "POST",
                   url: wsUrll,
                   contentType: "text/xml",
                   dataType: "text",
                   data: soapRequestt,
                   success: function(data, status, req) {
                   var strJSON = $(req.responseText).find("return").text();
                   console.log("success textupload gaurav : " + strJSON);
                   $('.appypie-loader').hide();
                   document.getElementById("video_add_wallpost").style.display = 'none';
                   document.getElementById("image_add_wallPost").style.display = 'none';
                   document.getElementById('photo_video_selection').style.display = 'none';
                   localStorage.uploadtypeWallPost = 'text';
                   openWall(true);
                   },
                   error: function(response, textStatus, errorThrown) {
                   $('.appypie-loader').hide();
                   setTimeout(function() {
                              
                              checkupdate();
                              }, 60000);
                   console.log("Error : " + JSON.stringify(response));
                   console.log("Error : " + textStatus);
                   console.log("Error : " + errorThrown.responseText);
                   }
                   });
        } else {
           
            navigator.notification.alert(
            		messagefff_wallpost, // message
                                         alertDismissed, // callback
                                         message_wallpost, // title
                                         ok_wallpost // buttonName
                                         );
            $('.appypie-loader').hide();
        }
    }
    
}

function successFn(r) {
    console.log("Response = " + r.response);
    $('.appypie-loader').hide();
    if (r.response == 'success') {
        openWall(true);
        var message = 'successfully Uploaded!';
        document.getElementById("video_add_wallpost").style.display = 'none';
        document.getElementById("image_add_wallPost").style.display = 'none';
        document.getElementById('photo_video_selection').style.display = 'none';
        localStorage.uploadtypeWallPost = 'text';
        // window.location.href='main.html';
    } else {
       
        navigator.notification.alert(
        		messagesome_wallpost, // message
                                     alertDismissed, // callback
                                     warning_wallpost, // title
                                     ok_wallpost // buttonName
                                     );
        setTimeout(function() {
                   
                   checkupdate();
                   }, 60000);
        document.getElementById("video_add_wallpost").style.display = 'none';
        document.getElementById("image_add_wallPost").style.display = 'none';
        document.getElementById('photo_video_selection').style.display = 'none';
        localStorage.uploadtypeWallPost = 'text';
        //window.location.href='main.html';
    }
}

function successFn_image(r) {
    $('.appypie-loader').hide();
    console.log("Response = " + r.response);
    if (r.response == 'success') {
        $('.appypie-loader').hide();
        openWall(true);
        document.getElementById("video_add_wallpost").style.display = 'none';
        document.getElementById("image_add_wallPost").style.display = 'none';
        document.getElementById('photo_video_selection').style.display = 'none';
        localStorage.uploadtypeWallPost = 'text';
    }
    else
    {
        setTimeout(function() {
                   
                   checkupdate();
                   }, 60000);
        $('.appypie-loader').hide();
    }
}

function errorFn(error) {
    setTimeout(function() {
               
               checkupdate();
               }, 60000);
    $('.appypie-loader').hide();
  //  alert("An error has occurred: Code = " + error.code);
    console.log("upload error source " + error.source);
    console.log("upload error target " + error.target);
}

function reportpost(Staticpostid)
{
    $('.appypie-loader').show();
   var postidd = Staticpostid.split("$$$");
    postid=postidd[1];
    var wsUrll = "http://"+resellerInitial+reseller+"/services/socialwall-soap#report";
    var soapRequestt = '<?xml version="1.0" encoding="utf-8"?> <soap:Envelope xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"  xmlns:xsd="http://www.w3.org/2001/XMLSchema" xmlns:soap="http://schemas.xmlsoap.org/soap/envelope/"> <soap:Body><report xmlns=\"http://'+resellerInitial+reseller+'/services/socialwall-soap#report\"><deviceId>' + device_Token + '</deviceId><appId>' + localStorage.getItem('applicationID') + '</appId><pageId>' + indexvalwall + '</pageId><reportId>' + postid + '</reportId><reportType>post</reportType></report></soap:Body></soap:Envelope>';
    console.log("SoapRequest : " + soapRequestt);
    $.ajax({
           type: "POST",
           url: wsUrll,
           contentType: "text/xml",
           dataType: "text",
           data: soapRequestt,
           success: function(data, status, req) {
           var strJSON = $(req.responseText).find("return").text();
           console.log("success textupload gaurav : " + strJSON);
           $('.appypie-loader').hide();
           document.getElementById(Staticpostid).innerHTML="<img src='images/sociel-reported.png'>" + rreportabuse_wallpost;
           },
           error: function(response, textStatus, errorThrown) {
           $('.appypie-loader').hide();
           console.log("Error : " + JSON.stringify(response));
           console.log("Error : " + textStatus);
           console.log("Error : " + errorThrown.responseText);
           }
           });
}
function reportcomment(Staticcommentid)
{
    $('.appypie-loader').show();
    var commentidd = Staticcommentid.split("$$$");
    var commentid = commentidd[1];
    var wsUrll = "http://"+resellerInitial+reseller+"/services/socialwall-soap#report";
    var soapRequestt = '<?xml version="1.0" encoding="utf-8"?> <soap:Envelope xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"  xmlns:xsd="http://www.w3.org/2001/XMLSchema" xmlns:soap="http://schemas.xmlsoap.org/soap/envelope/"> <soap:Body><report xmlns=\"http://'+resellerInitial+reseller+'/services/socialwall-soap#report\"><deviceId>' + device_Token + '</deviceId><appId>' + localStorage.getItem('applicationID') + '</appId><pageId>' + indexvalwall + '</pageId><reportId>' + commentid + '</reportId><reportType>comment</reportType></report></soap:Body></soap:Envelope>';
    console.log("SoapRequest : " + soapRequestt);
    $.ajax({
           type: "POST",
           url: wsUrll,
           contentType: "text/xml",
           dataType: "text",
           data: soapRequestt,
           success: function(data, status, req) {
           var strJSON = $(req.responseText).find("return").text();
           console.log("success textupload gaurav : " + strJSON);
           $('.appypie-loader').hide();
           document.getElementById(Staticcommentid).innerHTML="<img src='images/sociel-reported.png'>"+rreportabuse_wallpost;
           },
           error: function(response, textStatus, errorThrown) {
           $('.appypie-loader').hide();
           console.log("Error : " + JSON.stringify(response));
           console.log("Error : " + textStatus);
           console.log("Error : " + errorThrown.responseText);
           }
           });
}

function reportpostPostPage(Staticpostid)
{
    $('.appypie-loader').show();
    var postidd = Staticpostid.split("$$$");
    postid=postidd[1];
    var wsUrll = "http://"+resellerInitial+reseller+"/services/socialwall-soap#report";
    var soapRequestt = '<?xml version="1.0" encoding="utf-8"?> <soap:Envelope xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"  xmlns:xsd="http://www.w3.org/2001/XMLSchema" xmlns:soap="http://schemas.xmlsoap.org/soap/envelope/"> <soap:Body><report xmlns=\"http://'+resellerInitial+reseller+'/services/socialwall-soap#report\"><deviceId>' + device_Token + '</deviceId><appId>' + localStorage.getItem('applicationID') + '</appId><pageId>' + indexvalwall + '</pageId><reportId>' + postid + '</reportId><reportType>post</reportType></report></soap:Body></soap:Envelope>';
    console.log("SoapRequest : " + soapRequestt);
    $.ajax({
           type: "POST",
           url: wsUrll,
           contentType: "text/xml",
           dataType: "text",
           data: soapRequestt,
           success: function(data, status, req) {
           var strJSON = $(req.responseText).find("return").text();
           console.log("success textupload gaurav : " + strJSON);
           $('.appypie-loader').hide();
           document.getElementById(Staticpostid).innerHTML="<img src='images/sociel-reported.png'>"+rreportabuse_wallpost;
           },
           error: function(response, textStatus, errorThrown) {
           $('.appypie-loader').hide();
           console.log("Error : " + JSON.stringify(response));
           console.log("Error : " + textStatus);
           console.log("Error : " + errorThrown.responseText);
           }
           });
}
function reportcommentPostPage(Staticcommentid)
{
    $('.appypie-loader').show();
    var commentidd = Staticcommentid.split("$$$");
    var commentid = commentidd[1];
    var wsUrll = "http://"+resellerInitial+reseller+"/services/socialwall-soap#report";
    var soapRequestt = '<?xml version="1.0" encoding="utf-8"?> <soap:Envelope xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"  xmlns:xsd="http://www.w3.org/2001/XMLSchema" xmlns:soap="http://schemas.xmlsoap.org/soap/envelope/"> <soap:Body><report xmlns=\"http://'+resellerInitial+reseller+'/services/socialwall-soap#report\"><deviceId>' + device_Token + '</deviceId><appId>' + localStorage.getItem('applicationID') + '</appId><pageId>' + indexvalwall + '</pageId><reportId>' + commentid + '</reportId><reportType>comment</reportType></report></soap:Body></soap:Envelope>';
    console.log("SoapRequest : " + soapRequestt);
    $.ajax({
           type: "POST",
           url: wsUrll,
           contentType: "text/xml",
           dataType: "text",
           data: soapRequestt,
           success: function(data, status, req) {
           var strJSON = $(req.responseText).find("return").text();
           console.log("success textupload gaurav : " + strJSON);
           $('.appypie-loader').hide();
           document.getElementById(Staticcommentid).innerHTML="<img src='images/sociel-reported.png'>"+rreportabuse_wallpost;
           },
           error: function(response, textStatus, errorThrown) {
           $('.appypie-loader').hide();
           console.log("Error : " + JSON.stringify(response));
           console.log("Error : " + textStatus);
           console.log("Error : " + errorThrown.responseText);
           }
           });
}
function editprofile_from_wall()
{
    flagforeditprofile=1;
    
    localStorage.removeItem(indexvalwall);
    getWallPost(sessionStorage.getItem("indexValue"));
}