/*start facebook login*/

var social_menu_slide_main_menu_soicalapp = "Main Menu";
var social_login_fb_twitter_msg_socialapp = "Not able to login try again!";
var social_login_fb_alert_socialapp = "Alert";
var social_login_fb_alert_ok_socialapp = "OK";
var get_social_login_dont_have_account_yet_socialapp = "Don't have an account yet";
var get_social_login_signup_now_socialapp = "Sign Up Now";
var get_social_login_email_id_socialapp = "Email-Id";
var get_social_login_password_socialapp = "Password";
var get_social_login_forgot_pass_socialapp = "Forgot your password ?";
var get_social_login_placeholder_emailid_socialapp = "Email-Id";
var get_social_login_placeholder_password_socialapp = "Password";
var email_already_exist_socialapp = "Email id already exist!";
var enter_valid_email_id_socialapp = "Please Enter a valid Email Id!";
var please_enter_pass_socialapp = "Please enter password!";
var please_enter_email_socialapp = "Please enter email!";
var blocked_user_contact_admin_socialapp = "This user has been blocked. Please contact to Administrator";
var alert_warning_socialapp = "Warning";
var invalid_nameandpass_socialapp = "Invalid User name or password";
var invalid_credential_socialapp = "Invalid Credential";
var user_blocked_socialapp = "You have been blocked!";
var alert_message_socialapp = "Message";
var div_forgotten_pass_socialapp = "Forgotten Password";
var div_email_id_socialapp = "E-mail:";
var div_image_code_socialapp = "Image Code";
var div_placeholdere_email_socialapp = "Please enter your email";
var div_placeholdere_image_code_socialapp = "Please enter below image code";
var enter_captcha_image_socialapp = "Please enter below image code!";
var incorrect_captcha_code_socialapp = "Incorrect Code Entered!";
var new_pass_sent_onyour_mail_socialapp = "New password has been sent to email address";
var alert_msg_for_success_socialapp = "Success";
var email_not_match_our_record_socialapp = "Email not matched with our record";
var msg_fail_socialapp ="fail";
var msg_email_not_match_our_record_enter_register_mail_socialapp = "Email not matched with our record! Please enter your registered email.";
var signuppagesocial_html_signup_forapp_socialapp = "Sign Up for App";
var signuppagesocial_html_username_socialapp = "Username*";
var signuppagesocial_html_placeholder_username_socialapp = "Username";
var signuppagesocial_html_emailid_socialapp = "E-mail ID*";
var signuppagesocial_html_placeholder_emaiid_socialapp = "Email-ID";
var signuppagesocial_html_pass_socialapp = "Password*";
var signuppagesocial_html_placeholder_pass_socialapp = "Password";
var signuppagesocial_html_conpass_socialapp = "Confirm Password*";
var signuppagesocial_html_placeholder_conpass_socialapp = "Confirm Password";
var signuppagesocial_html_usr_licence_agreement_socialapp = "End User License Agreement";
var signuppagesocial_html_justify_licence_one_socialapp = "This End User License Agreement ( Agreement ) is between you and";
var signuppagesocial_html_justify_licence_two_socialapp = "and governs use of this app made available through the Apple App Store. By installing the";
var signuppagesocial_html_justify_licence_third_socialapp = "App, you agree to be bound by this Agreement and understand that there is no tolerance for objectionable content. If you do not agree with the terms and conditions of this Agreement, you are not entitled to use the";
var signuppagesocial_html_justify_licence_fourth_socialapp = "In order to ensure";
var signuppagesocial_html_justify_licence_third_socialapp = "provides the best experience possible for everyone, we strongly enforce a no tolerance policy for objectionable content. If you see inappropriate content, please use the  Report as offensive  feature found under each post.";
var signuppagesocial_html_justify_licence_fourth_br_socialapp = "1.  Parties";
var signuppagesocial_html_justify_licence_fourth_br_one_socialapp = "This Agreement is between you and";
var signuppagesocial_html_justify_licence_fifth_socialapp = "only, and not Apple, Inc. ( Apple ). Notwithstanding the foregoing, you acknowledge that Apple and its subsidiaries are third party beneficiaries of this Agreement and Apple has the right to enforce this Agreement against you.";
var signuppagesocial_html_justify_licence_six_socialapp = ", not Apple, is solely responsible for the";
var signuppagesocial_html_justify_licence_seven_socialapp = "App and its content.";
var signuppagesocial_html_justify_licence_seven_br_socialapp = "2. Privacy";
var signuppagesocial_html_justify_licence_eight_socialapp = "may collect and use information about your usage of the";
var signuppagesocial_html_justify_licence_nine_socialapp = "App, including certain types of information from and about your device.";
var signuppagesocial_html_justify_licence_ten_socialapp = "may use this information, as long as it is in a form that does not personally identify you, to measure the use and performance of the";
var signuppagesocial_html_justify_licence_app_socialapp = "App.";
var signuppagesocial_html_justify_licence_ten_br_socialapp = "3. Limited License";
var signuppagesocial_html_justify_licence_eleven_socialapp = "grants you a limited, non-exclusive, non-transferable, revocable license to use the";
var signuppagesocial_html_justify_licence_tweleve_socialapp = "App for your personal, non-commercial purposes. You may only use the";
var signuppagesocial_html_justify_licence_thirteen_socialapp = "App on Apple devices that you own or control and as permitted by the App Store Terms of Service.";
var signuppagesocial_html_justify_licence_thirteen_br_socialapp = "4. Age Restrictions ";
var signuppagesocial_html_justify_licence_byusing_socialapp = "By using the";
var signuppagesocial_html_justify_licence_fourteen_socialapp = "App, you represent and warrant that (a) you are 17 years of age or older and you agree to be bound by this Agreement; (b) if you are under 17 years of age, you have obtained verifiable consent from a parent or legal guardian; and (c) your use of the";
var signuppagesocial_html_justify_licence_fifteen_socialapp = "App does not violate any applicable law or regulation. Your access to the";
var signuppagesocial_html_justify_licence_sixteen_socialapp = "App may be terminated without Alert if";
var signuppagesocial_html_justify_licence_seventeen_socialapp = "believes, in its sole discretion, that you are under the age of 17 years and have not obtained verifiable consent from a parent or legal guardian. If you are a parent or legal guardian and you provide your consent to your child s use of the";
var signuppagesocial_html_justify_licence_eighteen_socialapp = "App, you agree to be bound by this Agreement in respect to your child s use of the";
var signuppagesocial_html_justify_licence_eighteen_br_socialapp = "5. Objectionable Content Policy";
var signuppagesocial_html_justify_licence_nineteen_socialapp = "Content may not be submitted to";
var signuppagesocial_html_justify_licence_twentyone_socialapp = ", who will moderate all content and ultimately decide whether or not to post a submission to the extent such content includes, is in conjunction with, or alongside any, Objectionable Content. Objectionable Content includes, but is not limited to: (i) sexually explicit materials; (ii) obscene, defamatory, libelous, slanderous, violent and/or unlawful content or profanity; (iii) content that infringes upon the rights of any third party, including copyright, trademark, privacy, publicity or other personal or proprietary right, or that is deceptive or fraudulent; (iv) content that promotes the use or sale of illegal or regulated substances, tobacco products, ammunition and/or firearms; and (v) gambling, including without limitation, any online casino, sports books, bingo or poker.";
var signuppagesocial_html_justify_licence_twentyone_br_socialapp = "6. Warranty";
var signuppagesocial_html_justify_licence_twentytwo_socialapp = "disclaims all warranties about the";
var signuppagesocial_html_justify_licence_twentythird_socialapp = "App to the fullest extent permitted by law. To the extent any warranty exists under law that cannot be disclaimed,";
var signuppagesocial_html_justify_licence_twentyfour_socialapp = ", not Apple, shall be solely responsible for such warranty.";
var signuppagesocial_html_justify_licence_twentyfive_br_socialapp = "7. Maintenance and Support";
var signuppagesocial_html_justify_licence_twentysix_socialapp = "does provide minimal maintenance or support for it but not to the extent that any maintenance or support is required by applicable law,";
var signuppagesocial_html_justify_licence_twentyseven_socialapp = ", not Apple, shall be obligated to furnish any such maintenance or support.";
var signuppagesocial_html_justify_licence_twentyseven_br_socialapp = "8. Product Claims";
var signuppagesocial_html_justify_licence_twentyeight_socialapp = ", not Apple, is responsible for addressing any claims by you relating to the";
var signuppagesocial_html_justify_licence_twentyenine_socialapp = "App or use of it, including, but not limited to: (i) any product liability claim; (ii) any claim that the";
var signuppagesocial_html_justify_licence_thirty_socialapp = "App fails to conform to any applicable legal or regulatory requirement; and (iii) any claim arising under consumer protection or similar legislation. Nothing in this Agreement shall be deemed an admission that you may have such claims.";
var signuppagesocial_html_justify_licence_thirty_br_socialapp = "9. Third Party Intellectual Property Claims";
var signuppagesocial_html_justify_licence_thirtyone_socialapp = "shall not be obligated to indemnify or defend you with respect to any third party claim arising out or relating to the";
var signuppagesocial_html_justify_licence_thirtytwo_socialapp = "App. To the extent";
var signuppagesocial_html_justify_licence_thirtythree_socialapp = "is required to provide indemnification by applicable law,";
var signuppagesocial_html_justify_licence_thirtyfour_socialapp = ", not Apple, shall be solely responsible for the investigation, defense, settlement and discharge of any claim that the";
var signuppagesocial_html_justify_licence_thirtyfive_socialapp = "App or your use of it infringes any third party intellectual property right.";
var signuppagesocial_html_justify_licence_accept_socialapp = "Accept";
var signuppagesocial_html_justify_licence_decline_socialapp = "Decline";
var alert_invalid_emailid_socialapp = "Invalid Email Address!";
var alert_enter_username_socialapp = "Please enter User Name!";
var alert_conpass_not_match_socialapp = "Confirm password not matched!";
var alert_pass_toshort_socialapp = "Password too short!";
var signup2pagesocial_fill_urinfo_socialapp = "Fill Your Information";
var signup2pagesocial_aboutme_socialapp = "About Me";
var signup2pagesocial_geneder_socialapp = "GENDER";
var signup2pagesocial_geneder_male_socialapp = "MALE";
var signup2pagesocial_geneder_female_socialapp = "FEMALE";
var signup2pagesocial_birthday_socialapp = "BIRTHDATE";
var alert_about_me_socialapp = "Please enter About Me!";
var alert_select_geneder_socialapp = "Please select gender!";
var alert_select_birthdate_socialapp = "Please select birth date!";
var alert_select_location_socialapp = "Please enter location!";
var alert_enter_phone_socialapp = "Please enter phone!";
var alert_enter_address_socialapp = "Please enter address!";
var alert_enter_country_socialapp = "Please select country!";
var alert_enter_state_socialapp = "Please select state!";
var alert_enter_city_socialapp = "Please select city!";
var alert_enter_zip_socialapp = "Please select zip!";
var latestsocial_show_more_socialapp = "Show more";
var social_view_all_socialapp = "View All";
var captionnnWallPost_image_social_saysomething_socialapp = "Say something about this photo...";
var captionnnWallPost_image_social_saysomething_video_socialapp = "Say something about this video...";
var social_post_socialapp = "Pages:";
var placeholder_search_socialapp = "Search...";
var without_palceholder_search_socialapp = "Search";
var nolike_found_socialapp = "No likes found";
var followers_socialapp = "Followers:";
var subscriber_socialapp = "Subscribers:";
var member_since_socialapp = "Member Since :";
var following_socialapp = "Following";
var decription_socialapp = "Description:";
var post_socialapp = "Posts :";
var subscribe_without_colon_socialapp = "Subscribers";
var follower_without_colon_socialapp = "Followers";
var follow_witjout_s_socialapp = "Follow";
var subscribed_socialapp = "Subscribed";
var subscribe_without_s_socialapp = "Subscribe";
var edit_profile_socialapp = "Edit Profile";
var add_comment_socialapp = "Add a Comment";
var alert_not_allowed_comment_socialapp = "You are not allowed to comment on this post!";
var comment_socialapp = "Comment";
var unlike_socialapp = "Unlike";
var like_socialapp = "like";
var alert_enter_comment_socialapp = "Plese enter comment!";
var no_comments_there_socialapp = "No comments on this post";
var no_likes_there_socialapp = "No likes on this post";
var by_socialapp = "by";
var mystream_socialapp = "Mystream";
var all_socialapp = "All";
var post_without_colon = "Posts";
var comments_socialapp = "Comments";
var follows_socialapp = "Follows";
var likes_socialapp = "Likes";
var subscribe_socialapp = "Subscribes";
var none_socialapp = "None";
var top_hundred_user_socialapp = "Top 100 User";
var alert_msg_for_successfully_updated_socialapp = "successfully Updated!";
var alert_msg_usrname_cant_blank_socialapp = "Username cannot be blank !";
var alert_msg_email_cant_blank_socialapp = "Email cannot be blank !";
var inner_msg_emailid_already_exist_socialapp = "Email-id already exist!";
var inner_msg_not_valid_email_address_socialapp = "Not a valid e-mail address!";
var alert_msg_enter_current_password_socialapp = "Please enter current password!";
var alert_msg_enter_new_pass_socialapp = "Please enter new password!";
var alert_msg_enter_confirm_password_socialapp = "Please enter confirm password!";
var alert_msg_password_doesnt_match_socialapp = "Passwords do not match!";
var alert_msg_selectfrom_where_want_socialapp = "Select from where you want to upload!";
var alert_gallery_camera_socialapp = "Camera,Gallery";
var alert_gallery_camera_cancel_socialapp = "Camera,Gallery,Cancel";
var alert_msg_addtext_toupload_image_socialapp = "Please add text to upload Image!";
var alert_msg_addtext_toupload_video_socialapp = "Please add text to upload Video!";
var alert_msg_addtext_toupload_socialapp = "Please add text to upload !";
var alert_msg_successfully_uploaded_socialapp = "successfully Uploaded!";
var alert_msg_some_error_occured_socialapp = "Some Error try again!";
var vedio_upload_socialapp = "Video Upload";
var gender_male_socialapp = "male";
var gender_female_socialapp = "female";
var subscriber_without_s_socialapp = "Subscriber";
var follower_without_s_socialapp = "Followers";
var filter_by_location_socialapp = "Filter by location";
var follow_all_socialapp ="Follow All";
var login_socialapp = "Login";
var signuppagesocial_html_continue_socialapp = "Continue";



 var soapRequestsign="";
var socialMenu=" <ul class='sub-menu' style='display:none;' >\
	<li><a onclick='goHomeFromSocial()' class='menu-nav' href='javascript:;'>Main Menu</a></li>\
	<li><a onclick='movidHome()' class='home-nav' href='javascript:;'>Home</a></li>\
	<li><a onclick='mystream()' class='my_stream-nav' href='javascript:;'>My Stream</a></li>\
	<li><a onclick='klustersocial()' class='cluster-nav' href='javascript:;'>Klusters</a></li>\
	<li><a onclick='top100user()' class='top_user-nav' href='javascript:;'>Top 100 Users</a></li>\
	<li><a onclick='whotofollow()' class='about_app-nav' href='javascript:;'>Who to follow</a></li>\
	<li><a onclick='MYProfile()' class='account-nav' href='javascript:;'>My Profile</a></li>\
	<li><a onclick='mysetting()' class='terms-nav' href='javascript:;'>Settings</a></li>\
	<li><a onclick='logOutSocial()' class='login-nav' href='javascript:;'>Logout</a></li></ul>";
	


var socialMenuSlide="<a onclick='goHomeFromSocial();' class='menu-nav' href='javascript:;'><img src='images/e-com/eMenu_icon.png' height=20px border='0'/> <span>"+social_menu_slide_main_menu_soicalapp+"</span></a>\
	<a onclick='movidHome()' class='home-nav' href='javascript:;'><img src='images/e-com/home_icon.png' border='0'/> <span>Home</span></a>\
	<a onclick='mystream()' class='my_stream-nav' href='javascript:;'><img src='images/my_stream.png' border='0'/> <span>My Stream</span></a>\
	<a onclick='klustersocial()' class='cluster-nav' href='javascript:;'><img src='images/cluster.png'  border='0'/> <span>Klusters</span></a>\
	<a onclick='top100user()' class='top_user-nav' href='javascript:;'><img src='images/top_user.png' border='0'/> <span>Top 100 Users</span></a>\
	<a onclick='whotofollow()' class='about_app-nav' href='javascript:;'><img src='images/about_app.png'  border='0'/> <span>Who to follow</span></a>\
	<a onclick='MYProfile()' class='account-nav' href='javascript:;'><img src='images/e-com/myAccount_icon.png'  border='0'/> <span>My Profile</span></a>\
	<a onclick='mysetting()' class='terms-nav' href='javascript:;'><img src='images/e-com/trems_icon.png' border='0'/> <span>Settings</span></a>\
	<a onclick='logOutSocial()' class='login-nav' href='javascript:;'><img src='images/e-com/login_icon.png'  border='0'/> <span>Logout</span></a>";



function goHomeFromSocial()
{

	if(window.localStorage.getItem("layout")=="bottom") {
		$(".app_navigation_bottom").show();
		window.localStorage.setItem("bottomHide","false");
	}

	window.sessionStorage.setItem("EcomSubMenu","true");
	if(window.localStorage.getItem("layout")=="slidemenu") {
		$("#mainmenu").empty();
		getIndexData();
	}
	else
	{
		onBackKeyDown("fromSocialItem"); 
	}
}

function movidHome()
{
	indexsocial();
}

function logOutSocial()
{
	if(window.localStorage.getItem("layout")=="slidemenu"){
		snapper.close();
		$("#mainmenu").empty();
        getIndexData();
	}
	localStorage.setItem('userid','');
	toaster.logout();
	// logout_fb();
	setTimeout(function(){
	getsocialapp('');
	//goHomeFromSocial();
	},1000);

	//  window.location ="logoutfromapp:";
}
var nameofuser;
var globalindex;
var resellerInitial="";
var reseller='';
var username_registeration;
var email_registeration;
var password_registeration;
var confirmpassword_registeration;
/*Start social login*/


function sociallogin_fb_twitter(email)
{
	var wsUrl="http://"+localStorage.getItem("reseller")+"/services/social-soap#signInJson";
	var soapRequest ='<?xml version="1.0" encoding="utf-8"?> <soap:Envelope xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"  xmlns:xsd="http://www.w3.org/2001/XMLSchema" xmlns:soap="http://schemas.xmlsoap.org/soap/envelope/"> <soap:Body><signInJson xmlns=\"http://'+localStorage.getItem('reseller')+'/services/social-soap#signInJson\"><appId>'+localStorage.getItem('applicationID')+'</appId><email>'+email+'</email><password></password><type>social</type><name>'+nameofuser+'</name></signInJson></soap:Body></soap:Envelope>';
	console.log("SoapRequest : "+ soapRequest);

	$.ajax({
		type: "POST",
		url: wsUrl,
		contentType: "text/xml",
		dataType: "text",
		data: soapRequest,
		success: function(data, status, req)
		{
			console.log("Success : "+req.responseText);
			var strJSON = $(req.responseText).find("return").text();
			var obj = JSON.parse(strJSON);
			if(obj.msg)
			{
				// logout_fb();
				var message=social_login_fb_twitter_msg_socialapp;
				navigator.notification.alert(
						message,  // message
						alertDismissed,         // callback
						social_login_fb_alert_socialapp,            // title
						social_login_fb_alert_ok_socialapp                  // buttonName
				);
				$('.appypie-loader').hide();
			}
			else
			{
				localStorage.setItem('userid',obj.id);
				indexsocial();
			}

			// listCategories(strJSON);
		},
		error: function(response, textStatus, errorThrown)
		{
			//   logout_fb();
			$('.appypie-loader').hide();
			console.log("Error : "+JSON.stringify(response));
			console.log("Error : "+textStatus);
			console.log("Error : "+errorThrown.responseText);
		}
	});
}
/*End social login*/


function getLoginStatus() {

	getsociallogin();
}

/* Login page start*/
function getsocialapp(index)
{
if(localStorage.getItem("appLanguageCheck") == "sa")
   {
      arabic();
   }
	var value=toaster.getValues();


	$('.appypie-loader').show();
	globalindex=index;
	reseller=window.localStorage.getItem("reseller");



	if(localStorage.getItem('userid'))
	{
		indexsocial();
	}
	else
	{

		if(value=="")
		{
			getLoginStatus();
		}
		else{
			indexsocial();
		}

	}


}


function getsociallogin()
{
	/*Login Page*/
	var xmldata=$.parseXML(window.sessionStorage.getItem("xml"));
	var appName = window.localStorage.getItem("AppName");
	
	
	 var checkFacebookLogin = $(masterData).find("loginfield").find("enableFacebookNow").text();
    if(checkFacebookLogin=="Off")
    {
		var html="<section class=' magentocl' style=''>  <div id='middle_page' class='social-inner-page'><div class='socialpost-box'><h1 class='heading'><a href='#'><small style='color: #000'>"+get_social_login_dont_have_account_yet_socialapp+" </small><small onclick='signuppagesocial();'>"+get_social_login_signup_now_socialapp+"</small></a></h2><h1 class='heading'></h1><ul class='login-box'><li><label>"+get_social_login_email_id_socialapp+"</label></li><li data-role='none'><input data-role='none' type='text' id='loginidsocial' placeholder="+get_social_login_placeholder_emailid_socialapp+"></li><li><label>"+get_social_login_password_socialapp+"</label></li><li data-role='none'><input data-role='none' type='password' placeholder="+get_social_login_placeholder_password_socialapp+" id='paswordsocial' value=''></li><li><button onclick='loginsocial();' "+primaryColor+" >"+login_socialapp+"</button></li><li><span class='login'><a href='#' onclick='forgotPasswordPage();'>"+get_social_login_forgot_pass_socialapp+"</a></span></li></ul><br clear='all'><div class='or-feald'></div></div><br clear='all'></div></div></div></div></section>"
	}
	else
	{
		var html="<section class=' magentocl' style=''>  <div id='middle_page' class='social-inner-page'><div class='socialpost-box'><h1 class='heading'><a href='#'><small style='color: #000'>"+get_social_login_dont_have_account_yet_socialapp+" </small><small onclick='signuppagesocial();'>"+get_social_login_signup_now_socialapp+"</small></a></h2><h1 class='heading'></h1><ul class='login-box'><li><label>"+get_social_login_email_id_socialapp+"</label></li><li data-role='none'><input data-role='none' type='text' id='loginidsocial' placeholder="+get_social_login_placeholder_emailid_socialapp+"></li><li><label>"+get_social_login_password_socialapp+"</label></li><li data-role='none'><input data-role='none' type='password' placeholder="+get_social_login_placeholder_password_socialapp+" id='paswordsocial' value=''></li><li><button onclick='loginsocial();' "+primaryColor+" >"+login_socialapp+"</button></li><li><span class='login'><a href='#' onclick='forgotPasswordPage();'>"+get_social_login_forgot_pass_socialapp+"</a></span></li></ul><br clear='all'><div class='or-feald'><span>Or</span></div><a href='#' class='social-fb' onclick='socialloginfb()'></a></div><br clear='all'></div></div></div></div></section>"
	}
	
		console.log(html);
	 $('#contentHolder20').css('background', '#edf0f5');
	appendHtml(html,20,1,'socialAppLogin');
}


function socialloginfb() {
	toaster.loginToFacebook("socialapp");
}

function AcceptLicence_social()
{
	document.getElementById('lighttt').style.display='none';
	document.getElementById('fadeee').style.display='none';
	localStorage.setItem("EulaAccept", "Done");
	//signupsocial();


	$('.appypie-loader').show();
	var wsUrl="http://"+window.localStorage.getItem("reseller")+"/services/social-soap#checkEmailJson";
	var soapRequest ='<?xml version="1.0" encoding="utf-8"?> <soap:Envelope xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"  xmlns:xsd="http://www.w3.org/2001/XMLSchema" xmlns:soap="http://schemas.xmlsoap.org/soap/envelope/"> <soap:Body><checkEmailJson xmlns=\"http://'+window.localStorage.getItem("reseller")+'/services/social-soap#checkEmailJson\"><email>'+email_registeration+'</email></checkEmailJson><appId>'+localStorage.getItem('applicationID')+'</appId></soap:Body></soap:Envelope>';
	console.log("SoapRequest1 : "+ soapRequest);

	$.ajax({
		type: "POST",
		url: wsUrl,
		contentType: "text/xml",
		dataType: "text",
		data: soapRequest,
		success: function(data, status, req)
		{

			var strJSON = $(req.responseText).find("return").text();
			if(strJSON=="")
			{
				var wsUrll="http://"+window.localStorage.getItem("reseller")+"/services/social-soap#signUpJson";
				var soapRequestt ='<?xml version="1.0" encoding="utf-8"?> <soap:Envelope xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"  xmlns:xsd="http://www.w3.org/2001/XMLSchema" xmlns:soap="http://schemas.xmlsoap.org/soap/envelope/"> <soap:Body><signUpJson xmlns=\"http://'+window.localStorage.getItem("reseller")+'/services/social-soap#signUpJson\"><appid>'+localStorage.getItem('applicationID')+'</appid><name>'+username_registeration+'</name><email>'+email_registeration+'</email><password>'+password_registeration+'</password></signUpJson></soap:Body></soap:Envelope>';
				console.log("SoapRequest2 : "+ soapRequest);

				$.ajax({
					type: "POST",
					url: wsUrll,
					contentType: "text/xml",
					dataType: "text",
					data: soapRequestt,
					success: function(data, status, req)
					{
						var strJSON = $(req.responseText).find("return").text();
						console.log("strJSON :---- "+ strJSON+"----krishna");
						if(strJSON!=""&& strJSON!="user already register" )
						{
							var obj = JSON.parse(strJSON);
							var res = strJSON.replace("", "W3Schools");
							strJSON = strJSON.replace(/"/g,'');

							localStorage.setItem('useridd',strJSON);
							localStorage.setItem('userid',strJSON);
							localStorage.setItem("sNUserName",username_registeration);
							signup2pagesocial();
						}
						else
						{
							console.log("Success else : ");
							var message=email_already_exist_socialapp;
							navigator.notification.alert(
									message,  // message
									alertDismissed,         // callback
									social_login_fb_alert_socialapp,            // title
                                    social_login_fb_alert_ok_socialapp                   // buttonName
							);
						}
						// listCategories(strJSON);
					},
					error: function(response, textStatus, errorThrown)
					{
						console.log("Error : "+JSON.stringify(response));
						console.log("Error : "+textStatus);
						console.log("Error : "+errorThrown.responseText);
					}
				});
				//finish

			}
			else
			{
				console.log("else : ");
				$('.appypie-loader').hide();
				var obj = JSON.parse(strJSON);
				var message=email_already_exist_socialapp;
				navigator.notification.alert(
						message,  // message
						alertDismissed,         // callback
						social_login_fb_alert_socialapp,            // title
                        social_login_fb_alert_ok_socialapp                 // buttonName
				);
			}
			// listCategories(strJSON);
		},
		error: function(response, textStatus, errorThrown)
		{
			console.log("Error : "+JSON.stringify(response));
			console.log("Error : "+textStatus);
			console.log("Error : "+errorThrown.responseText);
		}

	});



}


function callAccessSocial(name,email)
{
	nameofuser= name;
	sociallogin_fb_twitter(email);

}
function DeclineLicence_social()
{
	document.getElementById('lighttt').style.display='none';
	document.getElementById('fadeee').style.display='none';
}
/* Login page ends*/

/* Login wsdl start*/
function loginsocial()
{
	var username_login=document.getElementById("loginidsocial").value;
	var password_login=document.getElementById("paswordsocial").value;
	if(username_login=="" || !checkEmail(username_login))
	{
		//document.getElementById('username_login').focus();
		var message=enter_valid_email_id_socialapp;
		navigator.notification.alert(
				message,  // message
				alertDismissed,         // callback
				social_login_fb_alert_socialapp,            // title
                social_login_fb_alert_ok_socialapp                   // buttonName
		);

	}
	else if(password_login=="")
	{
		//document.getElementById('password_login').focus();
		var message=please_enter_pass_socialapp;
		navigator.notification.alert(
				message,  // message
				alertDismissed,         // callback
				social_login_fb_alert_socialapp,            // title
				social_login_fb_alert_ok_socialapp                  // buttonName
		);

	}
	else
	{
		$('.appypie-loader').show();
		var wsUrl="http://"+localStorage.getItem("reseller")+"/services/social-soap#signInJson";
		var soapRequestsign ='<?xml version="1.0" encoding="utf-8"?> <soap:Envelope xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"  xmlns:xsd="http://www.w3.org/2001/XMLSchema" xmlns:soap="http://schemas.xmlsoap.org/soap/envelope/"> <soap:Body><signInJson xmlns=\"http://'+window.localStorage.getItem("reseller")+'/services/social-soap#signInJson\"><appId>'+localStorage.getItem('applicationID')+'</appId><email>'+username_login+'</email><password>'+password_login+'</password></signInJson></soap:Body></soap:Envelope>';
		console.log("SoapRequest Ravi2: "+ soapRequestsign);
       localStorage.setItem("soapRequestsign",soapRequestsign);
		$.ajax({
			type: "POST",
			url: wsUrl,
			contentType: "text/xml",
			dataType: "text",
			data: soapRequestsign,
			success: function(data, status, req)
			{
				console.log("Success Ravi: "+req.responseText);
				var strJSON = $(req.responseText).find("return").text();
				
				var obj = JSON.parse(strJSON);
				console.log("Success Ravi2: "+obj.msg);
				
				if(obj.msg=="This user has been blocked. Please contact to Administrator")
               {
               console.log("Successuuuu : "+obj.msg);
               navigator.notification.alert(
                                            obj.msg,  // message
                                            alertDismissed,         // callback
                                            alert_warning_socialapp,            // title
                                            social_login_fb_alert_ok_socialapp                  // buttonName
                                            );
               $('.appypie-loader').hide();
               return;
               }
               else if(obj.msg=="Invalid User name or password" || obj.msg=="Invalid Credential")
				{
					console.log("Success : "+obj.msg);
					navigator.notification.alert(
							invalid_nameandpass_socialapp,  // message
							alertDismissed,         // callback
							social_login_fb_alert_socialapp,            // title
							social_login_fb_alert_ok_socialapp                  // buttonName
					);
					$('.appypie-loader').hide();
				}else if(obj.msg=="This user has been blocked. Please contact to Administrator")
					{
					  navigator.notification.alert(
                              user_blocked_socialapp,
                              alertDismissed,
                              alert_message_socialapp,
                              social_login_fb_alert_ok_socialapp
                              );
					  $('.appypie-loader').hide();
					}
				else
				{
					document.getElementById("loginidsocial").value="";
					document.getElementById("paswordsocial").value="";
					console.log("Success : "+obj.id);
					console.log("Success : "+obj.name);
					console.log("Success : "+obj.email);
					 localStorage.setItem("sNUserName",obj.name);
					localStorage.setItem('userid',obj.id);
					indexsocial();
				}
				// listCategories(strJSON);
			},
			error: function(response, textStatus, errorThrown)
			{
				console.log("Error : "+JSON.stringify(response));
				console.log("Error : "+textStatus);
				console.log("Error : "+errorThrown.responseText);
			}
		});
	}
}
/* Login wsdl ends*/
/* forgot password start*/
function forgotPasswordPage()
{
   
	var html="<section class=' magentocl' style=''><div id='middle_page' class='social-inner-page'><div class='socialpost-box'><h1 class='heading'>"+div_forgotten_pass_socialapp+"</h1><ul class='login-box'><li><label>"+div_email_id_socialapp+"</label></li><li><input id='fgtEmail' type='text' placeholder='Please enter your email'></li><form id='fgtForm'><li><label>"+div_image_code_socialapp+" </label></li><li><input placeholder="+div_placeholdere_image_code_socialapp+" type='text' id='captchaText' /></li><li><p id='captcha'></p></li><li><button "+primaryColor+">"+signuppagesocial_html_continue_socialapp+"</button></li></form><script type='text/javascript'>$('form').clientSideCaptcha({input: '#captchaText',display: '#captcha',pass : function() { successSubmit('Pass'); return false; },fail : function() {successSubmit('Wrong'); return false; }});</script></li></ul><br clear='all'></div></div></section>";

   $('#contentHolder21').css('background', '#edf0f5');
	$("#contentHolder21").empty();

	//setTimeout(function(){
	$("#reload").hide();
   $("#mainback").show();
   appendHtml("<div class='page-text'>"+html+"</div>",21,2,'socialAppLogin');
	//$("#contentHolder21").append("<div class='page-text'>"+html+"</div>");
		$.mobile.changePage('#page22', { transition: 'slidefade',allowSamePageTransition: false});
		$('.appypie-loader').hide();
	//},10);
}

function successSubmit(valuePass)
{
	var fgt_Email=document.getElementById("fgtEmail").value;
	var fgt_ImgCode=document.getElementById("captchaText").value;

	var ck_email = /^[^@]+@[^@.]+\.[^@]*\w\w$/;
	var isValid=ck_email.test(fgt_Email);

	if(fgt_Email=="")
	{
		document.getElementById('fgtEmail').focus();
		var message=please_enter_email_socialapp;
		navigator.notification.alert(
				message,  // message
				alertDismissed,         // callback
				social_login_fb_alert_socialapp,            // title
                social_login_fb_alert_ok_socialapp                 // buttonName
		);

	}
	else if(fgt_Email.length>0)
	{
		if (!isValid) {

			document.getElementById('fgtEmail').focus();
			var message=enter_valid_email_id_socialapp;
			navigator.notification.alert(
					message,  // message
					alertDismissed,         // callback
					social_login_fb_alert_socialapp,            // title
                    social_login_fb_alert_ok_socialapp                  // buttonName
			);
		}
		else if(fgt_ImgCode=="")
		{
			document.getElementById('captchaText').focus();
			var message=enter_captcha_image_socialapp;
			navigator.notification.alert(
					message,  // message
					alertDismissed,         // callback
					social_login_fb_alert_socialapp,            // title
                    social_login_fb_alert_ok_socialapp                   // buttonName
			);
		}
		else
		{
			if(valuePass=="Wrong")
			{
				var message=incorrect_captcha_code_socialapp;
				navigator.notification.alert(
						message,  // message
						alertDismissed,         // callback
						social_login_fb_alert_socialapp,            // title
                        social_login_fb_alert_ok_socialapp                  // buttonName
				);
				forgotPasswordPage();
			}
			else if(valuePass=="Pass")
			{
				// window.localStorage.getItem("AppName");
				//New password has been sent to email address
				$('.appypie-loader').show();
				var wsUrl="http://"+window.localStorage.getItem("reseller")+"/services/social-soap#forgotpassJson";
				var soapRequest ='<?xml version="1.0" encoding="utf-8"?> <soap:Envelope xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"  xmlns:xsd="http://www.w3.org/2001/XMLSchema" xmlns:soap="http://schemas.xmlsoap.org/soap/envelope/"> <soap:Body><forgotpassJson xmlns=\"http://'+window.localStorage.getItem("reseller")+'/services/social-soap#forgotpassJson\"><appId>'+localStorage.getItem('applicationID')+'</appId><email>'+fgt_Email+'</email></forgotpassJson></soap:Body></soap:Envelope>';
				console.log("SoapRequest : "+ soapRequest);

				$.ajax({
					type: "POST",
					url: wsUrl,
					contentType: "text/xml",
					dataType: "text",
					data: soapRequest,
					success: function(data, status, req)
					{
						console.log("Success : "+req.responseText);
						var strJSON = $(req.responseText).find("return").text();


						if(strJSON.trim()=="New password has been sent to email address")
						{
							console.log("Success : "+strJSON);


							var message=new_pass_sent_onyour_mail_socialapp;
							navigator.notification.alert(
									message,  // message
									dissmissedAlert,         // callback
									alert_msg_for_success_socialapp,            // title
									social_login_fb_alert_ok_socialapp                  // buttonName
							);

							document.getElementById('captchaText').value="";
							document.getElementById('fgtEmail').value="";
							$('.appypie-loader').hide();
						}
						else if(strJSON=="Email not matched with our record" || strJSON=="fail")
						{
							$('.appypie-loader').hide();
							document.getElementById('fgtEmail').focus();

							var message=msg_email_not_match_our_record_enter_register_mail_socialapp;
							navigator.notification.alert(
									message,  // message
									alertDismissed,         // callback
									social_login_fb_alert_socialapp,            // title
                                    social_login_fb_alert_ok_socialapp                   // buttonName
							);
						}
					},
					error: function(response, textStatus, errorThrown)
					{
						console.log("Error : "+JSON.stringify(response));
						console.log("Error : "+textStatus);
						console.log("Error : "+errorThrown.responseText);
					}
				});
			}
		}
	}
}
function dissmissedAlert()
{
	console.log("good");
	getsociallogin()('');

}
/* forgot password Ends*/

/* Signup Start*/
function signuppagesocial()
{
	
	var appName = window.localStorage.getItem("AppName");
	var html="<section class=' magentocl' style='' date-role='none'>  <div id='middle_page' class='social-inner-page'><div class='socialpost-box'><h1 class='heading'>"+signuppagesocial_html_signup_forapp_socialapp+"</h1><ul class='login-box'><li><label>"+signuppagesocial_html_username_socialapp+"</label></li><li><input type='text' value='' placeholder="+signuppagesocial_html_placeholder_username_socialapp+" id='username_registeration'></li><li><label>"+signuppagesocial_html_emailid_socialapp+"</label></li><li><input type='email' value='' placeholder="+signuppagesocial_html_placeholder_emaiid_socialapp+" id='email_registeration' onblur='validateEmail(this);'></li><li><label>"+signuppagesocial_html_pass_socialapp+"</label></li><li><input type='password' value='' placeholder="+signuppagesocial_html_placeholder_pass_socialapp+" id='password_registeration'></li><li><label>"+signuppagesocial_html_conpass_socialapp+"</label></li><li><input type='password' value='' placeholder="+signuppagesocial_html_placeholder_conpass_socialapp+" id='confirmpassword_registeration'></li><li><button onclick='beforesignupsocial();' "+primaryColor+">"+signuppagesocial_html_continue_socialapp+"</button></li></ul><br clear='all'></div></div></div></div></section><div id='lighttt' class='white_content'> <h4 class='license-ttle'>"+signuppagesocial_html_usr_licence_agreement_socialapp+"</h4><div class='license-wrapper'><p align='justify'>"+signuppagesocial_html_justify_licence_one_socialapp+" "+appName+" "+signuppagesocial_html_justify_licence_two_socialapp+"  "+appName+" "+signuppagesocial_html_justify_licence_third_socialapp+"  "+appName+" "+signuppagesocial_html_justify_licence_app_socialapp+" <br><br> "+signuppagesocial_html_justify_licence_fourth_socialapp+"  "+appName+" "+signuppagesocial_html_justify_licence_third_socialapp+" <br><br> "+signuppagesocial_html_justify_licence_fourth_br_socialapp+" <br>"+signuppagesocial_html_justify_licence_fourth_br_one_socialapp+"  "+appName+" "+signuppagesocial_html_justify_licence_fifth_socialapp+"  "+appName+""+signuppagesocial_html_justify_licence_six_socialapp+"  "+appName+" "+signuppagesocial_html_justify_licence_seven_socialapp+"<br><br> "+signuppagesocial_html_justify_licence_seven_br_socialapp+" <br> "+appName+" "+signuppagesocial_html_justify_licence_eight_socialapp+"  "+appName+" "+signuppagesocial_html_justify_licence_nine_socialapp+"  "+appName+" "+signuppagesocial_html_justify_licence_ten_socialapp+"  "+appName+" "+signuppagesocial_html_justify_licence_app_socialapp+" <br><br> "+signuppagesocial_html_justify_licence_ten_br_socialapp+" <br> "+appName+" "+signuppagesocial_html_justify_licence_eleven_socialapp+" "+appName+" "+signuppagesocial_html_justify_licence_tweleve_socialapp+" "+appName+" "+signuppagesocial_html_justify_licence_thirteen_socialapp+" <br><br> "+signuppagesocial_html_justify_licence_thirteen_br_socialapp+" <br>"+signuppagesocial_html_justify_licence_byusing_socialapp+"  "+appName+" "+signuppagesocial_html_justify_licence_fourteen_socialapp+"  "+appName+" "+signuppagesocial_html_justify_licence_fifteen_socialapp+"  "+appName+" "+signuppagesocial_html_justify_licence_sixteen_socialapp+"  "+appName+" "+signuppagesocial_html_justify_licence_seventeen_socialapp+"  "+appName+" "+signuppagesocial_html_justify_licence_eighteen_socialapp+"  "+appName+" "+signuppagesocial_html_justify_licence_app_socialapp+" <br><br> "+signuppagesocial_html_justify_licence_eighteen_br_socialapp+" <br> "+signuppagesocial_html_justify_licence_nineteen_socialapp+"  "+appName+""+signuppagesocial_html_justify_licence_twentyone_socialapp+" <br><br> "+signuppagesocial_html_justify_licence_twentyone_br_socialapp+" <br> "+appName+" "+signuppagesocial_html_justify_licence_twentytwo_socialapp+"  "+appName+" "+signuppagesocial_html_justify_licence_twentythird_socialapp+"  "+appName+""+signuppagesocial_html_justify_licence_twentyfour_socialapp+" <br><br> "+signuppagesocial_html_justify_licence_twentyfive_br_socialapp+" <br> "+appName+" "+signuppagesocial_html_justify_licence_twentysix_socialapp+"  "+appName+""+signuppagesocial_html_justify_licence_twentyseven_socialapp+" <br><br> "+signuppagesocial_html_justify_licence_twentyseven_br_socialapp+" <br> "+appName+""+signuppagesocial_html_justify_licence_twentyeight_socialapp+"  "+appName+" "+signuppagesocial_html_justify_licence_twentyenine_socialapp+"  "+appName+" "+signuppagesocial_html_justify_licence_thirty_socialapp+" <br><br> "+signuppagesocial_html_justify_licence_thirty_br_socialapp+" <br> "+appName+" "+signuppagesocial_html_justify_licence_thirtyone_socialapp+"  "+appName+" "+signuppagesocial_html_justify_licence_thirtytwo_socialapp+"  "+appName+" "+signuppagesocial_html_justify_licence_thirtythree_socialapp+"  "+appName+""+signuppagesocial_html_justify_licence_thirtyfour_socialapp+"  "+appName+" "+signuppagesocial_html_justify_licence_thirtyfive_socialapp+"/p></div><div class='license-clsBtn'><a href='#' class='accept' onclick='AcceptLicence_social();'>"+signuppagesocial_html_justify_licence_accept_socialapp+"</a><a href = 'javascript:void(0)'  class='decline' onclick='DeclineLicence_social();'>"+signuppagesocial_html_justify_licence_decline_socialapp+"</a></div></div><div id='fadeee' class='black_overlay'></div>";
	 $('#contentHolder21').css('background', '#edf0f5');
	appendHtml("<div class='page-text'>"+html+"</div>",21,2,'food');
	$(".ui-btn-left").hide();

}


function validateEmail(emailField){
	var reg = /^([A-Za-z0-9_\-\.])+\@([A-Za-z0-9_\-\.])+\.([A-Za-z]{2,4})$/;

	if (reg.test(emailField.value) == false)
	{
		var message=alert_invalid_emailid_socialapp;
		navigator.notification.alert(
				message,  // message
				alertDismissed,         // callback
				social_login_fb_alert_socialapp,            // title
                social_login_fb_alert_ok_socialapp                  // buttonName
		);
		document.getElementById("email_registeration").value="";
		document.getElementById("email_registeration").focus();
	}
}

function beforesignupsocial()
{
	signupsocial();

}
function signupsocial()
{
	username_registeration=document.getElementById("username_registeration").value;
	email_registeration=document.getElementById("email_registeration").value;
	password_registeration=document.getElementById("password_registeration").value;
	confirmpassword_registeration=document.getElementById("confirmpassword_registeration").value;
	localStorage.setItem("sNUserName",username_registeration);
	if(username_registeration.trim()=="")
	{
		var message=alert_enter_username_socialapp;
		navigator.notification.alert(
				message,  // message
				alertDismissed,         // callback
				social_login_fb_alert_socialapp,            // title
                social_login_fb_alert_ok_socialapp                 // buttonName
		);
		document.getElementById('username_registeration').focus();
	}
	else if(email_registeration=="")
	{
		var message=please_enter_email_socialapp;
		navigator.notification.alert(
				message,  // message
				alertDismissed,         // callback
				social_login_fb_alert_socialapp,            // title
                social_login_fb_alert_ok_socialapp                 // buttonName
		);
		document.getElementById('email_registeration').focus();
	}
	else if(password_registeration=="")
	{
		var message=please_enter_pass_socialapp;
		navigator.notification.alert(
				message,  // message
				alertDismissed,         // callback
				social_login_fb_alert_socialapp,            // title
                social_login_fb_alert_ok_socialapp                // buttonName
		);
		document.getElementById('password_registeration').focus();
	}
	else if(password_registeration!=confirmpassword_registeration)
	{
		var message=alert_conpass_not_match_socialapp;
		navigator.notification.alert(
				message,  // message
				alertDismissed,         // callback
				social_login_fb_alert_socialapp,            // title
                social_login_fb_alert_ok_socialapp                 // buttonName
		);
		document.getElementById('confirmpassword_registeration').focus();
	}
	else if(password_registeration.length<6)
	{
		var message=password_alert_pass_toshort_socialapp;
		navigator.notification.alert(
				message,  // message
				alertDismissed,         // callback
				social_login_fb_alert_socialapp,            // title
                social_login_fb_alert_ok_socialapp                 // buttonName
		);
		document.getElementById('confirmpassword_registeration').focus();
	}
	else
	{

		document.getElementById('lighttt').style.display='block';
		document.getElementById('fadeee').style.display='block';

	}
}
/* Signup Ends*/

/* Signup2 Starts*/
function signup2pagesocial()
{
	$("#mainback").hide();
	var countryobj;
	var countryoption="";
	var wsUrlll="http://"+window.localStorage.getItem("reseller")+"/services/social-soap#getCountryListJson";
	var soapRequestt ='<?xml version="1.0" encoding="utf-8"?> <soap:Envelope xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"  xmlns:xsd="http://www.w3.org/2001/XMLSchema" xmlns:soap="http://schemas.xmlsoap.org/soap/envelope/"> <soap:Body><getCountryListJson xmlns=\"http://'+window.localStorage.getItem("reseller")+'/services/social-soap#getCountryListJson\"></getCountryListJson></soap:Body></soap:Envelope>';
	console.log("signup2pagesocial "+ soapRequestt);
	$.ajax({
		type: "POST",
		url: wsUrlll,
		contentType: "text/xml",
		dataType: "text",
		data: soapRequestt,
		success: function(data, status, req)
		{
			var strJSON = $(req.responseText).find("return").text();
			console.log("Success : "+strJSON);
			countryobj = JSON.parse(strJSON);

			for(var i=0; i<countryobj.length; i++)
			{
				countryoption+='<option value='+countryobj[i].id+'>'+countryobj[i].country+'</option>';
			}

			var html="<div class='social-inner-page'><div id='signup2_div' class='socialpost-box'><h1 class='heading'>"+signup2pagesocial_fill_urinfo_socialapp+"</h1><ul class='login-box'><li><label>"+signup2pagesocial_aboutme_socialapp+"</label></li><li><textarea id='about_me' name='about_me' data-role='none' class='afterIn'></textarea></li><li><label>"+signup2pagesocial_geneder_socialapp+"</label></li><li class='male'><input type='radio' name='gender' id='male' value='m' data-role='none' > <p>"+signup2pagesocial_geneder_male_socialapp+"</p></li><li class='male'><input type='radio' name='gender' id='female' value='f' data-role='none'><p>"+signup2pagesocial_geneder_female_socialapp+"</p></li><li><label>"+signup2pagesocial_birthday_socialapp+"</label></li><li class='birthday'><select data-role='none' id='bdday' style='width:93%;'>\
                      <option value=''>Day</option>\
                                   <option value='01'>1</option>\
                                   <option value='02'>2</option>\
                                   <option value='03'>3</option>\
                                   <option value='04'>4</option>\
                                   <option value='05'>5</option>\
                                   <option value='06'>6</option>\
                                   <option value='07'>7</option>\
                                   <option value='08'>8</option>\
                                   <option value='09'>9</option>\
                                   <option value='10'>10</option>\
                                   <option value='11'>11</option>\
                                   <option value='12'>12</option>\
                                   <option value='13'>13</option>\
                                   <option value='14'>14</option>\
                                   <option value='15'>15</option>\
                                   <option value='16'>16</option>\
                                   <option value='17'>17</option>\
                                   <option value='18'>18</option>\
                                   <option value='19'>19</option>\
                                   <option value='20'>20</option>\
                                   <option value='21'>21</option>\
                                   <option value='22'>22</option>\
                                   <option value='23'>23</option>\
                                   <option value='24'>24</option>\
                                   <option value='25'>25</option>\
                                   <option value='26'>26</option>\
                                   <option value='27'>27</option>\
                                   <option value='28'>28</option>\
                                   <option value='29'>29</option>\
                                   <option value='30'>30</option>\
                                   <option value='31'>31</option>\
                                  </select>\
                                  <br />\
                                  <select data-role='none' id='birthmonthEditPage' style='width:93%;'>\
                                   <option value=''>Month</option>\
                                   <option value='01'>Jan</option>\
                                   <option value='02'>Feb</option>\
                                   <option value='03'>Mar</option>\
                                   <option value='04'>Apr</option>\
                                   <option value='05'>May</option>\
                                   <option value='06'>Jun</option>\
                                   <option value='07'>Jul</option>\
                                   <option value='08'>Aug</option>\
                                   <option value='09'>Sep</option>\
                                   <option value='10'>Oct</option>\
                                   <option value='11'>Nov</option>\
                                   <option value='12'>Dec</option>\
                                  </select> \
                                  <br />\
                                  <select data-role='none' id='birthyearEditPage' style='width:93%;'>\
                                   <option value=''>Year</option>\
                                   <option value='1950'>1950</option>\
                                   <option value='1951'>1951</option>\
                                   <option value='1952'>1952</option>\
                                   <option value='1953'>1953</option>\
                                   <option value='1954'>1954</option>\
                                   <option value='1955'>1955</option>\
                                   <option value='1956'>1956</option>\
                                   <option value='1957'>1957</option>\
                                   <option value='1958'>1958</option>\
                                   <option value='1959'>1959</option>\
                                   <option value='1960'>1960</option>\
                                   <option value='1961'>1961</option>\
                                   <option value='1962'>1962</option>\
                                   <option value='1963'>1963</option>\
                                   <option value='1964'>1964</option>\
                                   <option value='1965'>1965</option>\
                                   <option value='1966'>1966</option>\
                                   <option value='1967'>1967</option>\
                                   <option value='1968'>1968</option>\
                                   <option value='1969'>1969</option>\
                                   <option value='1970'>1970</option>\
                                   <option value='1971'>1971</option>\
                                   <option value='1972'>1972</option>\
                                   <option value='1973'>1973</option>\
                                   <option value='1974'>1974</option>\
                                   <option value='1975'>1975</option>\
                                   <option value='1976'>1976</option>\
                                   <option value='1977'>1977</option>\
                                   <option value='1978'>1978</option>\
                                   <option value='1979'>1979</option>\
                                   <option value='1980'>1980</option>\
                                   <option value='1981'>1981</option>\
                                   <option value='1982'>1982</option>\
                                   <option value='1983'>1983</option>\
                                   <option value='1984'>1984</option>\
                                   <option value='1985'>1985</option>\
                                   <option value='1986'>1986</option>\
                                   <option value='1987'>1987</option>\
                                   <option value='1988'>1988</option>\
                                   <option value='1989'>1989</option>\
                                   <option value='1990'>1990</option>\
                                   <option value='1991'>1991</option>\
                                   <option value='1992'>1992</option>\
                                   <option value='1993'>1993</option>\
                                   <option value='1994'>1994</option>\
                                   <option value='1995'>1995</option>\
                                   <option value='1996'>1996</option>\
                                   <option value='1997'>1997</option>\
                                   <option value='1998'>1998</option>\
                                   <option value='1999'>1999</option>\
                                   <option value='2000'>2000</option>\
                                  </select>\
                                  </li><li><label>LOCATION</label></li><li><input type='text' id='location' name='location'data-role='none'  /></li><li><label>PHONE</label></li><li><input type='tel' id='phone' name='phone' data-role='none' /></li><li><label>ADDRESS</label></li><li><textarea id='saddress' name='address' data-role='none' ></textarea></li><li><label>COUNTRY</label></li><li><select id='country' name='country' class='country' data-role='none' >"+countryoption+"</select></li><li><label>STATE</label></li><li><input type='text' id='state' name='state'data-role='none'  /></li><li><label>CITY</label></li><li><input type='text' id='city' name='city' data-role='none' /></li><li><label>ZIP</label></li><li><input type='text' id='zip' name='zip'data-role='none'  /></li><li><button onclick='signup2social();' class='submit_btn' >SAVE</button></li></ul></div></div>";
			 $('#contentHolder22').css('background', '#edf0f5');
			appendHtml("<div class='page-text'>"+html+"</div>",22,3,'food');


		},
		error: function(response, textStatus, errorThrown)
		{
			console.log("Error : "+JSON.stringify(response));
			console.log("Error : "+textStatus);
			console.log("Error : "+errorThrown.responseText);
		}
	});

}


function showBottom111()
{

	if(document.getElementById('bdday').value!=null)
	{
		cb22(document.getElementById('bdday').value);
	}
}
function cb22(date)
{

	var dt = new Date(date);
	var todaydate = new Date();
	currentMonth = '' + (todaydate.getMonth() + 1),
	currentDay = '' + todaydate.getDate(),
	currentYear = todaydate.getFullYear();
	if (currentMonth.length < 2){
		currentMonth = '0' + currentMonth;
	}
	if (currentDay.length < 2) {
		currentDay = '0' + currentDay;
	}
	currentDate = [currentMonth, currentDay, currentYear].join('/');
	scheduleMonth = '' + (dt.getMonth() + 1),
	scheduleDay = '' + dt.getDate(),
	scheduleYear = dt.getFullYear();
	if (scheduleMonth.length < 2)
	{
		scheduleMonth = '0' + scheduleMonth;
	}
	if (scheduleDay.length < 2)
	{
		scheduleDay = '0' + scheduleDay;
	}
	scheduleDate = [scheduleYear, scheduleMonth, scheduleDay].join('-');

	document.getElementById('bdday').value = scheduleDate;
}
function signup2social()
{
	var genderr="";
	var radios = document.getElementsByName('gender');
	for (var i = 0, length = radios.length; i < length; i++) {
		if (radios[i].checked) {
			// do whatever you want with the checked radio
			genderr=radios[i].value;
			// only one radio can be logically checked, don't check the rest
			break;
		}
	}


	var sel = document.getElementById('country');
	var countryy = sel.options[sel.selectedIndex].value;

	if(document.getElementById("about_me").value=="")
	{
		var message=alert_about_me_socialapp;
		navigator.notification.alert(
				message,  // message
				alertDismissed,         // callback
				social_login_fb_alert_socialapp,            // title
                social_login_fb_alert_ok_socialapp                // buttonName
		);
		document.getElementById('about_me').focus();
	}
	else if(genderr=="")
	{
		var message=alert_select_geneder_socialapp;
		navigator.notification.alert(
				message,  // message
				alertDismissed,         // callback
				social_login_fb_alert_socialapp,            // title
                social_login_fb_alert_ok_socialapp                // buttonName
		);

	}
	else if(document.getElementById("bdday").value=="")
	{
		var message=alert_select_birthdate_socialapp;
		navigator.notification.alert(
				message,  // message
				alertDismissed,         // callback
				social_login_fb_alert_socialapp,            // title
                social_login_fb_alert_ok_socialapp                // buttonName
		);

	}
	else if(document.getElementById("location").value=="")
	{
		var message=alert_select_location_socialapp;
		navigator.notification.alert(
				message,  // message
				alertDismissed,         // callback
				social_login_fb_alert_socialapp,            // title
                social_login_fb_alert_ok_socialapp                // buttonName
		);
		document.getElementById('location').focus();
	}
	else if(document.getElementById("phone").value=="")
	{
		var message=alert_enter_phone_socialapp;
		navigator.notification.alert(
				message,  // message
				alertDismissed,         // callback
				social_login_fb_alert_socialapp,            // title
                social_login_fb_alert_ok_socialapp                // buttonName
		);
		document.getElementById('phone').focus();
	}
	else if(document.getElementById("saddress").value=="")
	{
		var message=alert_enter_address_socialapp;
		navigator.notification.alert(
				message,  // message
				alertDismissed,         // callback
				social_login_fb_alert_socialapp,            // title
                social_login_fb_alert_ok_socialapp                  // buttonName
		);
		document.getElementById('saddress').focus();
	}
	else if(countryy=="")
	{
		var message=alert_enter_country_socialapp;
		navigator.notification.alert(
				message,  // message
				alertDismissed,         // callback
				social_login_fb_alert_socialapp,            // title
                social_login_fb_alert_ok_socialapp                // buttonName
		);
		//document.getElementById('country').focus();
	}
	else if(document.getElementById("state").value=="")
	{
		var message=alert_enter_state_socialapp;
		navigator.notification.alert(
				message,  // message
				alertDismissed,         // callback
				social_login_fb_alert_socialapp,            // title
                social_login_fb_alert_ok_socialapp                 // buttonName
		);
		document.getElementById('state').focus();
	}
	else if(document.getElementById("city").value=="")
	{
		var message=alert_enter_city_socialapp;
		navigator.notification.alert(
				message,  // message
				alertDismissed,         // callback
				social_login_fb_alert_socialapp,            // title
                social_login_fb_alert_ok_socialapp                 // buttonName
		);
		document.getElementById('city').focus();
	}
	else if(document.getElementById("zip").value=="")
	{
		var message=alert_enter_zip_socialapp;
		navigator.notification.alert(
				message,  // message
				alertDismissed,         // callback
				social_login_fb_alert_socialapp,            // title
				social_login_fb_alert_ok_socialapp                  // buttonName
		);
		document.getElementById('zip').focus();
	}
	else
	{
		$('.appypie-loader').show();
		var birthdatee=document.getElementById("bdday").value;

		var wsUrl="http://"+window.localStorage.getItem("reseller")+"/services/social-soap#signUp2Json";
		var soapRequest ='<?xml version="1.0" encoding="utf-8"?> <soap:Envelope xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"  xmlns:xsd="http://www.w3.org/2001/XMLSchema" xmlns:soap="http://schemas.xmlsoap.org/soap/envelope/"> <soap:Body><signUp2Json xmlns=\"http://'+window.localStorage.getItem("reseller")+'/services/social-soap#signUp2Json\"><appId>'+localStorage.getItem('applicationID')+'</appId><userId>'+localStorage.getItem('useridd')+'</userId><phone>'+document.getElementById("phone").value+'</phone><country>'+countryy+'</country><address>'+document.getElementById("saddress").value+'</address><state>'+document.getElementById("state").value+'</state><city>'+document.getElementById("city").value+'</city><zip>'+document.getElementById("zip").value+'</zip><gender>'+genderr+'</gender><aboutMe>'+document.getElementById("about_me").value+'</aboutMe><location>'+document.getElementById("location").value+'</location><birthdate>'+birthdatee+'</birthdate></signUp2Json></soap:Body></soap:Envelope>';
		console.log("SoapRequest : "+ soapRequest);
		$.ajax({
			type: "POST",
			url: wsUrl,
			contentType: "text/xml",
			dataType: "text",
			data: soapRequest,
			success: function(data, status, req)
			{
				console.log("Success : "+req.responseText);
				var strJSON = $(req.responseText).find("return").text();
				var obj = JSON.parse(strJSON);

				indexsocial();
			},
			error: function(response, textStatus, errorThrown)
			{
				console.log("Error : "+JSON.stringify(response));
				console.log("Error : "+textStatus);
				console.log("Error : "+errorThrown.responseText);
			}
		});
	}
}

/* Signup2 Ends*/
function indexsocial()
{
localStorage.uploadtypeWallPost_social = 'text';
localStorage.uploadtype = 'text';
	countrylistvaluetop100=0;
	filtervaluetop100='';

	if(window.localStorage.getItem("layout")=="slidemenu"){
		snapper.close();
	}
	setTimeout(function(){
		$("#mainmenu").empty();
		$("#mainmenu").append(socialMenuSlide);
	},1000);

	latestsocial();
}

var pageno = 1;
var profile = '';
function openLargeImageSocial(url)
{
	console.log("image url---->");
	 window.plugins.photo.show({ videoid:0, videoInfo:url}, function() {}, function() {} );

}
function latestsocial()
{

	$('.appypie-loader').show();
	pageno = 1;
	profile = '';
	var wsUrll="http://"+window.localStorage.getItem("reseller")+"/services/social-soap#getLatestPostsJson";

	var soapRequestt ='<?xml version="1.0" encoding="utf-8"?> <soap:Envelope xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"  xmlns:xsd="http://www.w3.org/2001/XMLSchema" xmlns:soap="http://schemas.xmlsoap.org/soap/envelope/"> <soap:Body><getLatestPostsJson xmlns=\"http://'+window.localStorage.getItem("reseller")+'/services/social-soap#getLatestPostsJson\"><appId>'+localStorage.getItem('applicationID')+'</appId><userId>'+localStorage.getItem('userid')+'</userId><filter></filter><page>1</page></getLatestPostsJson></soap:Body></soap:Envelope>';


	console.log("SoapRequest : "+ soapRequestt);
	$.ajax({
		type: "POST",
		url: wsUrll,
		contentType: "text/xml",
		dataType: "text",
		data: soapRequestt,
		success: function(data, status, req)
		{
			console.log("success dddd : "+ req.responseText);
			var strJSON = $(req.responseText).find("return").text();
			console.log("success gaurav : "+strJSON);
			var obj = JSON.parse(strJSON);
			var totalpages=obj.count/obj.pagesize;
			var outputpagination="";
			if(totalpages>1)
			{
				temp2 = "<div class='section_post_div' style='margin-top:20px;'><div class='socialpost-box' style='background: none; border: none; height: 45px; margin-top:0px; padding-top:0px;'  align='center'> <a href='#' style='font-size: 18px; float: none; font-weight: normal; padding: 5px 16px;' onclick='pagechangelatest();' class='showmorebtn'>"+latestsocial_show_more_socialapp+"</a></div></div></section>";

			}
			else
			{
				temp2="</section>";
			}

			if(obj.data!=null)
			{
				for(var i=0; i<obj.data.length; i++)
				{
				 var username1= obj.data[i].username;
                             var userName2=localStorage.getItem("sNUserName");
                             console.log("username1==="+username1)
                             console.log("username2=="+userName2)
                             //if(username1.trim()==)
                             
                             //alert("sddd"+localStorage.getItem('useridd'))
                             //alert("login"+localStorage.getItem('userid'))
                             var displydelete='none';
                             if(username1==userName2)
                             {
                             displydelete='block';
                             }
                             else
                             {
                             displydelete='none';
                             }
					var countryflag="http://"+window.localStorage.getItem("reseller")+obj.data[i].country_flag;

					profile+="";
					if(obj.data[i].post_type=="video")
					{
						var imageshow="http://"+window.localStorage.getItem("reseller")+"/"+obj.data[i].image;
						var iDforPostReport_social = "staticText$$$" + obj.data[i].id;
                        var iDforPostDelete_social = "staticTextdelete$$$" + obj.data[i].id;
						var profile_image="http://"+window.localStorage.getItem("reseller")+obj.data[i].avatar;
						var video_url="http://"+window.localStorage.getItem("reseller")+"/"+obj.data[i].video;
						 profile+="<div class='section_post_div' id="+obj.data[i].id+">\
                             <div class='socialApp-image'><img src=" + profile_image + "></div>\
                             <div class='tpHead'><span class='blueHead'>" + obj.data[i].username + "</span> posted a new video <span class='social_report_delete' style='display:"+displydelete+"'  id=" + iDforPostDelete_social + " onclick='deletepost_social(this.id);'><img src='images/social-delete.png'></span></div>\
                             <div class='postSection'>\
                             <div class='postContainer'>\
                             <h2>" + obj.data[i].message + "</h2>\
                             <div class='socialPost-video' onclick='videocall(\""+video_url+"\")'>\
                             <video width='100%' height='100%'>\
                             </video>\
                             </div>\
                             </div>\
                             <div class='social-like-comment'>\
                             <div class='social_like'><img src='images/sociel-like.png'> " + obj.data[i].count_like + " Like</div>\
                             <div class='social_comment' onclick='postpage("+obj.data[i].id+");'><img src='images/social-comment.png'>" + obj.data[i].count_comment + " Comment</div>\
                             <div class='social_report_social' id=" + iDforPostReport_social + " onclick='reportpost_social(this.id);'><img src='images/sociel-report.png'>Report Abuse</div>\
							 </div>";
						if (obj.data[i].comments) {
							profile += "<div class='postContainer'>\
								<div class='socialComment'>\
								<ul>";
							var temp_for_loop = 5;
							if (obj.data[i].comments.length < 5) {
								temp_for_loop = obj.data[i].comments.length;
							}
							for (var j = 0; j < temp_for_loop; j++) {
								var comment_user_avator="http://"+window.localStorage.getItem("reseller")+obj.data[i].comments[j].avatar;
								var iDforReport_social = "staticText$$$" + obj.data[i].comments[j].id;
								profile+="<li>\
									<div class='socialC-image'><img src="+comment_user_avator+"></div>\
									<div class='socialcomment-txt'>\
									<div class='commentSocial'><span class='blueHead2'>" + obj.data[i].comments[j].username + " </span>  " + obj.data[i].comments[j].message + "</div>\
									</div>\
									<div class='social_report_social'><a id=" + iDforReport_social + " onclick='reportcomment_social(this.id);'><img src='images/sociel-report.png'> Report Abuse</a></div>\
									</li>";
							}
							if (obj.data[i].comments.length > 5) {
								profile += "<div class='socialView-all' onclick='postpage("+obj.data[i].id+");'><a href='#'>"+social_view_all_socialapp+"</a></div>";
							}
							profile+="</ul>\
								</div>\
								</div>\
								</div>\
								</div>";
						}
						else
						{
							profile+="</div>\
							</div>";
						}

					}
					else if(obj.data[i].post_type=="image")
					{
						var imageshow="http://"+window.localStorage.getItem("reseller")+"/"+obj.data[i].image;
						var profile_image="http://"+window.localStorage.getItem("reseller")+obj.data[i].avatar;
						var iDforPostReport_social = "staticText$$$" + obj.data[i].id;
                        var iDforPostDelete_social = "staticTextdelete$$$" + obj.data[i].id;
						 profile+="<div class='section_post_div' id="+obj.data[i].id+">\
                             <div class='socialApp-image'><img src=" + profile_image + "></div>\
                             <div class='tpHead'><span class='blueHead'>" + obj.data[i].username + "</span> posted a new photo<span class='social_report_delete' style='display:"+displydelete+"'  id=" + iDforPostDelete_social + " onclick='deletepost_social(this.id);'><img src='images/social-delete.png'></span></div>\
                             <div class='postSection'>\
                             <div class='postContainer'>\
                             <h2>" + obj.data[i].message + "</h2>\
                             <div class='socialPost-img'><img src=" + imageshow + " id=" + imageshow + "  onclick='openLargeImageSocial(this.id);'></div>\
                             </div>\
                             <div class='social-like-comment'>\
                             <div class='social_like'><img src='images/sociel-like.png'> " + obj.data[i].count_like + " Like</div>\
                             <div class='social_comment' onclick='postpage("+obj.data[i].id+");'><img src='images/social-comment.png' >" + obj.data[i].count_comment + " Comment</div>\
                             <div class='social_report_social' id=" + iDforPostReport_social + " onclick='reportpost_social(this.id);'><img src='images/sociel-report.png'>Report Abuse</div>\
							 </div>";
						if (obj.data[i].comments) {

							profile += "<div class='postContainer'>\
								<div class='socialComment'>\
								<ul>";
							var temp_for_loop = 5;
							if (obj.data[i].comments.length < 5) {
								temp_for_loop = obj.data[i].comments.length;
							}
							for (var j = 0; j < temp_for_loop; j++) {
								var comment_user_avator="http://"+window.localStorage.getItem("reseller")+obj.data[i].comments[j].avatar;
								var iDforReport_social = "staticText$$$" + obj.data[i].comments[j].id;
								profile+="<li>\
									<div class='socialC-image'><img src="+comment_user_avator+"></div>\
									<div class='socialcomment-txt'>\
									<div class='commentSocial'><span class='blueHead2'>" + obj.data[i].comments[j].username + " </span>  " + obj.data[i].comments[j].message + "</div>\
									</div>\
									<div class='social_report_social'><a id=" + iDforReport_social + " onclick='reportcomment_social(this.id);'><img src='images/sociel-report.png'> Report Abuse</a></div>\
									</li>";
							}
							if (obj.data[i].comments.length > 5) {
								profile += "<div class='socialView-all' onclick='postpage("+obj.data[i].id+");'><a href='#'>"+social_view_all_socialapp+"</a></div>";
							}
							profile+="</ul>\
								</div>\
								</div>\
								</div>\
								</div>";
						}
						else
						{
							profile+="</div>\
							</div>";

						}

					}
					else
					{
						var profile_image="http://"+window.localStorage.getItem("reseller")+obj.data[i].avatar;
						var iDforPostReport_social = "staticText$$$" + obj.data[i].id;
                        var iDforPostDelete_social = "staticTextdelete$$$" + obj.data[i].id;
						profile+="<div class='section_post_div' id="+obj.data[i].id+">\
                            <div class='socialApp-image'><img src=" + profile_image + "></div>\
                            <div class='tpHead'><span class='blueHead'>" + obj.data[i].username + "</span> posted a new status<span class='social_report_delete' style='display:"+displydelete+"'  id=" + iDforPostDelete_social + " onclick='deletepost_social(this.id);'><img src='images/social-delete.png'></span></div>\
                            <div class='postSection'>\
                            <div class='postContainer'>\
                            <p class='capsHead'></p>\
                            <h2>" + obj.data[i].message + "</h2>\
                            </div>\
                            <div class='social-like-comment'>\
                            <div class='social_like'><img src='images/sociel-like.png'> " + obj.data[i].count_like + " Like</div>\
                            <div class='social_comment' onclick='postpage("+obj.data[i].id+");'><img src='images/social-comment.png' >" + obj.data[i].count_comment + " Comment</div>\
                            <div class='social_report_social' id=" + iDforPostReport_social + " onclick='reportpost_social(this.id);'><img src='images/sociel-report.png'>Report Abuse</div>\
						    </div>";

						if (obj.data[i].comments) {

							profile += "<div class='postContainer'>\
								<div class='socialComment'>\
								<ul>";
							var temp_for_loop = 5;
							if (obj.data[i].comments.length < 5) {
								temp_for_loop = obj.data[i].comments.length;
							}
							for (var j = 0; j < temp_for_loop; j++) {
								var comment_user_avator="http://"+window.localStorage.getItem("reseller")+obj.data[i].comments[j].avatar;
								var iDforReport_social = "staticText$$$" + obj.data[i].comments[j].id;
								profile+="<li>\
									<div class='socialC-image'><img src="+comment_user_avator+"></div>\
									<div class='socialcomment-txt'>\
									<div class='commentSocial'><span class='blueHead2'>" + obj.data[i].comments[j].username + " </span>  " + obj.data[i].comments[j].message + "</div>\
									</div>\
									<div class='social_report_social'><a id=" + iDforReport_social + " onclick='reportcomment_social(this.id);'><img src='images/sociel-report.png'> Report Abuse</a></div>\
									</li>";
							}
							if (obj.data[i].comments.length > 5) {
								profile += "<div class='socialView-all' onclick='postpage("+obj.data[i].id+");'><a href='#'>"+social_view_all_socialapp+"</a></div>";
							}
							profile+="</ul>\
								</div>\
								</div>\
								</div>\
								</div>";
						}
						else
						{
							profile+="</div>\
							</div>";

						}

					}
				}
			}

			else
			{

			}
			var html="<section class=' magentocl' style=''>\
                <div class='socialWall-head'>\
                <ul>\
                <li><a href='#' onclick='MYProfile();'><img src='images/profile-icon.png'></a></li>\
                <li class='ddsf'><input data-role='none' type='text'  class='filled_inp' placeholder="+placeholder_search_socialapp+" id='searchsocialtext1'>\
                <input  data-role='none' type='button' onclick='searchsocialfunction(\"searchsocialtext1\");' class='searchbtn' value='Search'></li>\
                <li> </li>\
                </ul>\
                </div>\
                <div class='socialWall-container'>\
                <div class='app-btn'>\
                <ul>\
                <li id='updatestatus_social' onclick='select_for_status_update_social();'>Update Status</li>\
                <li id='addphotovideo_social' class='sociel-active' onclick='select_for_post_upload_social();' >Add Photo/Video</li>\
                </ul>\
                </div>\
                <div class='appPost-middlepan'>\
                <div class='wallApp-video' style='display:none;' id='video_add_wallpost_social'>\
                <div class='updatePhoto'>\
                <textarea name='' cols='' rows='' id='captionnnWallPost_video_social' placeholder='Say something about this video...' style='font-size:16px;'></textarea>\
                <video width='100%' height='100%' id='video_add_wallPost_show_social' src='images/20140725_192046.mp4' controls>\
                </video> \
                <div class='post-box'><a onclick='upload();' href='#'>Post</a></div>\
                </div>\
                </div>\
                <div class='appPost-box' style='display:none;' id='image_add_wallPost_social'>\
                <div class='updatePhoto'>\
                <textarea name='' cols='' rows='' id='captionnnWallPost_image_social' placeholder="+captionnnWallPost_image_social_saysomething_socialapp+" style='font-size:16px;'></textarea>\
                <div class='appPost-box'><img id='image_add_wallPost_show_social' src='images/post-img.png'></div>\
                <div class='post-box'><a href='#' onclick='upload();'>Post</a></div>\
                </div>\
                </div>\
                <div class='socialUpload-file' id='photo_video_selection_social'  style='display:none;'>  \
                <div class='sUpload-pan'>\
                <div class='suploadFile' onclick='image_upload();'><a href='#'><img src='images/social-upload-img.png'></a> <span><a href='#'>Upload Image</a></span></div>\
                <div class='suploadFile suploadVideo' onclick='confirm_box();'><a href='#'><img src='images/social-upload-video.png'></a> <span><a href='#'>Upload Video</a></span></div>\
                </div>\
                </div>\
                <div class='appPost-box' id='textUploadWall_social'>      	\
                <textarea name='' data-role='none' cols='' rows='' id='captionnnWallPost_social' style='font-size:16px;'></textarea>\
                <div class='post-box'><span></span> <a onclick='upload();' href='#'>Post</a></div>\
                </div>";
                html+=profile;
                
               html+=" </div>\
                </div>";
                html+=temp2;
			console.log("check----"+html+" "+socialMenu);
			$('#contentHolder20').css('background', '#edf0f5');
			appendHtml(html+" "+socialMenu,20,1,'food');

		},
		error: function(response, textStatus, errorThrown)
		{
			console.log("Error : "+JSON.stringify(response));
			console.log("Error : "+textStatus);
			console.log("Error : "+errorThrown.responseText);
		}
	});

}

function pagechangelatest()
{


	pageno += 1;
	var wsUrll="http://"+window.localStorage.getItem("reseller")+"/services/social-soap#getLatestPostsJson";

	var soapRequestt ='<?xml version="1.0" encoding="utf-8"?> <soap:Envelope xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"  xmlns:xsd="http://www.w3.org/2001/XMLSchema" xmlns:soap="http://schemas.xmlsoap.org/soap/envelope/"> <soap:Body><getLatestPostsJson xmlns=\"http://'+window.localStorage.getItem("reseller")+'/services/social-soap#getLatestPostsJson\"><appId>'+localStorage.getItem('applicationID')+'</appId><userId>'+localStorage.getItem('userid')+'</userId><filter></filter><page>'+pageno+'</page></getLatestPostsJson></soap:Body></soap:Envelope>';


	console.log("SoapRequest : "+ soapRequestt);
	$.ajax({
		type: "POST",
		url: wsUrll,
		contentType: "text/xml",
		dataType: "text",
		data: soapRequestt,
		success: function(data, status, req)
		{
			console.log("success dddd : "+ req.responseText);
			var strJSON = $(req.responseText).find("return").text();
			console.log("success gaurav : "+strJSON);
			var obj = JSON.parse(strJSON);
			var totalpages=obj.count/obj.pagesize;
			var outputpagination="";
			if(totalpages>pageno)
			{
				temp2 = "<div class='section_post_div' style='margin-top:20px;'><div class='socialpost-box' style='background: none; border: none; height: 45px; margin-top:0px; padding-top:0px;'  align='center'> <a href='#' style='font-size: 18px; float: none; font-weight: normal; padding: 5px 16px;' onclick='pagechangelatest();'>"+latestsocial_show_more_socialapp+"</a></div></div></section>";
			}
			else
			{
				temp2="</section>";
			}

			if(obj.data!=null)
			{
				for(var i=0; i<obj.data.length; i++)
				{
           
           
           var username1= obj.data[i].username;
           var userName2=localStorage.getItem("sNUserName");
           console.log("username1==="+username1)
           console.log("username2=="+userName2)
           var displydelete='none';
           if(username1==userName2)
           {
           displydelete='block';
           }
           else
           {
           displydelete='none';
           }
           

					var countryflag="http://"+window.localStorage.getItem("reseller")+obj.data[i].country_flag;


					if(obj.data[i].post_type=="video")
					{
						var imageshow="http://"+window.localStorage.getItem("reseller")+"/"+obj.data[i].image;

						var profile_image="http://"+window.localStorage.getItem("reseller")+obj.data[i].avatar;
						var video_url="http://"+window.localStorage.getItem("reseller")+"/"+obj.data[i].video;
						var iDforPostReport_social = "staticText$$$" + obj.data[i].id;
                       var iDforPostDelete_social = "staticTextdelete$$$" + obj.data[i].id;
						 profile+="<div class='section_post_div' id="+obj.data[i].id+">\
		                      <div class='socialApp-image'><img src=" + profile_image + "></div>\
		                      <div class='tpHead'><span class='blueHead'>" + obj.data[i].username + "</span> posted a new video<span class='social_report_delete' style='display:"+displydelete+"'  id=" + iDforPostDelete_social + " onclick='deletepost_social(this.id);'><img src='images/social-delete.png'></span></div>\
		                      <div class='postSection'>\
		                      <div class='postContainer'>\
		                      <h2>" + obj.data[i].message + "</h2>\
		                      <div class='socialPost-video' onclick='videocall(\""+video_url+"\")'>\
		                      <video width='100%' height='100%'>\
		                      </video>\
		                      </div>\
		                      </div>\
		                      <div class='social-like-comment'>\
		                      <div class='social_like'><img src='images/sociel-like.png'> " + obj.data[i].count_like + " Like</div>\
		                      <div class='social_comment' onclick='postpage("+obj.data[i].id+");'><img src='images/social-comment.png'>" + obj.data[i].count_comment + " Comment</div>\
		                      <div class='social_report_social' id=" + iDforPostReport_social + " onclick='reportpost_social(this.id);'><img src='images/sociel-report.png'>Report Abuse</div>\
							   </div>";
						if (obj.data[i].comments) {
							profile += "<div class='postContainer'>\
								<div class='socialComment'>\
								<ul>";
							var temp_for_loop = 5;
							if (obj.data[i].comments.length < 5) {
								temp_for_loop = obj.data[i].comments.length;
							}
							for (var j = 0; j < temp_for_loop; j++) {
								var comment_user_avator="http://"+window.localStorage.getItem("reseller")+obj.data[i].comments[j].avatar;
								var iDforReport_social = "staticText$$$" + obj.data[i].comments[j].id;
								profile+="<li>\
									<div class='socialC-image'><img src="+comment_user_avator+"></div>\
									<div class='socialcomment-txt'>\
									<div class='commentSocial'><span class='blueHead2'>" + obj.data[i].comments[j].username + " </span>  " + obj.data[i].comments[j].message + "</div>\
									</div>\
									<div class='social_report_social'><a id=" + iDforReport_social + " onclick='reportcomment_social(this.id);'><img src='images/sociel-report.png'> Report Abuse</a></div>\
									</li>";
							}
							if (obj.data[i].comments.length > 5) {
								profile += "<div class='socialView-all' onclick='postpage("+obj.data[i].id+");'><a href='#'>"+social_view_all_socialapp+"</a></div>";
							}
							profile+="</ul>\
								</div>\
								</div>\
								</div>\
								</div>";
						}
						else
						{
							profile+="</div>\
								</div>";
						}

					}
					else if(obj.data[i].post_type=="image")
					{
						var imageshow="http://"+window.localStorage.getItem("reseller")+"/"+obj.data[i].image;
						var profile_image="http://"+window.localStorage.getItem("reseller")+obj.data[i].avatar;
						var iDforPostReport_social = "staticText$$$" + obj.data[i].id;
                     var iDforPostDelete_social = "staticTextdelete$$$" + obj.data[i].id;
						profile+="<div class='section_post_div' id="+obj.data[i].id+">\
		                      <div class='socialApp-image'><img src=" + profile_image + "></div>\
		                      <div class='tpHead'><span class='blueHead'>" + obj.data[i].username + "</span> posted a new photo<span class='social_report_delete' style='display:"+displydelete+"'  id=" + iDforPostDelete_social + " onclick='deletepost_social(this.id);'><img src='images/social-delete.png'></span></div>\
		                      <div class='postSection'>\
		                      <div class='postContainer'>\
		                      <h2>" + obj.data[i].message + "</h2>\
		                      <div class='socialPost-img'><img src=" + imageshow + " id=" + imageshow + "  onclick='openLargeImageSocial(this.id);'></div>\
		                      </div>\
		                      <div class='social-like-comment'>\
		                      <div class='social_like'><img src='images/sociel-like.png'> " + obj.data[i].count_like + " Like</div>\
		                      <div class='social_comment' onclick='postpage("+obj.data[i].id+");'><img src='images/social-comment.png' >" + obj.data[i].count_comment + " Comment</div>\
		                      <div class='social_report_social' style='display:"+displydelete+"' id=" + iDforPostReport_social + " onclick='reportpost_social(this.id);'><img src='images/sociel-report.png'>Report Abuse</div>\
							  </div>";
						if (obj.data[i].comments) {

							profile += "<div class='postContainer'>\
								<div class='socialComment'>\
								<ul>";
							var temp_for_loop = 5;
							if (obj.data[i].comments.length < 5) {
								temp_for_loop = obj.data[i].comments.length;
							}


							for (var j = 0; j < temp_for_loop; j++) {
								var comment_user_avator="http://"+window.localStorage.getItem("reseller")+obj.data[i].comments[j].avatar;
								var iDforReport_social = "staticText$$$" + obj.data[i].comments[j].id;
								profile+="<li>\
									<div class='socialC-image'><img src="+comment_user_avator+"></div>\
									<div class='socialcomment-txt'>\
									<div class='commentSocial'><span class='blueHead2'>" + obj.data[i].comments[j].username + " </span>  " + obj.data[i].comments[j].message + "</div>\
									</div>\
									<div class='social_report_social'><a id=" + iDforReport_social + " onclick='reportcomment_social(this.id);'><img src='images/sociel-report.png'> Report Abuse</a></div>\
									</li>";
							}
							if (obj.data[i].comments.length > 5) {
								profile += "<div class='socialView-all' onclick='postpage("+obj.data[i].id+");'><a href='#'>"+social_view_all_socialapp+"</a></div>";
							}
							profile+="</ul>\
								</div>\
								</div>\
								</div>\
								</div>";
						}
						else
						{
							profile+="</div>\
								</div>";

						}

					}
					else
					{
						var profile_image="http://"+window.localStorage.getItem("reseller")+obj.data[i].avatar;
						var iDforPostReport_social = "staticText$$$" + obj.data[i].id;
                    var iDforPostDelete_social = "staticTextdelete$$$" + obj.data[i].id;
						profile+="<div class='section_post_div' id="+obj.data[i].id+">\
		                      <div class='socialApp-image'><img src=" + profile_image + "></div>\
		                      <div class='tpHead'><span class='blueHead'>" + obj.data[i].username + "</span> posted a new status<span class='social_report_delete' style='display:"+displydelete+"'  id=" + iDforPostDelete_social + " onclick='deletepost_social(this.id);'><img src='images/social-delete.png'></span></div>\
		                      <div class='postSection'>\
		                      <div class='postContainer'>\
		                      <p class='capsHead'></p>\
		                      <h2>" + obj.data[i].message + "</h2>\
		                      </div>\
		                      <div class='social-like-comment'>\
		                      <div class='social_like'><img src='images/sociel-like.png'> " + obj.data[i].count_like + " Like</div>\
		                      <div class='social_comment' onclick='postpage("+obj.data[i].id+");'><img src='images/social-comment.png' >" + obj.data[i].count_comment + " Comment</div>\
		                      <div class='social_report_social' id=" + iDforPostReport_social + " onclick='reportpost_social(this.id);'><img src='images/sociel-report.png'>Report Abuse</div>\
							  </div>";

						if (obj.data[i].comments) {

							profile += "<div class='postContainer'>\
								<div class='socialComment'>\
								<ul>";
							var temp_for_loop = 5;
							if (obj.data[i].comments.length < 5) {
								temp_for_loop = obj.data[i].comments.length;
							}
							for (var j = 0; j < temp_for_loop; j++) {
								var comment_user_avator="http://"+window.localStorage.getItem("reseller")+obj.data[i].comments[j].avatar;
								var iDforReport_social = "staticText$$$" + obj.data[i].comments[j].id;
								profile+="<li>\
									<div class='socialC-image'><img src="+comment_user_avator+"></div>\
									<div class='socialcomment-txt'>\
									<div class='commentSocial'><span class='blueHead2'>" + obj.data[i].comments[j].username + " </span>  " + obj.data[i].comments[j].message + "</div>\
									</div>\
									<div class='social_report_social'><a id=" + iDforReport_social + " onclick='reportcomment_social(this.id);'><img src='images/sociel-report.png'> Report Abuse</a></div>\
									</li>";
							}
							if (obj.data[i].comments.length > 5) {
								profile += "<div class='socialView-all' onclick='postpage("+obj.data[i].id+");'><a href='#'>"+social_view_all_socialapp+"</a></div>";
							}
							profile+="</ul>\
								</div>\
								</div>\
								</div>\
								</div>";
						}
						else
						{
							profile+="</div>\
								</div>";

						}

					}
				}
			}

			else
			{

			}
			 var html="<section class=' magentocl' style=''>\
                 <div class='socialWall-head'>\
                 <ul>\
                 <li><a href='#' onclick='MYProfile();'><img src='images/profile-icon.png'></a></li>\
                 <li class='ddsf'><input data-role='none' type='text'  class='filled_inp' placeholder="+placeholder_search_socialapp+" id='searchsocialtext1'>\
                 <input  data-role='none'type='button' onclick='searchsocialfunction(\"searchsocialtext1\");' class='searchbtn' value='Search'></li>\
                 <li> </li>\
                 </ul>\
                 </div>\
                 <div class='socialWall-container'>\
                 <div class='app-btn'>\
                 <ul>\
                 <li id='updatestatus_social' onclick='select_for_status_update_social();'>Update Status</li>\
                 <li id='addphotovideo_social' class='sociel-active' onclick='select_for_post_upload_social();' >Add Photo/Video</li>\
                 </ul>\
                 </div>\
                 <div class='appPost-middlepan'>\
                 <div class='wallApp-video' style='display:none;' id='video_add_wallpost_social'>\
                 <div class='updatePhoto'>\
                 <textarea name='' cols='' rows='' id='captionnnWallPost_video_social' placeholder="+captionnnWallPost_image_social_saysomething_video_socialapp+" style='font-size:16px;'></textarea>\
                 <video width='100%' height='100%' id='video_add_wallPost_show_social' src='images/20140725_192046.mp4' controls>\
                 </video> \
                 <div class='post-box'><a onclick='upload();' href='#'>Post</a></div>\
                 </div>\
                 </div>\
                 <div class='appPost-box' style='display:none;' id='image_add_wallPost_social'>\
                 <div class='updatePhoto'>\
                 <textarea name='' cols='' rows='' id='captionnnWallPost_image_social' placeholder="+captionnnWallPost_image_social_saysomething_socialapp+" style='font-size:16px;'></textarea>\
                 <div class='appPost-box'><img id='image_add_wallPost_show_social' src='images/post-img.png'></div>\
                 <div class='post-box'><a href='#' onclick='upload();'>Post</a></div>\
                 </div>\
                 </div>\
                 <div class='socialUpload-file' id='photo_video_selection_social'  style='display:none;'>  \
                 <div class='sUpload-pan'>\
                 <div class='suploadFile' onclick='image_upload();'><a href='#'><img src='images/social-upload-img.png'></a> <span><a href='#'>Upload Image</a></span></div>\
                 <div class='suploadFile suploadVideo' onclick='confirm_box();'><a href='#'><img src='images/social-upload-video.png'></a> <span><a href='#'>Upload Video</a></span></div>\
                 </div>\
                 </div>\
                 <div class='appPost-box' id='textUploadWall_social'>      	\
                 <textarea name='' data-role='none' cols='' rows='' id='captionnnWallPost_social' style='font-size:16px;'></textarea>\
                 <div class='post-box'><span></span> <a onclick='upload();' href='#'>Post</a></div>\
                 </div>";
                 html+=profile;
                 html+=" </div>\
                 </div>";
                 html+=temp2;
                 $('#contentHolder20').css('background', '#edf0f5');
			appendHtml(html+" "+socialMenu,20,1,'food');


		},
		error: function(response, textStatus, errorThrown)
		{
			console.log("Error : "+JSON.stringify(response));
			console.log("Error : "+textStatus);
			console.log("Error : "+errorThrown.responseText);
		}
	});
}

function videocall(url)
{
	toaster.liveVideoPlayMethodSocial(url);
	}

function klustersocial()
{

	if(window.localStorage.getItem("layout")=="slidemenu"){
		snapper.close();
	}

	$('.appypie-loader').show();
	var wsUrll="http://"+window.localStorage.getItem("reseller")+"/services/social-soap#klusterJson";
	var soapRequestt ='<?xml version="1.0" encoding="utf-8"?> <soap:Envelope xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"  xmlns:xsd="http://www.w3.org/2001/XMLSchema" xmlns:soap="http://schemas.xmlsoap.org/soap/envelope/"> <soap:Body><klusterJson xmlns=\"http://'+window.localStorage.getItem("reseller")+'/services/social-soap#klusterJson\"><appId>'+localStorage.getItem('applicationID')+'</appId><userId>'+localStorage.getItem('userid')+'</userId><page>1</page></klusterJson></soap:Body></soap:Envelope>';
	console.log("SoapRequest : "+ soapRequestt);
	$.ajax({
		type: "POST",
		url: wsUrll,
		contentType: "text/xml",
		dataType: "text",
		data: soapRequestt,
		success: function(data, status, req)
		{
			var strJSON = $(req.responseText).find("return").text();
			console.log("success kluster gaurav : "+strJSON);
			var obj = JSON.parse(strJSON);
			var output="";


			var totalpages=obj.count/obj.pagesize;
			var outputpagination="";
			if(totalpages>1)
			{
				outputpagination="<div class='socialpost-box'><div class='pager'><span class='pager-item title'>"+social_post_socialapp+"</span>"
					var totalpagesint = parseInt(totalpages)
					if(totalpages>totalpagesint)
					{
						totalpagesint+=1;
					}
				for(var k=1;k<=totalpagesint;k++)
				{
					if(k==1)
					{
						outputpagination+="<a class='pager-item current' href='#'>"+k+"</a>"
					}
					else
					{
						outputpagination+="<a id='"+k+"' class='pager-item' href='#' onclick='pagechangekluster(this.id)'>"+k+"</a>"
					}
				}
				outputpagination+="</div></div>";
			}
			if(obj.data!=null)
			{
				for(var i=0;i<obj.data.length;i++)
				{
					output+="<li id='"+obj.data[i].id+"' onclick='innerkluster(this.id);'><a href='#'><span class='f-left'>"+obj.data[i].kluster+"</span></a></li>";
				}
			}
			 var html="<div id='appypie-search-section' class='social-search'><input type='text' id='searchsocialtext3' data-role='none' class='filled_inp' value='' placeholder="+placeholder_search_socialapp+"><a href='#' onclick='searchsocialfunction(\"searchsocialtext3\");' class='searchBtn' data-role='none'>"+without_palceholder_search_socialapp+"</a><a href='#' class='social-uploadBtn' onclick='capturepage();'><img src='images/social-upload.png' alt=''/></a></div><div id='middle_page' class='social-inner-page'><div class='socialpost-box'><ul class='user_msg kluster'>"+output+"</ul></div>"+outputpagination+"</div>";
			 $('#contentHolder21').css('background', '#edf0f5');
			 appendHtml(html+" "+socialMenu,21,2,'food');
			

		},
		error: function(response, textStatus, errorThrown)
		{
			console.log("Error : "+JSON.stringify(response));
			console.log("Error : "+textStatus);
			console.log("Error : "+errorThrown.responseText);
		}
	});

}
function pagechangekluster(pageid)
{

	$('.appypie-loader').show();
	var wsUrll="http://"+window.localStorage.getItem("reseller")+"/services/social-soap#klusterJson";
	var soapRequestt ='<?xml version="1.0" encoding="utf-8"?> <soap:Envelope xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"  xmlns:xsd="http://www.w3.org/2001/XMLSchema" xmlns:soap="http://schemas.xmlsoap.org/soap/envelope/"> <soap:Body><klusterJson xmlns=\"http://'+window.localStorage.getItem("reseller")+'/services/social-soap#klusterJson\"><appId>'+localStorage.getItem('applicationID')+'</appId><userId>'+localStorage.getItem('userid')+'</userId><page>1</page></klusterJson></soap:Body></soap:Envelope>';
	console.log("SoapRequest : "+ soapRequestt);
	$.ajax({
		type: "POST",
		url: wsUrll,
		contentType: "text/xml",
		dataType: "text",
		data: soapRequestt,
		success: function(data, status, req)
		{
			var strJSON = $(req.responseText).find("return").text();
			console.log("success kluster gaurav : "+strJSON);
			var obj = JSON.parse(strJSON);
			var output="";


			var totalpages=obj.count/obj.pagesize;
			var outputpagination="";
			if(totalpages>1)
			{
				outputpagination="<div class='socialpost-box'><div class='pager'><span class='pager-item title'>"+social_post_socialapp+"</span>";

				var totalpagesint = parseInt(totalpages)
				if(totalpages>totalpagesint)
				{
					totalpagesint+=1;
				}
				for(var k=1;k<=totalpagesint;k++)
				{
					if(k==pageid)
					{
						outputpagination+="<a class='pager-item current' href='#'>"+k+"</a>"
					}
					else
					{
						outputpagination+="<a id='"+k+"' class='pager-item' href='#' onclick='pagechangelatest(this.id)'>"+k+"</a>"
					}
				}
				outputpagination+="</div></div>";
			}
			if(obj.data!=null)
			{
				for(var i=0;i<obj.data.length;i++)
				{
					output+="<li id='"+obj.data[i].id+"' onclick='innerkluster(this.id);'><a href='#'><span class='f-left'>"+obj.data[i].kluster+"</span></a></li>";
				}
			}
			var html="<div id='appypie-search-section' class='social-search'><input type='text' id='searchsocialtext4' data-role='none' class='filled_inp' value='' placeholder="+placeholder_search_socialapp+"><a href='#' onclick='searchsocialfunction(\"searchsocialtext4\");' class='searchBtn' data-role='none'>"+without_palceholder_search_socialapp+"</a><a href='#' class='social-uploadBtn' onclick='capturepage();'><img src='images/social-upload.png' alt=''/></a></div><div id='middle_page' class='social-inner-page'><div class='socialpost-box'><ul class='user_msg kluster'>"+output+"</ul></div>"+outputpagination+"</div>";
			$('#contentHolder21').css('background', '#edf0f5');
			appendHtml(html+" "+socialMenu,21,2,'food');

		},
		error: function(response, textStatus, errorThrown)
		{
			console.log("Error : "+JSON.stringify(response));
			console.log("Error : "+textStatus);
			console.log("Error : "+errorThrown.responseText);
		}
	});
}
function innerkluster(klusterid)
{

	$('.appypie-loader').show();
	var wsUrll="http://"+window.localStorage.getItem("reseller")+"/services/social-soap#klusterListJson";
	var soapRequestt ='<?xml version="1.0" encoding="utf-8"?> <soap:Envelope xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"  xmlns:xsd="http://www.w3.org/2001/XMLSchema" xmlns:soap="http://schemas.xmlsoap.org/soap/envelope/"> <soap:Body><klusterListJson xmlns=\"http://'+window.localStorage.getItem("reseller")+'/services/social-soap#klusterListJson\"><appId>'+localStorage.getItem('applicationID')+'</appId><userId>'+localStorage.getItem('userid')+'</userId><klusterId>'+klusterid+'</klusterId></klusterListJson></soap:Body></soap:Envelope>';
	console.log("SoapRequest : "+ soapRequestt);
	$.ajax({
		type: "POST",
		url: wsUrll,
		contentType: "text/xml",
		dataType: "text",
		data: soapRequestt,
		success: function(data, status, req)
		{
			var strJSON = $(req.responseText).find("return").text();
			console.log("success kluster inner gaurav : "+strJSON);
			var obj = JSON.parse(strJSON);
			var output="";


			var totalpages=obj.count/obj.pagesize;
			var outputpagination="";
			if(totalpages>1)
			{
				outputpagination="<div class='socialpost-box'><div class='pager'><span class='pager-item title'>"+social_post_socialapp+"</span>"
					var totalpagesint = parseInt(totalpages)
					if(totalpages>totalpagesint)
					{
						totalpagesint+=1;
					}
				for(var k=1;k<=totalpagesint;k++)
				{
					if(k==1)
					{
						outputpagination+="<a class='pager-item current' href='#'>"+k+"</a>"
					}
					else
					{
						outputpagination+="<a id='"+k+"' class='pager-item' href='#' onclick='pagechangeklusterinner(this.id)'>"+k+"</a>"
					}
				}
				outputpagination+="</div></div>";
			}
			if(obj.data!=null)
			{
				for(var i=0; i<obj.data.length; i++)
				{
					var countryflag="http://"+window.localStorage.getItem("reseller")+obj.data[i].country_flag;
					if(obj.data[i].post_type=="video")
					{
						var imageshow="http://"+window.localStorage.getItem("reseller")+"/"+obj.data[i].image;
						if(obj.data[i].show_flag==1)
						{

							output+="<div class='socialpost-box letest' onclick='postpage("+obj.data[i].id+");'><img width='74' height='54' src="+imageshow+" alt='' class='f-left'><div class='video_text'><h4>"+obj.data[i].message+"</h4><span>"+obj.data[i].addedon+" by <a href='#' class='orangeTxt'>"+obj.data[i].username+"</a></span><span class='flag'><img width='16' height='16' alt='' src="+countryflag+">"+obj.data[i].country+"</span></div> <div class='right-content'><a  href='#' class='like-icon'>"+obj.data[i].count_like+"</a><a class='coment-icon' href='#'>"+obj.data[i].count_comment+"</a></div></div>";
						}
						else
						{
							output+="<div class='socialpost-box letest' onclick='postpage("+obj.data[i].id+");'><img width='74' height='54' src="+imageshow+" alt='' class='f-left'><div class='video_text'><h4>"+obj.data[i].message+"</h4><span>"+obj.data[i].addedon+" by <a href='#' class='orangeTxt'>"+obj.data[i].username+"</a></span></div> <div class='right-content'><a  href='#' class='like-icon'>"+obj.data[i].count_like+"</a><a class='coment-icon' href='#'>"+obj.data[i].count_comment+"</a></div></div>";
						}
					}
					else if(obj.data[i].post_type=="image")
					{
						var imageshow="http://"+window.localStorage.getItem("reseller")+"/"+obj.data[i].image;
						if(obj.data[i].show_flag==1)
						{

							output+="<div class='socialpost-box letest' onclick='postpage("+obj.data[i].id+");'><img width='74' height='54' src="+imageshow+" alt='' class='f-left'><div class='video_text'><h4>"+obj.data[i].message+"</h4><span>"+obj.data[i].addedon+" by <a href='#' class='orangeTxt'>"+obj.data[i].username+"</a></span><span class='flag'><img width='16' height='16' alt='' src="+countryflag+">"+obj.data[i].country+"</span></div> <div class='right-content'><a  href='#' class='like-icon'>"+obj.data[i].count_like+"</a><a class='coment-icon' href='#'>"+obj.data[i].count_comment+"</a></div></div>";
						}
						else
						{
							output+="<div class='socialpost-box letest' onclick='postpage("+obj.data[i].id+");'><img width='74' height='54' src="+imageshow+" alt='' class='f-left'><div class='video_text'><h4>"+obj.data[i].message+"</h4><span>"+obj.data[i].addedon+" by <a href='#' class='orangeTxt'>"+obj.data[i].username+"</a></span></div> <div class='right-content'><a  href='#' class='like-icon'>"+obj.data[i].count_like+"</a><a class='coment-icon' href='#'>"+obj.data[i].count_comment+"</a></div></div>";
						}
					}
					else
					{
						if(obj.data[i].show_flag==1)
						{

							output+="<div class='socialpost-box letest' onclick='postpage("+obj.data[i].id+");'><div class='video_text'><h4>"+obj.data[i].message+"</h4><span>"+obj.data[i].addedon+" by <a href='#' class='orangeTxt'>"+obj.data[i].username+"</a></span><span class='flag'><img width='16' height='16' alt='' src='"+countryflag+"'> "+obj.data[i].country+"</span></div><div class='right-content'><a  href='#' class='like-icon'>"+obj.data[i].count_like+"</a><a class='coment-icon' href='#'>"+obj.data[i].count_comment+"</a></div></div>";
						}
						else
						{
							output+="<div class='socialpost-box letest' onclick='postpage("+obj.data[i].id+");'><div class='video_text'><h4>"+obj.data[i].message+"</h4><span>"+obj.data[i].addedon+" by <a href='#' class='orangeTxt'>"+obj.data[i].username+"</a></span></div><div class='right-content'><a  href='#' class='like-icon'>"+obj.data[i].count_like+"</a><a class='coment-icon' href='#'>"+obj.data[i].count_comment+"</a></div></div>";
						}
					}
				}
			}

			 var html="<div id='appypie-search-section' class='social-search'><input type='text' id='searchsocialtext5' data-role='none' class='filled_inp' value='' placeholder="+placeholder_search_socialapp+"><a href='#' onclick='searchsocialfunction(\"searchsocialtext5\");' class='searchBtn' data-role='none'>"+without_palceholder_search_socialapp+"</a><a href='#' class='social-uploadBtn' onclick='capturepage();'><img src='images/social-upload.png' alt=''/></a></div><div id='middle_page' class='social-inner-page'>"+output+"</div>"+outputpagination+"";
			 $('#contentHolder22').css('background', '#edf0f5');
			 appendHtml(html+" "+socialMenu,22,3,'food');
		},
		error: function(response, textStatus, errorThrown)
		{
			console.log("Error : "+JSON.stringify(response));
			console.log("Error : "+textStatus);
			console.log("Error : "+errorThrown.responseText);
		}
	});
}
function pagechangeklusterinner(pageid)
{

	$('.appypie-loader').show();
	var wsUrll="http://"+window.localStorage.getItem("reseller")+"/services/social-soap#klusterListJson";
	var soapRequestt ='<?xml version="1.0" encoding="utf-8"?> <soap:Envelope xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"  xmlns:xsd="http://www.w3.org/2001/XMLSchema" xmlns:soap="http://schemas.xmlsoap.org/soap/envelope/"> <soap:Body><klusterListJson xmlns=\"http://'+window.localStorage.getItem("reseller")+'/services/social-soap#klusterListJson\"><appId>'+localStorage.getItem('applicationID')+'</appId><userId>'+localStorage.getItem('userid')+'</userId><klusterId>'+klusterid+'</klusterId></klusterListJson></soap:Body></soap:Envelope>';
	console.log("SoapRequest : "+ soapRequestt);
	$.ajax({
		type: "POST",
		url: wsUrll,
		contentType: "text/xml",
		dataType: "text",
		data: soapRequestt,
		success: function(data, status, req)
		{
			var strJSON = $(req.responseText).find("return").text();
			console.log("success kluster inner gaurav : "+strJSON);
			var obj = JSON.parse(strJSON);
			var output="";


			var totalpages=obj.count/obj.pagesize;
			var outputpagination="";
			if(totalpages>1)
			{
				outputpagination="<div class='socialpost-box'><div class='pager'><span class='pager-item title'>"+social_post_socialapp+"</span>"

					var totalpagesint = parseInt(totalpages)
					if(totalpages>totalpagesint)
					{
						totalpagesint+=1;
					}
				for(var k=1;k<=totalpagesint;k++)
				{
					if(k==pageid)
					{
						outputpagination+="<a class='pager-item current' href='#'>"+k+"</a>"
					}
					else
					{
						outputpagination+="<a id='"+k+"' class='pager-item' href='#' onclick='pagechangeklusterinner(this.id)'>"+k+"</a>"
					}
				}
				outputpagination+="</div></div>";
			}
			if(obj.data!=null)
			{
				for(var i=0; i<obj.data.length; i++)
				{
					var countryflag="http://"+window.localStorage.getItem("reseller")+obj.data[i].country_flag;
					if(obj.data[i].post_type=="video")
					{
						var imageshow="http://"+window.localStorage.getItem("reseller")+"/"+obj.data[i].image;
						if(obj.data[i].show_flag==1)
						{

							output+="<div class='socialpost-box letest' onclick='postpage("+obj.data[i].id+");'><img width='74' height='54' src="+imageshow+" alt='' class='f-left'><div class='video_text'><h4>"+obj.data[i].message+"</h4><span>"+obj.data[i].addedon+" by <a href='#' class='orangeTxt'>"+obj.data[i].username+"</a></span><span class='flag'><img width='16' height='16' alt='' src="+countryflag+">"+obj.data[i].country+"</span></div> <div class='right-content'><a  href='#' class='like-icon'>"+obj.data[i].count_like+"</a><a class='coment-icon' href='#'>"+obj.data[i].count_comment+"</a></div></div>";
						}
						else
						{
							output+="<div class='socialpost-box letest' onclick='postpage("+obj.data[i].id+");'><img width='74' height='54' src="+imageshow+" alt='' class='f-left'><div class='video_text'><h4>"+obj.data[i].message+"</h4><span>"+obj.data[i].addedon+" by <a href='#' class='orangeTxt'>"+obj.data[i].username+"</a></span></div> <div class='right-content'><a  href='#' class='like-icon'>"+obj.data[i].count_like+"</a><a class='coment-icon' href='#'>"+obj.data[i].count_comment+"</a></div></div>";
						}
					}
					else if(obj.data[i].post_type=="image")
					{
						var imageshow="http://"+window.localStorage.getItem("reseller")+"/"+obj.data[i].image;
						if(obj.data[i].show_flag==1)
						{

							output+="<div class='socialpost-box letest' onclick='postpage("+obj.data[i].id+");'><img width='74' height='54' src="+imageshow+" alt='' class='f-left'><div class='video_text'><h4>"+obj.data[i].message+"</h4><span>"+obj.data[i].addedon+" by <a href='#' class='orangeTxt'>"+obj.data[i].username+"</a></span><span class='flag'><img width='16' height='16' alt='' src="+countryflag+">"+obj.data[i].country+"</span></div> <div class='right-content'><a  href='#' class='like-icon'>"+obj.data[i].count_like+"</a><a class='coment-icon' href='#'>"+obj.data[i].count_comment+"</a></div></div>";
						}
						else
						{
							output+="<div class='socialpost-box letest' onclick='postpage("+obj.data[i].id+");'><img width='74' height='54' src="+imageshow+" alt='' class='f-left'><div class='video_text'><h4>"+obj.data[i].message+"</h4><span>"+obj.data[i].addedon+" by <a href='#' class='orangeTxt'>"+obj.data[i].username+"</a></span></div> <div class='right-content'><a  href='#' class='like-icon'>"+obj.data[i].count_like+"</a><a class='coment-icon' href='#'>"+obj.data[i].count_comment+"</a></div></div>";
						}
					}
					else
					{
						if(obj.data[i].show_flag==1)
						{

							output+="<div class='socialpost-box letest' onclick='postpage("+obj.data[i].id+");'><div class='video_text'><h4>"+obj.data[i].message+"</h4><span>"+obj.data[i].addedon+" by <a href='#' class='orangeTxt'>"+obj.data[i].username+"</a></span><span class='flag'><img width='16' height='16' alt='' src='"+countryflag+"'> "+obj.data[i].country+"</span></div><div class='right-content'><a  href='#' class='like-icon'>"+obj.data[i].count_like+"</a><a class='coment-icon' href='#'>"+obj.data[i].count_comment+"</a></div></div>";
						}
						else
						{
							output+="<div class='socialpost-box letest' onclick='postpage("+obj.data[i].id+");'><div class='video_text'><h4>"+obj.data[i].message+"</h4><span>"+obj.data[i].addedon+" by <a href='#' class='orangeTxt'>"+obj.data[i].username+"</a></span></div><div class='right-content'><a  href='#' class='like-icon'>"+obj.data[i].count_like+"</a><a class='coment-icon' href='#'>"+obj.data[i].count_comment+"</a></div></div>";
						}
					}
				}
			}

			 var html="<div id='appypie-search-section' class='social-search'><input type='text' id='searchsocialtext6' data-role='none' class='filled_inp' value='' placeholder="+placeholder_search_socialapp+"><a href='#' onclick='searchsocialfunction(\"searchsocialtext6\");' class='searchBtn' data-role='none'>"+without_palceholder_search_socialapp+"</a><a href='#' class='social-uploadBtn' onclick='capturepage();'><img src='images/social-upload.png' alt=''/></a></div><div id='middle_page' class='social-inner-page'>"+output+"</div>"+outputpagination+"";
			 $('#contentHolder22').css('background', '#edf0f5');
			 appendHtml(html+" "+socialMenu,22,3,'food');

		},
		error: function(response, textStatus, errorThrown)
		{
			console.log("Error : "+JSON.stringify(response));
			console.log("Error : "+textStatus);
			console.log("Error : "+errorThrown.responseText);
		}
	});

}
function whotofollow()
{


	if(window.localStorage.getItem("layout")=="slidemenu"){
		snapper.close();
	}

	$('.appypie-loader').show();
	var wsUrll="http://"+window.localStorage.getItem("reseller")+"/services/social-soap#featuredJson";
	var soapRequestt ='<?xml version="1.0" encoding="utf-8"?> <soap:Envelope xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"  xmlns:xsd="http://www.w3.org/2001/XMLSchema" xmlns:soap="http://schemas.xmlsoap.org/soap/envelope/"> <soap:Body><featuredJson xmlns=\"http://'+window.localStorage.getItem("reseller")+'/services/social-soap#featuredJson\"><appId>'+localStorage.getItem('applicationID')+'</appId><userId>'+localStorage.getItem('userid')+'</userId><page>1</page></featuredJson></soap:Body></soap:Envelope>';
	console.log("SoapRequest : "+ soapRequestt);
	$.ajax({
		type: "POST",
		url: wsUrll,
		contentType: "text/xml",
		dataType: "text",
		data: soapRequestt,
		success: function(data, status, req)
		{
			var strJSON = $(req.responseText).find("return").text();
			console.log("success who2follow gaurav : "+strJSON);
			var obj = JSON.parse(strJSON);
			var output="";

			var totalpages=obj.count/obj.pagesize;
			var outputpagination="";
			if(totalpages>1)
			{
				outputpagination="<div class='socialpost-box'><div class='pager'><span class='pager-item title'>"+social_post_socialapp+"</span>"
					var totalpagesint = parseInt(totalpages)
					if(totalpages>totalpagesint)
					{
						totalpagesint+=1;
					}
				for(var k=1;k<=totalpagesint;k++)
				{
					if(k==1)
					{
						outputpagination+="<a class='pager-item current' href='#'>"+k+"</a>"
					}
					else
					{
						outputpagination+="<a id='"+k+"' class='pager-item' href='#' onclick='pagechangewhotofollow(this.id)'>"+k+"</a>"
					}
				}
				outputpagination+="</div></div>";
			}
			var alluserid="";
			if(obj.data!=null)
			{
				for(var i=0; i<obj.data.length; i++)
				{

					if(obj.data[i].userId==localStorage.getItem('userid'))
					{


					}
					else
					{
						if(i==obj.data.length-1)
						{
							alluserid+=obj.data[i].userId;
						}
						else{
							alluserid+=obj.data[i].userId+",";
						}
						var avatarr="http://"+window.localStorage.getItem("reseller")+obj.data[i].avatar;
						if(obj.data[i].show_flag==1)
						{

							var countryflag="http://"+window.localStorage.getItem("reseller")+obj.data[i].country_flag;
							if(obj.data[i].followed==1)
							{
								output+="<div class='socialpost-box '><img width='74' height='54' src='"+avatarr+"' alt=''><div class='video_text'><h4>"+obj.data[i].name+"</h4><span class='flag'><img width='16' height='16' alt='' src='"+countryflag+"'>"+obj.data[i].country+"</span></div><button class='blu f-right' onclick='follow("+obj.data[i].userId+")'>"+following_socialapp+"</button></div>";
							}
							else
							{
								output+="<div class='socialpost-box '><img width='74' height='54' src='"+avatarr+"' alt=''><div class='video_text'><h4>"+obj.data[i].name+"</h4><span class='flag'><img width='16' height='16' alt='' src='"+countryflag+"'>"+obj.data[i].country+"</span></div><button class='f-right' data-role='none' onclick='follow("+obj.data[i].userId+")'>"+follow_witjout_s_socialapp+"</button></div>";
							}
						}
						else
						{
							if(obj.data[i].followed==1)
							{
								output+="<div class='socialpost-box '><img width='74' height='54' src='"+avatarr+"' alt=''><div class='video_text'><h4>"+obj.data[i].name+"</h4></div><button class='blu f-right' onclick='follow("+obj.data[i].userId+")'>"+following_socialapp+"</button></div>";
							}
							else
							{
								output+="<div class='socialpost-box '><img width='74' height='54' src='"+avatarr+"' alt=''><div class='video_text'><h4>"+obj.data[i].name+"</h4></div><button class='f-right' data-role='none' onclick='follow("+obj.data[i].userId+")'>"+follow_witjout_s_socialapp+"</button></div>";
							}
						}
					}
				}
			}
			var html="<section class='magentocl whoFollow' style=''><div id='appypie-search-section' class='social-search'><input type='text' id='searchsocialtext7' data-role='none' class='filled_inp' value='' placeholder="+placeholder_search_socialapp+"><a href='#' onclick='searchsocialfunction(\"searchsocialtext7\");' class='searchBtn' data-role='none'>"+without_palceholder_search_socialapp+"</a><a href='#' class='social-uploadBtn' onclick='capturepage();'><img src='images/social-upload.png' alt=''/></a></div><div id='middle_page' class='social-inner-page'><div class='socialpost-box'><div><button class='orange f-right' id="+alluserid+" onclick='followAll(this.id)'>"+follow_all_socialapp+"</button> </div></div>"+output+outputpagination+"</div></section>";
			$('#contentHolder21').css('background', '#edf0f5');
			appendHtml(html+" "+socialMenu,21,2,'food');

			globalpageid=1;

		},
		error: function(response, textStatus, errorThrown)
		{
			console.log("Error : "+JSON.stringify(response));
			console.log("Error : "+textStatus);
			console.log("Error : "+errorThrown.responseText);
		}
	});
}
var globalpageid;
function pagechangewhotofollow(pageid)
{

	$('.appypie-loader').show();
	globalpageid=pageid;
	var wsUrll="http://"+window.localStorage.getItem("reseller")+"/services/social-soap#featuredJson";
	var soapRequestt ='<?xml version="1.0" encoding="utf-8"?> <soap:Envelope xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"  xmlns:xsd="http://www.w3.org/2001/XMLSchema" xmlns:soap="http://schemas.xmlsoap.org/soap/envelope/"> <soap:Body><featuredJson xmlns=\"http://'+window.localStorage.getItem("reseller")+'/services/social-soap#featuredJson\"><appId>'+localStorage.getItem('applicationID')+'</appId><userId>'+localStorage.getItem('userid')+'</userId><page>1</page></featuredJson></soap:Body></soap:Envelope>';
	console.log("SoapRequest : "+ soapRequestt);
	$.ajax({
		type: "POST",
		url: wsUrll,
		contentType: "text/xml",
		dataType: "text",
		data: soapRequestt,
		success: function(data, status, req)
		{
			var strJSON = $(req.responseText).find("return").text();
			console.log("success who2follow gaurav : "+strJSON);
			var obj = JSON.parse(strJSON);
			var output="";

			var totalpages=obj.count/obj.pagesize;
			var outputpagination="";
			if(totalpages>1)
			{
				outputpagination="<div class='socialpost-box'><div class='pager'><span class='pager-item title'>"+social_post_socialapp+"</span>"
					var totalpagesint = parseInt(totalpages)
					if(totalpages>totalpagesint)
					{
						totalpagesint+=1;
					}
				for(var k=1;k<=totalpagesint;k++)
				{
					if(k==pageid)
					{
						outputpagination+="<a class='pager-item current' href='#'>"+k+"</a>"
					}
					else
					{
						outputpagination+="<a id='"+k+"' class='pager-item' href='#' onclick='pagechangewhotofollow(this.id)'>"+k+"</a>"
					}
				}
				outputpagination+="</div></div>";
			}
			var alluserid="";
			if(obj.data!=null)
			{
				for(var i=0; i<obj.data.length; i++)
				{

					if(obj.data[i].userId==localStorage.getItem('userid'))
					{


					}
					else
					{
						if(i==obj.data.length-1)
						{
							alluserid+=obj.data[i].userId;
						}
						else{
							alluserid+=obj.data[i].userId+",";
						}
						var avatarr="http://"+window.localStorage.getItem("reseller")+obj.data[i].avatar;
						if(obj.data[i].show_flag==1)
						{

							var countryflag="http://"+window.localStorage.getItem("reseller")+obj.data[i].country_flag;
							if(obj.data[i].followed==1)
							{
								output+="<div class='socialpost-box '><img width='74' height='54' src='"+avatarr+"' alt=''><div class='video_text'><h4>"+obj.data[i].name+"</h4><span class='flag'><img width='16' height='16' alt='' src='"+countryflag+"'>"+obj.data[i].country+"</span></div><button class='blu f-right' onclick='follow("+obj.data[i].userId+")'>"+following_socialapp+"</button></div>";
							}
							else
							{
								output+="<div class='socialpost-box '><img width='74' height='54' src='"+avatarr+"' alt=''><div class='video_text'><h4>"+obj.data[i].name+"</h4><span class='flag'><img width='16' height='16' alt='' src='"+countryflag+"'>"+obj.data[i].country+"</span></div><button class='f-right' data-role='none' onclick='follow("+obj.data[i].userId+")'>"+follow_witjout_s_socialapp+"</button></div>";
							}
						}
						else
						{
							if(obj.data[i].followed==1)
							{
								output+="<div class='socialpost-box '><img width='74' height='54' src='"+avatarr+"' alt=''><div class='video_text'><h4>"+obj.data[i].name+"</h4></div><button class='blu f-right' onclick='follow("+obj.data[i].userId+")'>"+following_socialapp+"</button></div>";
							}
							else
							{
								output+="<div class='socialpost-box '><img width='74' height='54' src='"+avatarr+"' alt=''><div class='video_text'><h4>"+obj.data[i].name+"</h4></div><button  class='f-right' data-role='none' onclick='follow("+obj.data[i].userId+")'>"+follow_witjout_s_socialapp+"</button></div>";
							}
						}
					}
				}
			}
			var html="<section class='magentocl whoFollow' style=''><div id='appypie-search-section' class='social-search'><input type='text' id='searchsocialtext8' data-role='none' class='filled_inp' value='' placeholder="+placeholder_search_socialapp+"><a href='#' onclick='searchsocialfunction(\"searchsocialtext8\");' class='searchBtn' data-role='none'>"+without_palceholder_search_socialapp+"</a><a href='#' class='social-uploadBtn' onclick='capturepage();'><img src='images/social-upload.png' alt=''/></a></div><div id='middle_page' class='social-inner-page'><div class='socialpost-box'><div><button class='orange f-right' onclick='followAll("+alluserid+")'>"+follow_all_socialapp+"</button> </div></div>"+output+outputpagination+"</div></section>";
			$('#contentHolder21').css('background', '#edf0f5');
			appendHtml(html+" "+socialMenu,21,2,'food');


		},
		error: function(response, textStatus, errorThrown)
		{
			console.log("Error : "+JSON.stringify(response));
			console.log("Error : "+textStatus);
			console.log("Error : "+errorThrown.responseText);
		}
	});
}
function follow(other_userid)
{
	$('.appypie-loader').show();
	var wsUrll="http://"+window.localStorage.getItem("reseller")+"/services/social-soap#friendUnfriendJson";
	var soapRequestt ='<?xml version="1.0" encoding="utf-8"?> <soap:Envelope xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"  xmlns:xsd="http://www.w3.org/2001/XMLSchema" xmlns:soap="http://schemas.xmlsoap.org/soap/envelope/"> <soap:Body><friendUnfriendJson xmlns=\"http://'+window.localStorage.getItem("reseller")+'/services/social-soap#friendUnfriendJson\"><appId>'+localStorage.getItem('applicationID')+'</appId><userId>'+localStorage.getItem('userid')+'</userId><friendId>'+other_userid+'</friendId></friendUnfriendJson></soap:Body></soap:Envelope>';
	console.log("SoapRequest : "+ soapRequestt);
	$.ajax({
		type: "POST",
		url: wsUrll,
		contentType: "text/xml",
		dataType: "text",
		data: soapRequestt,
		success: function(data, status, req)
		{
			var strJSON = $(req.responseText).find("return").text();
			console.log("success follow gaurav : "+strJSON);

			if(strJSON=='"unfollow"'|| strJSON=='"follow"')
			{

				if(globalpageid==1)
				{
					whotofollow();
				}
				else
				{
					pagechangewhotofollow(globalpageid);
				}
			}
			else
			{

			}
		},
		error: function(response, textStatus, errorThrown)
		{
			console.log("Error : "+JSON.stringify(response));
			console.log("Error : "+textStatus);
			console.log("Error : "+errorThrown.responseText);
		}
	});
}
function followAll(all_userid)
{
	$('.appypie-loader').show();
	var wsUrll="http://"+window.localStorage.getItem("reseller")+"/services/social-soap#followallJson";
	var soapRequestt ='<?xml version="1.0" encoding="utf-8"?> <soap:Envelope xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"  xmlns:xsd="http://www.w3.org/2001/XMLSchema" xmlns:soap="http://schemas.xmlsoap.org/soap/envelope/"> <soap:Body><followallJson xmlns=\"http://'+window.localStorage.getItem("reseller")+'/services/social-soap#followallJson\"><appId>'+localStorage.getItem('applicationID')+'</appId><userId>'+localStorage.getItem('userid')+'</userId><friendIds>'+all_userid+'</friendIds></followallJson></soap:Body></soap:Envelope>';
	console.log("SoapRequest : "+ soapRequestt);
	$.ajax({
		type: "POST",
		url: wsUrll,
		contentType: "text/xml",
		dataType: "text",
		data: soapRequestt,
		success: function(data, status, req)
		{
			var strJSON = $(req.responseText).find("return").text();
			console.log("success followall gaurav : "+strJSON);


			if(globalpageid==1)
			{
				whotofollow();
			}
			else
			{
				pagechangewhotofollow(globalpageid);
			}
		},
		error: function(response, textStatus, errorThrown)
		{
			console.log("Error : "+JSON.stringify(response));
			console.log("Error : "+textStatus);
			console.log("Error : "+errorThrown.responseText);
		}
	});
}

function changecountrytop100()
{
	var e = document.getElementById("selectcountrytop100");
	var countrylistvalue = e.options[e.selectedIndex].value;
	if(countrylistvalue!="")
	{
		countrylistvaluetop100=countrylistvalue;

	}
	else
	{
		countrylistvaluetop100=0;
	}
	top100user();
}
function changefiltertop100()
{
	var e = document.getElementById("filtertop100");
	var filtervalue = e.options[e.selectedIndex].value;

	filtervaluetop100=filtervalue;

	top100user();

}
var filtervaluetop100='';
var countrylistvaluetop100=0;
function top100user()
{


	if(window.localStorage.getItem("layout")=="slidemenu"){
		snapper.close();
	}
	$('.appypie-loader').show();
	var countrylist="";
	var wsUrll="http://"+window.localStorage.getItem("reseller")+"/services/social-soap#getCountryListJson";
	var soapRequestt ='<?xml version="1.0" encoding="utf-8"?> <soap:Envelope xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"  xmlns:xsd="http://www.w3.org/2001/XMLSchema" xmlns:soap="http://schemas.xmlsoap.org/soap/envelope/"> <soap:Body><getCountryListJson xmlns=\"http://'+window.localStorage.getItem("reseller")+'/services/social-soap#getCountryListJson\"></getCountryListJson></soap:Body></soap:Envelope>';
	console.log("SoapRequest : "+ soapRequestt);
	$.ajax({
		type: "POST",
		url: wsUrll,
		contentType: "text/xml",
		dataType: "text",
		data: soapRequestt,
		success: function(data, status, req)
		{
			var strJSON2 = $(req.responseText).find("return").text();
			console.log("success country list : "+strJSON2);
			var objcountry = JSON.parse(strJSON2);
			for(var l=0; l<objcountry.length; l++)
			{

				countrylist+="<option value="+objcountry[l].id+">"+objcountry[l].country+"</option>";
			}
			//new
			var wsUrll="http://"+window.localStorage.getItem("reseller")+"/services/social-soap#top100usersJson";
			if(countrylistvaluetop100==0)
			{
				var soapRequestt ='<?xml version="1.0" encoding="utf-8"?> <soap:Envelope xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"  xmlns:xsd="http://www.w3.org/2001/XMLSchema" xmlns:soap="http://schemas.xmlsoap.org/soap/envelope/"> <soap:Body><top100usersJson xmlns=\"http://'+window.localStorage.getItem("reseller")+'/services/social-soap#top100usersJson\"><appId>'+localStorage.getItem('applicationID')+'</appId><userId>'+localStorage.getItem('userid')+'</userId><filter>'+filtervaluetop100+'</filter><country></country><page>1</page></top100usersJson></soap:Body></soap:Envelope>';
			}
			else
			{
				var soapRequestt ='<?xml version="1.0" encoding="utf-8"?> <soap:Envelope xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"  xmlns:xsd="http://www.w3.org/2001/XMLSchema" xmlns:soap="http://schemas.xmlsoap.org/soap/envelope/"> <soap:Body><top100usersJson xmlns=\"http://'+window.localStorage.getItem("reseller")+'/services/social-soap#top100usersJson\"><appId>'+localStorage.getItem('applicationID')+'</appId><userId>'+localStorage.getItem('userid')+'</userId><filter>'+filtervaluetop100+'</filter><country>'+countrylistvaluetop100+'</country><page>1</page></top100usersJson></soap:Body></soap:Envelope>';
			}

			console.log("SoapRequest : "+ soapRequestt);
			$.ajax({
				type: "POST",
				url: wsUrll,
				contentType: "text/xml",
				dataType: "text",
				data: soapRequestt,
				success: function(data, status, req)
				{
					var strJSON = $(req.responseText).find("return").text();
					console.log("success top100user gaurav : "+strJSON);
					var obj = JSON.parse(strJSON);
					var output="";

					var totalpages=obj.count/obj.pagesize;
					var outputpagination="";
					if(totalpages>1)
					{
						outputpagination="<div class='socialpost-box'><div class='pager'><span class='pager-item title'>"+social_post_socialapp+"</span>"
							var totalpagesint = parseInt(totalpages)
							if(totalpages>totalpagesint)
							{
								totalpagesint+=1;
							}
						for(var k=1;k<=totalpagesint;k++)
						{
							if(k==1)
							{
								outputpagination+="<a class='pager-item current' href='#'>"+k+"</a>"
							}
							else
							{
								outputpagination+="<a id='"+k+"' class='pager-item' href='#' onclick='pagechangetop100(this.id)'>"+k+"</a>"
							}
						}
						outputpagination+="</div></div>";
					}
					if(obj.data!=null)
					{
						for(var i=0; i<obj.data.length; i++)
						{
							var avatarr="http://"+window.localStorage.getItem("reseller")+obj.data[i].avatar;
							if(obj.data[i].show_flag==1)
							{

								var countryflag="http://"+window.localStorage.getItem("reseller")+obj.data[i].country_flag;
								output+="<div class='socialpost-box top100'><a onclick='userProfile("+obj.data[i].userId+");'><img width='74' height='54' src='"+avatarr+"' alt='' class='f-left'><div class='video_text'><h4>"+obj.data[i].name+"</h4><span class='flag'><img width='16' height='16' alt='' src='"+countryflag+"'>"+obj.data[i].country+"</span></div><div class='right-content'><ul class='listing'><li>"+followers_socialapp+" "+obj.data[i].followers+"</li><li>"+subscriber_socialapp+" "+obj.data[i].subscribers+"</li><li>"+post_socialapp+"  "+obj.data[i].posts+"</li></ul></div></a></div>";
							}
							else
							{

								output+="<div class='socialpost-box top100'><a onclick='userProfile("+obj.data[i].userId+");'><img width='74' height='54' src='"+avatarr+"' alt='' class='f-left'><div class='video_text'><h4>"+obj.data[i].name+"</h4></div><div class='right-content'><ul class='listing'><li>"+followers_socialapp+" "+obj.data[i].followers+"</li><li>"+subscriber_socialapp+" "+obj.data[i].subscribers+"</li><li>"+post_socialapp+"  "+obj.data[i].posts+"</li></ul></div></a></div>";

							}
						}
					}
					else
					{

					}
					var html="<section class='magentocl whoFollow' style='' data-role='none'><div id='appypie-search-section' class='social-search'><input type='text' id='searchsocialtext9' data-role='none' class='filled_inp' value='' placeholder="+placeholder_search_socialapp+"><a href='#' onclick='searchsocialfunction(\"searchsocialtext9\");' class='searchBtn' data-role='none'>"+without_palceholder_search_socialapp+"</a><a href='#' class='social-uploadBtn' onclick='capturepage();'><img src='images/social-upload.png' alt=''/></a></div><div id='middle_page' class='social-inner-page'><div class='socialpost-box ' data-role='none'>  <a href='#' class='filters-refresh'>"+top_hundred_user_socialapp+"</a> <p class='clearAll' data-role='none'><select class='filter-select' style='margin-left:10px;' data-role='none' onchange='changefiltertop100();' id='filtertop100'><option value=''>"+all_socialapp+"</option><option value='subscribers'>"+subscriber_without_s_socialapp+"</option><option value='followers'>"+follower_without_s_socialapp+"</option><option value='posts'>"+post_without_colon+"</option></select><select class='filter-select' data-role='none' onchange='changecountrytop100();' id='selectcountrytop100'><option value=''>"+filter_by_location_socialapp+"</option><option value='0'>"+none_socialapp+"</option>"+countrylist+"</select></p></div>"+output+outputpagination+"</div></section>";

					setTimeout(function(){
						$('#contentHolder21').css('background', '#edf0f5');
						appendHtml(html+" "+socialMenu,21,2,'food');
						var e3 = document.getElementById("selectcountrytop100");
						e3.value = countrylistvaluetop100;
						var e4 = document.getElementById("filtertop100");
						e4.value = filtervaluetop100;
					},1000);
				},
				error: function(response, textStatus, errorThrown)
				{
					console.log("Error : "+JSON.stringify(response));
					console.log("Error : "+textStatus);
					console.log("Error : "+errorThrown.responseText);
				}
			});
		},
		error: function(response, textStatus, errorThrown)
		{
			console.log("Error : "+JSON.stringify(response));
			console.log("Error : "+textStatus);
			console.log("Error : "+errorThrown.responseText);
		}
	});
}

function pagechangetop100(pageid)
{

	$('.appypie-loader').show();
	var countrylist="";
	var wsUrll="http://"+window.localStorage.getItem("reseller")+"/services/social-soap#getCountryListJson";
	var soapRequestt ='<?xml version="1.0" encoding="utf-8"?> <soap:Envelope xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"  xmlns:xsd="http://www.w3.org/2001/XMLSchema" xmlns:soap="http://schemas.xmlsoap.org/soap/envelope/"> <soap:Body><getCountryListJson xmlns=\"http://'+window.localStorage.getItem("reseller")+'/services/social-soap#getCountryListJson\"></getCountryListJson></soap:Body></soap:Envelope>';
	console.log("SoapRequest : "+ soapRequestt);
	$.ajax({
		type: "POST",
		url: wsUrll,
		contentType: "text/xml",
		dataType: "text",
		data: soapRequestt,
		success: function(data, status, req)
		{
			var strJSON2 = $(req.responseText).find("return").text();
			console.log("success country list : "+strJSON2);
			var objcountry = JSON.parse(strJSON2);
			for(var l=0; l<objcountry.length; l++)
			{

				countrylist+="<option value="+objcountry[l].id+">"+objcountry[l].country+"</option>";
			}
			var wsUrll="http://"+window.localStorage.getItem("reseller")+"/services/social-soap#top100usersJson";
			if(countrylistvaluetop100==0)
			{
				var soapRequestt ='<?xml version="1.0" encoding="utf-8"?> <soap:Envelope xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"  xmlns:xsd="http://www.w3.org/2001/XMLSchema" xmlns:soap="http://schemas.xmlsoap.org/soap/envelope/"> <soap:Body><top100usersJson xmlns=\"http://'+window.localStorage.getItem("reseller")+'/services/social-soap#top100usersJson\"><appId>'+localStorage.getItem('applicationID')+'</appId><userId>'+localStorage.getItem('userid')+'</userId><filter>'+filtervaluetop100+'</filter><country></country><page>'+pageid+'</page></top100usersJson></soap:Body></soap:Envelope>';
			}
			else
			{
				var soapRequestt ='<?xml version="1.0" encoding="utf-8"?> <soap:Envelope xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"  xmlns:xsd="http://www.w3.org/2001/XMLSchema" xmlns:soap="http://schemas.xmlsoap.org/soap/envelope/"> <soap:Body><top100usersJson xmlns=\"http://'+window.localStorage.getItem("reseller")+'/services/social-soap#top100usersJson\"><appId>'+localStorage.getItem('applicationID')+'</appId><userId>'+localStorage.getItem('userid')+'</userId><filter>'+filtervaluetop100+'</filter><country>'+countrylistvaluetop100+'</country><page>'+pageid+'</page></top100usersJson></soap:Body></soap:Envelope>';
			}

			console.log("SoapRequest : "+ soapRequestt);
			$.ajax({
				type: "POST",
				url: wsUrll,
				contentType: "text/xml",
				dataType: "text",
				data: soapRequestt,
				success: function(data, status, req)
				{
					var strJSON = $(req.responseText).find("return").text();
					console.log("success top100user gaurav : "+strJSON);
					var obj = JSON.parse(strJSON);
					var output="";

					var totalpages=obj.count/obj.pagesize;
					var outputpagination="";
					if(totalpages>1)
					{
						outputpagination="<div class='socialpost-box'><div class='pager'><span class='pager-item title'>"+social_post_socialapp+"</span>"
							var totalpagesint = parseInt(totalpages)
							if(totalpages>totalpagesint)
							{
								totalpagesint+=1;
							}
						for(var k=1;k<=totalpagesint;k++)
						{
							if(k==pageid)
							{
								outputpagination+="<a class='pager-item current' href='#'>"+k+"</a>"
							}
							else
							{
								outputpagination+="<a id='"+k+"' class='pager-item' href='#' onclick='pagechangetop100(this.id)'>"+k+"</a>"
							}
						}
						outputpagination+="</div></div>";
					}
					if(obj.data!=null)
					{
						for(var i=0; i<obj.data.length; i++)
						{
							var avatarr="http://"+window.localStorage.getItem("reseller")+obj.data[i].avatar;
							if(obj.data[i].show_flag==1)
							{

								var countryflag="http://"+window.localStorage.getItem("reseller")+obj.data[i].country_flag;
								output+="<div class='socialpost-box top100'><a onclick='userProfile("+obj.data[i].userId+");'><img width='74' height='54' src='"+avatarr+"' alt='' class='f-left'><div class='video_text'><h4>"+obj.data[i].name+"</h4><span class='flag'><img width='16' height='16' alt='' src='"+countryflag+"'>"+obj.data[i].country+"</span></div><div class='right-content'><ul class='listing'><li>"+followers_socialapp+" "+obj.data[i].followers+"</li><li>"+followers_socialapp+" "+obj.data[i].subscribers+"</li><li>post:  "+obj.data[i].posts+"</li></ul></div></a></div>";
							}
							else
							{

								output+="<div class='socialpost-box top100'><a onclick='userProfile("+obj.data[i].userId+");'><img width='74' height='54' src='"+avatarr+"' alt='' class='f-left'><div class='video_text'><h4>"+obj.data[i].name+"</h4></div><div class='right-content'><ul class='listing'><li>Followers: "+obj.data[i].followers+"</li><li>"+subscriber_socialapp+" "+obj.data[i].subscribers+"</li><li>"+post_socialapp+"  "+obj.data[i].posts+"</li></ul></div></a></div>";

							}
						}
					}
					else
					{

					}

						var html="<section class='magentocl whoFollow' style='' data-role='none'><div id='appypie-search-section' class='social-search'><input type='text' id='searchsocialtext10' data-role='none' class='filled_inp' value='' placeholder="+placeholder_search_socialapp+"><a href='#' onclick='searchsocialfunction(\"searchsocialtext10\");' class='searchBtn' data-role='none'>"+without_palceholder_search_socialapp+"</a><a href='#' class='social-uploadBtn' onclick='capturepage();'><img src='images/social-upload.png' alt=''/></a></div><div id='middle_page' class='social-inner-page'><div class='socialpost-box ' data-role='none'>  <a href='#' class='filters-refresh'>"+top_hundred_user_socialapp+"</a> <p class='clearAll'><select class='filter-select' style='margin-left:10px;' data-role='none' onchange='changefiltertop100();' id='filtertop100'><option value=''>"+none_socialapp+"</option><option value='subscribers'>"+subscriber_without_s_socialapp+"</option><option value='followers'>"+follower_without_s_socialapp+"</option><option value='posts'>"+post_without_colon+"</option></select><select class='filter-select' data-role='none' onchange='changecountrytop100();' id='selectcountrytop100'><option value=''>"+filter_by_location_socialapp+"</option><option value='0'>"+none_socialapp+"</option>"+countrylist+"</select></p></div>"+output+outputpagination+"</div></section>";
					$('#contentHolder21').css('background', '#edf0f5');
					setTimeout(function(){
						appendHtml(html+" "+socialMenu,21,2,'food');
						var e3 = document.getElementById("selectcountrytop100");
						e3.value = countrylistvaluetop100;
						var e4 = document.getElementById("filtertop100");
						e4.value = filtervaluetop100;
					},1000);
				},
				error: function(response, textStatus, errorThrown)
				{
					console.log("Error : "+JSON.stringify(response));
					console.log("Error : "+textStatus);
					console.log("Error : "+errorThrown.responseText);
				}
			});
		},
		error: function(response, textStatus, errorThrown)
		{
			console.log("Error : "+JSON.stringify(response));
			console.log("Error : "+textStatus);
			console.log("Error : "+errorThrown.responseText);
		}
	});
}

//
var glopadprofileid;
function userProfile(profileId)
{

	$('.appypie-loader').show();
	glopadprofileid=profileId;
	var wsUrll="http://"+window.localStorage.getItem("reseller")+"/services/social-soap#userProfileJson";
	var soapRequestt ='<?xml version="1.0" encoding="utf-8"?> <soap:Envelope xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"  xmlns:xsd="http://www.w3.org/2001/XMLSchema" xmlns:soap="http://schemas.xmlsoap.org/soap/envelope/"> <soap:Body><userProfileJson xmlns=\"http://'+window.localStorage.getItem("reseller")+'/services/social-soap#userProfileJson\"><appId>'+localStorage.getItem('applicationID')+'</appId><userId>'+localStorage.getItem('userid')+'</userId><profileId>'+profileId+'</profileId></userProfileJson></soap:Body></soap:Envelope>';
	console.log("SoapRequest : "+ soapRequestt);
	$.ajax({
		type: "POST",
		url: wsUrll,
		contentType: "text/xml",
		dataType: "text",
		data: soapRequestt,
		success: function(data, status, req)
		{
			var strJSON = $(req.responseText).find("return").text();
			console.log("success userprofile gaurav : "+strJSON);
			var obj = JSON.parse(strJSON);
			var output="";
			var avatarr="http://"+window.localStorage.getItem("reseller")+obj.user.avatar;
			var gender="";

			if(obj.user.gender=='m')
			{
				gender=gender_male_socialapp;
			}
			else
			{
				gender=gender_female_socialapp;
			}
			var commentoutput="";
			var likeoutput="";
			if(obj.comments!=null)
			{

				for(var i=0; i<obj.comments.length; i++)
				{
					commentoutput+="<li onclick='postpage("+obj.comments[i].id+");'><strong class='Disblock'>"+obj.comments[i].comment+"</strong><span class='Disblock'>"+obj.comments[i].comment_date+"</span><span class='orng-txt Disblock'><strong>on "+obj.comments[i].username+"'s post</strong> </span></li>";
				}

			}
			if(obj.likes!=null)
			{
				for(var i=0; i<obj.likes.length; i++)
				{
					var countryflag="http://"+window.localStorage.getItem("reseller")+obj.likes[i].country_flag;
					likeoutput+="";
					if(obj.likes[i].attached!="0")
					{
						if(obj.likes[i].post_type=="video")
						{
							var imageshow="http://"+window.localStorage.getItem("reseller")+obj.likes[i].image;
							if(obj.likes[i].show_flag==1)
							{

								likeoutput+="<li onclick='postpage("+obj.likes[i].id+");'><img class='f-left' width='74' height='54' alt='' src="+imageshow+"> <span class='right-content'> <h2><a name='what'>"+obj.likes[i].message+"</a></h2> <span>"+obj.likes[i].addedon+" by <a class='' href='#'>"+obj.likes[i].username+"</a></span> <span class='flag Disblock'><img width='16' height='16' src="+countryflag+" alt=''>"+obj.likes[i].country+"</span> </span> <span class='right-like'> <a class='like-icon' href='#'>"+obj.likes[i].count_like+"</a> <a href='#' class='coment-icon'>"+obj.likes[i].count_comments+"</a> </span> </li>";
							}
							else
							{
								likeoutput+="<li onclick='postpage("+obj.likes[i].id+");'><img class='f-left' width='74' height='54' alt='' src="+imageshow+"> <span class='right-content'> <h2><a name='what'>"+obj.likes[i].message+"</a></h2> <span>"+obj.likes[i].addedon+" by <a class='' href='#'>"+obj.likes[i].username+"</a></span></span> <span class='right-like'> <a class='like-icon' href='#'>"+obj.likes[i].count_like+"</a> <a href='#' class='coment-icon'>"+obj.likes[i].count_comments+"</a> </span> </li>";
							}
						}
						else if(obj.likes[i].post_type=="image")
						{
							var imageshow="http://"+window.localStorage.getItem("reseller")+obj.likes[i].image;
							if(obj.likes[i].show_flag==1)
							{

								likeoutput+="<li onclick='postpage("+obj.likes[i].id+");'><img class='f-left' width='74' height='54' alt='' src="+imageshow+"> <span class='right-content'> <h2><a name='what'>"+obj.likes[i].message+"</a></h2> <span>"+obj.likes[i].addedon+" by <a class='' href='#'>"+obj.likes[i].username+"</a></span> <span class='flag Disblock'><img width='16' height='16' src="+countryflag+" alt=''>"+obj.likes[i].country+"</span> </span> <span class='right-like'> <a class='like-icon' href='#'>"+obj.likes[i].count_like+"</a> <a href='#' class='coment-icon'>"+obj.likes[i].count_comments+"</a> </span> </li>";
							}
							else
							{
								likeoutput+="<li onclick='postpage("+obj.likes[i].id+");'><img class='f-left' width='74' height='54' alt='' src="+imageshow+"> <span class='right-content'> <h2><a name='what'>"+obj.likes[i].message+"</a></h2> <span>"+obj.likes[i].addedon+" by <a class='' href='#'>"+obj.likes[i].username+"</a></span></span> <span class='right-like'> <a class='like-icon' href='#'>"+obj.likes[i].count_like+"</a> <a href='#' class='coment-icon'>"+obj.likes[i].count_comments+"</a> </span> </li>";
							}
						}
					}
					else
					{
						if(obj.likes[i].show_flag==1)
						{
							likeoutput+="<li onclick='postpage("+obj.likes[i].id+");'><span class='right-content'> <h2><a name='what'>"+obj.likes[i].message+"</a></h2> <span>"+obj.likes[i].addedon+" by <a class='' href='#'>"+obj.likes[i].username+"</a></span> <span class='flag Disblock'><img width='16' height='16' src="+countryflag+" alt=''>"+obj.likes[i].country+"</span> </span> <span class='right-like'> <a class='like-icon' href='#'>"+obj.likes[i].count_like+"</a> <a href='#' class='coment-icon'>"+obj.likes[i].count_comments+"</a> </span> </li>";

						}
						else
						{
							likeoutput+="<li onclick='postpage("+obj.likes[i].id+");'> <span class='right-content'> <h2><a name='what'>"+obj.likes[i].message+"</a></h2> <span>"+obj.likes[i].addedon+" by <a class='' href='#'>"+obj.likes[i].username+"</a></span></span> <span class='right-like'> <a class='like-icon' href='#'>"+obj.likes[i].count_like+"</a> <a href='#' class='coment-icon'>"+obj.likes[i].count_comments+"</a> </span> </li>";.0
						}
					   }
				       }
			          }
					   else
                      {
                            likeoutput+="<li > <span class='right-content'>"+nolike_found_socialapp+"</span> </li>";
                      }


			//Post

			var postoutput="";
			if(obj.posts!=null)
			{
				for(var i=0; i<obj.posts.length; i++)
				{
					var countryflag="http://"+window.localStorage.getItem("reseller")+obj.posts[i].country_flag;
					postoutput+="";

					if(obj.posts[i].attached!="0")
					{
						if(obj.posts[i].post_type=="video")
						{

							var imageshow="http://"+window.localStorage.getItem("reseller")+obj.posts[i].image;
							if(obj.posts[i].show_flag==1)
							{

								postoutput+="<li onclick='postpage("+obj.posts[i].id+");'><img class='f-left' width='74' height='54' alt='' src="+imageshow+"> <span class='right-content'> <h2><a name='what'>"+obj.posts[i].message+"</a></h2> <span>"+obj.posts[i].addedon+" by <a class='' href='#'>"+obj.posts[i].username+"</a></span> <span class='flag Disblock'><img width='16' height='16' src="+countryflag+" alt=''>"+obj.posts[i].country+"</span> </span> <span class='right-like'> <a class='like-icon' href='#'>"+obj.posts[i].likes+"</a> <a href='#' class='coment-icon'>"+obj.posts[i].comments+"</a> </span> </li>";
							}
							else
							{
								postoutput+="<li onclick='postpage("+obj.posts[i].id+");'><img class='f-left' width='74' height='54' alt='' src="+imageshow+"> <span class='right-content'> <h2><a name='what'>"+obj.posts[i].message+"</a></h2> <span>"+obj.posts[i].addedon+" by <a class='' href='#'>"+obj.posts[i].username+"</a></span></span> <span class='right-like'> <a class='like-icon' href='#'>"+obj.posts[i].likes+"</a> <a href='#' class='coment-icon'>"+obj.posts[i].comments+"</a> </span> </li>";
							}
						}
						else if(obj.posts[i].post_type=="image")
						{
							var imageshow="http://"+window.localStorage.getItem("reseller")+obj.posts[i].image;
							if(obj.posts[i].show_flag==1)
							{

								postoutput+="<li onclick='postpage("+obj.posts[i].id+");'><img class='f-left' width='74' height='54' alt='' src="+imageshow+"> <span class='right-content'> <h2><a name='what'>"+obj.posts[i].message+"</a></h2> <span>"+obj.posts[i].addedon+" by <a class='' href='#'>"+obj.posts[i].username+"</a></span> <span class='flag Disblock'><img width='16' height='16' src="+countryflag+" alt=''>"+obj.posts[i].country+"</span> </span> <span class='right-like'> <a class='like-icon' href='#'>"+obj.posts[i].likes+"</a> <a href='#' class='coment-icon'>"+obj.posts[i].comments+"</a> </span> </li>";

							}
							else
							{
								postoutput+="<li onclick='postpage("+obj.posts[i].id+");'><img class='f-left' width='74' height='54' alt='' src="+imageshow+"> <span class='right-content'> <h2><a name='what'>"+obj.posts[i].message+"</a></h2> <span>"+obj.posts[i].addedon+" by <a class='' href='#'>"+obj.posts[i].username+"</a></span></span> <span class='right-like'> <a class='like-icon' href='#'>"+obj.posts[i].likes+"</a> <a href='#' class='coment-icon'>"+obj.posts[i].comments+"</a> </span> </li>";
							}
						}
					}
					else
					{
						if(obj.posts[i].show_flag==1)
						{
							postoutput+="<li onclick='postpage("+obj.posts[i].id+");'><span class='right-content'> <h2><a name='what'>"+obj.posts[i].message+"</a></h2> <span>"+obj.posts[i].addedon+" by <a class='' href='#'>"+obj.posts[i].username+"</a></span> <span class='flag Disblock'><img width='16' height='16' src="+countryflag+" alt=''>"+obj.posts[i].country+"</span> </span> <span class='right-like'> <a class='like-icon' href='#'>"+obj.posts[i].likes+"</a> <a href='#' class='coment-icon'>"+obj.posts[i].comments+"</a> </span> </li>";

						}
						else
						{
							postoutput+="<li onclick='postpage("+obj.posts[i].id+");'> <span class='right-content'> <h2><a name='what'>"+obj.posts[i].message+"</a></h2> <span>"+obj.posts[i].addedon+" by <a class='' href='#'>"+obj.posts[i].username+"</a></span></span> <span class='right-like'> <a class='like-icon' href='#'>"+obj.posts[i].likes+"</a> <a href='#' class='coment-icon'>"+obj.posts[i].comments+"</a> </span> </li>";
						}
					}

				}
			}
			var followbutton="";
			var subscribebutton="";

			//	 if(
			if(obj.user.followed==1)
			{
				followbutton="<button class='follow' data-role='none' onclick='followuser("+obj.user.userId+")'>"+following_socialapp+"</button>";

			}
			else

			{
				followbutton="<button class='unfollow' data-role='none' onclick='followuser("+obj.user.userId+")'>"+follow_witjout_s_socialapp+"</button>";
			}
			if(obj.user.subscribed==1)
			{
				followbutton+="<button class='follow' data-role='none' onclick='subscribeuser("+obj.user.userId+")'>"+subscribed_socialapp+"</button>";

			}
			else

			{
				followbutton+="<button class='unfollow' data-role='none' onclick='subscribeuser("+obj.user.userId+")'>"+subscribe_without_s_socialapp+"</button>";
			}
			var countryflag="http://"+window.localStorage.getItem("reseller")+obj.user.country_flag;
			 var html='<section class=" magentocl socialApp" data-role="none"><div id="appypie-search-section" class="social-search"><input type="text" id="searchsocialtext11" data-role="none" class="filled_inp" value="" placeholder='+placeholder_search_socialapp+'><a href="#" onclick="searchsocialfunction(\'searchsocialtext11\');" class="searchBtn" data-role="none">'+without_palceholder_search_socialapp+'</a><a href="#" class="social-uploadBtn" onclick="capturepage();"><img src="images/social-upload.png" width="32" height="32" alt=""/></a></div><div id="middle_page" class="social-inner-page"><div class="socialpost-box"><h4>'+obj.user.name+'</h4></div> <div class="socialpost-box"> <img width="74" height="54" src='+avatarr+' alt="" class="f-left"> <div class="video_text full" id="userprofile_follow">'+followbutton+'</div> <div class="video_text full clearAll"> <div class="follow-boxes"><ul><li onclick="followers('+obj.user.userId+');"> <span class="cont">'+obj.user.num_followers+'</span> <span >"+follower_without_colon_socialapp+"</span></li> <li onclick="Following('+obj.user.userId+');"> <span class="cont">'+obj.user.num_following+'</span> <span>"+following_socialapp+"</span></li> <li onclick="Subscribers('+obj.user.userId+');"> <span class="cont">'+obj.user.num_subscriber+'</span> <span>'+subscribe_without_colon_socialapp+'</span></li> </ul> </div></div> </div> <div class="domtab"> <ul class="domtabs"> <li><a href="#play"><span class="play">2</span></a></li> <li><a href="#user"><span class="user">2</span></a></li> <li><a href="#love"><span class="love">2</span></a></li> <li><a href="#chat"><span class="chat">2</span></a></li> </ul> <div> <ul class="play" id="play">'+postoutput+'</ul> </div> <div> <ul class="play user" id="user"> <li>'+obj.user.name+' is '+gender+'</li><li><span class="flag Disblock Disblock"><img width="16" height="16" src='+countryflag+' alt=""> '+obj.user.country+'</span></li><li><span><strong> '+post_socialapp+' </strong>'+obj.user.num_posts+'</span></li><li><span><strong>'+decription_socialapp+'</strong></span><br><span>'+obj.user.aboutme+'</span></li>  <li><span><strong> '+member_since_socialapp+' </strong>'+obj.user.addedon+'</span></li> </ul> </div> <div> <ul class="play" id="love"> '+likeoutput+' </ul></div> <div> <ul class="play chat" id="chat">'+commentoutput+'</ul> </div> </div>  </div> </section>';
			 $('#contentHolder22').css('background', '#edf0f5');
			 appendHtml(html+" "+socialMenu,22,3,'food');
			domtab.init();

			if(profileId==localStorage.getItem('userid'))
			{
				document.getElementById("userprofile_follow").style.display='none';

			}

		},
		error: function(response, textStatus, errorThrown)
		{

			console.log("Error : "+JSON.stringify(response));
			console.log("Error : "+textStatus);
			console.log("Error : "+errorThrown.responseText);
		}
	});


}

function subscribeuser(other_userid)
{
	$('.appypie-loader').show();
	var wsUrll="http://"+window.localStorage.getItem("reseller")+"/services/social-soap#subscribeUnsubscribeJson";
	var soapRequestt ='<?xml version="1.0" encoding="utf-8"?> <soap:Envelope xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"  xmlns:xsd="http://www.w3.org/2001/XMLSchema" xmlns:soap="http://schemas.xmlsoap.org/soap/envelope/"> <soap:Body><subscribeUnsubscribeJson xmlns=\"http://'+window.localStorage.getItem("reseller")+'/services/social-soap#subscribeUnsubscribeJson\"><appId>'+localStorage.getItem('applicationID')+'</appId><userId>'+localStorage.getItem('userid')+'</userId><friendId>'+other_userid+'</friendId></subscribeUnsubscribeJson></soap:Body></soap:Envelope>';
	console.log("SoapRequest : "+ soapRequestt);
	$.ajax({
		type: "POST",
		url: wsUrll,
		contentType: "text/xml",
		dataType: "text",
		data: soapRequestt,
		success: function(data, status, req)
		{
			var strJSON = $(req.responseText).find("return").text();
			console.log("success follow gaurav : "+strJSON);

			if(strJSON=='"unsubscribe"'|| strJSON=='"subscribe"')
			{

				userProfile(glopadprofileid);
			}
			else
			{
				$('.appypie-loader').hide();
			}
		},
		error: function(response, textStatus, errorThrown)
		{
			console.log("Error : "+JSON.stringify(response));
			console.log("Error : "+textStatus);
			console.log("Error : "+errorThrown.responseText);
		}
	});
}
function followuser(other_userid)
{
	$('.appypie-loader').show();
	var wsUrll="http://"+window.localStorage.getItem("reseller")+"/services/social-soap#friendUnfriendJson";
	var soapRequestt ='<?xml version="1.0" encoding="utf-8"?> <soap:Envelope xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"  xmlns:xsd="http://www.w3.org/2001/XMLSchema" xmlns:soap="http://schemas.xmlsoap.org/soap/envelope/"> <soap:Body><friendUnfriendJson xmlns=\"http://'+window.localStorage.getItem("reseller")+'/services/social-soap#friendUnfriendJson\"><appId>'+localStorage.getItem('applicationID')+'</appId><userId>'+localStorage.getItem('userid')+'</userId><friendId>'+other_userid+'</friendId></friendUnfriendJson></soap:Body></soap:Envelope>';
	console.log("SoapRequest : "+ soapRequestt);
	$.ajax({
		type: "POST",
		url: wsUrll,
		contentType: "text/xml",
		dataType: "text",
		data: soapRequestt,
		success: function(data, status, req)
		{
			var strJSON = $(req.responseText).find("return").text();
			console.log("success follow gaurav : "+strJSON);

			if(strJSON=='"unfollow"'|| strJSON=='"follow"')
			{

				userProfile(glopadprofileid);
			}
			else
			{
				$('.appypie-loader').hide();
			}
		},
		error: function(response, textStatus, errorThrown)
		{
			console.log("Error : "+JSON.stringify(response));
			console.log("Error : "+textStatus);
			console.log("Error : "+errorThrown.responseText);
		}
	});
}

function followers(userId)
{

	$('.appypie-loader').show();
	var wsUrll="http://"+window.localStorage.getItem("reseller")+"/services/social-soap#getFollowerUserJson";
	var soapRequestt ='<?xml version="1.0" encoding="utf-8"?> <soap:Envelope xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"  xmlns:xsd="http://www.w3.org/2001/XMLSchema" xmlns:soap="http://schemas.xmlsoap.org/soap/envelope/"> <soap:Body><getFollowerUserJson xmlns=\"http://'+window.localStorage.getItem("reseller")+'/services/social-soap#getFollowerUserJson\"><appId>'+localStorage.getItem('applicationID')+'</appId><userId>'+userId+'</userId></getFollowerUserJson></soap:Body></soap:Envelope>';
	console.log("SoapRequest : "+ soapRequestt);
	$.ajax({
		type: "POST",
		url: wsUrll,
		contentType: "text/xml",
		dataType: "text",
		data: soapRequestt,
		success: function(data, status, req)
		{
			var strJSON = $(req.responseText).find("return").text();
			console.log("success follower gaurav : "+strJSON);
			var obj = JSON.parse(strJSON);
			var output="";

			if(obj!=null)
			{
				for(var i=0; i<obj.length; i++)
				{
					var avatarr="http://"+window.localStorage.getItem("reseller")+obj[i].avatar;
					if(obj[i].show_flag==1)
					{

						var countryflag="http://"+window.localStorage.getItem("reseller")+obj[i].country_flag;
						output+="<div class='socialpost-box top100'><a onclick='userProfile("+obj[i].id+");'><img width='74' height='54' src='"+avatarr+"' alt='' class='f-left'><div class='video_text'><h4>"+obj[i].name+"</h4><span class='flag'><img width='16' height='16' alt='' src='"+countryflag+"'>"+obj[i].country+"</span></div><div class='right-content'><ul class='listing'><li>"+followers_socialapp+" "+obj[i].followers+"</li><li>"+subscriber_socialapp+" "+obj[i].subscribers+"</li><li>"+post_socialapp+"  "+obj[i].posts+"</li></ul></div></a></div>";
					}
					else
					{

						output+="<div class='socialpost-box top100'><a onclick='userProfile("+obj[i].id+");'><img width='74' height='54' src='"+avatarr+"' alt='' class='f-left'><div class='video_text'><h4>"+obj[i].name+"</h4></div><div class='right-content'><ul class='listing'><li>"+followers_socialapp+" "+obj[i].followers+"</li><li>"+subscriber_socialapp+" "+obj[i].subscribers+"</li><li>"+post_socialapp+"  "+obj[i].posts+"</li></ul></div></a></div>";

					}
				}
			}

			 var html="<section class='magentocl whoFollow' style='' data-role='none'><div id='appypie-search-section' class='social-search'><input type='text' id='searchsocialtext12' data-role='none' class='filled_inp' value='' placeholder="+placeholder_search_socialapp+"><a href='#' onclick='searchsocialfunction(\"searchsocialtext12\");' class='searchBtn' data-role='none'>"+without_palceholder_search_socialapp+"</a><a href='#' class='social-uploadBtn' onclick='capturepage();'><img src='images/social-upload.png' alt=''/></a></div><div id='middle_page' class='social-inner-page'>"+output+"</div></section>";
			 $('#contentHolder22').css('background', '#edf0f5');
			 appendHtml(html+" "+socialMenu,22,3,'food');


		},
		error: function(response, textStatus, errorThrown)
		{
			console.log("Error : "+JSON.stringify(response));
			console.log("Error : "+textStatus);
			console.log("Error : "+errorThrown.responseText);
		}
	});

}
function Following(userId)
{

	$('.appypie-loader').show();
	var wsUrll="http://"+window.localStorage.getItem("reseller")+"/services/social-soap#getFollowingUserJson";
	var soapRequestt ='<?xml version="1.0" encoding="utf-8"?> <soap:Envelope xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"  xmlns:xsd="http://www.w3.org/2001/XMLSchema" xmlns:soap="http://schemas.xmlsoap.org/soap/envelope/"> <soap:Body><getFollowingUserJson xmlns=\"http://'+window.localStorage.getItem("reseller")+'/services/social-soap#getFollowingUserJson\"><appId>'+localStorage.getItem('applicationID')+'</appId><userId>'+userId+'</userId></getFollowingUserJson></soap:Body></soap:Envelope>';
	console.log("SoapRequest : "+ soapRequestt);
	$.ajax({
		type: "POST",
		url: wsUrll,
		contentType: "text/xml",
		dataType: "text",
		data: soapRequestt,
		success: function(data, status, req)
		{
			var strJSON = $(req.responseText).find("return").text();
			console.log("success follower gaurav : "+strJSON);
			var obj = JSON.parse(strJSON);
			var output="";

			if(obj!=null)
			{
				for(var i=0; i<obj.length; i++)
				{
					var avatarr="http://"+window.localStorage.getItem("reseller")+obj[i].avatar;
					if(obj[i].show_flag==1)
					{

						var countryflag="http://"+window.localStorage.getItem("reseller")+obj[i].country_flag;
						output+="<div class='socialpost-box top100'><a onclick='userProfile("+obj[i].id+");'><img width='74' height='54' src='"+avatarr+"' alt='' class='f-left'><div class='video_text'><h4>"+obj[i].name+"</h4><span class='flag'><img width='16' height='16' alt='' src='"+countryflag+"'>"+obj[i].country+"</span></div><div class='right-content'><ul class='listing'><li>"+followers_socialapp+" "+obj[i].followers+"</li><li>"+subscriber_socialapp+" "+obj[i].subscribers+"</li><li>"+post_socialapp+"  "+obj[i].posts+"</li></ul></div></a></div>";
					}
					else
					{

						output+="<div class='socialpost-box top100'><a onclick='userProfile("+obj[i].id+");'><img width='74' height='54' src='"+avatarr+"' alt='' class='f-left'><div class='video_text'><h4>"+obj[i].name+"</h4></div><div class='right-content'><ul class='listing'><li>"+followers_socialapp+" "+obj[i].followers+"</li><li>"+subscriber_socialapp+" "+obj[i].subscribers+"</li><li>"+post_socialapp+"  "+obj[i].posts+"</li></ul></div></a></div>";

					}
				}
			}

			 var html="<section class='magentocl whoFollow' style='' data-role='none'><div id='appypie-search-section' class='social-search'><input type='text' id='searchsocialtext13' data-role='none' class='filled_inp' value='' placeholder="+placeholder_search_socialapp+"><a href='#' onclick='searchsocialfunction(\"searchsocialtext13\");' class='searchBtn' data-role='none'>"+without_palceholder_search_socialapp+"</a><a href='#' class='social-uploadBtn' onclick='capturepage();'><img src='images/social-upload.png' alt=''/></a></div><div id='middle_page' class='social-inner-page'>"+output+"</div></section>";
			 $('#contentHolder22').css('background', '#edf0f5');
			 appendHtml(html+" "+socialMenu,22,3,'food');
		},
		error: function(response, textStatus, errorThrown)
		{
			console.log("Error : "+JSON.stringify(response));
			console.log("Error : "+textStatus);
			console.log("Error : "+errorThrown.responseText);
		}
	});


}
function Subscribers(userId)
{

	$('.appypie-loader').show();
	var wsUrll="http://"+window.localStorage.getItem("reseller")+"/services/social-soap#getSubscriberUserJson";
	var soapRequestt ='<?xml version="1.0" encoding="utf-8"?> <soap:Envelope xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"  xmlns:xsd="http://www.w3.org/2001/XMLSchema" xmlns:soap="http://schemas.xmlsoap.org/soap/envelope/"> <soap:Body><getSubscriberUserJson xmlns=\"http://'+window.localStorage.getItem("reseller")+'/services/social-soap#getSubscriberUserJson\"><appId>'+localStorage.getItem('applicationID')+'</appId><userId>'+userId+'</userId></getSubscriberUserJson></soap:Body></soap:Envelope>';
	console.log("SoapRequest : "+ soapRequestt);
	$.ajax({
		type: "POST",
		url: wsUrll,
		contentType: "text/xml",
		dataType: "text",
		data: soapRequestt,
		success: function(data, status, req)
		{
			var strJSON = $(req.responseText).find("return").text();
			console.log("success follower gaurav : "+strJSON);
			var obj = JSON.parse(strJSON);
			var output="";

			if(obj!=null)
			{
				for(var i=0; i<obj.length; i++)
				{
					var avatarr="http://"+window.localStorage.getItem("reseller")+obj[i].avatar;
					if(obj[i].show_flag==1)
					{

						var countryflag="http://"+window.localStorage.getItem("reseller")+obj[i].country_flag;
						output+="<div class='socialpost-box top100'><a onclick='userProfile("+obj[i].id+");'><img width='74' height='54' src='"+avatarr+"' alt='' class='f-left'><div class='video_text'><h4>"+obj[i].name+"</h4><span class='flag'><img width='16' height='16' alt='' src='"+countryflag+"'>"+obj[i].country+"</span></div><div class='right-content'><ul class='listing'><li>"+followers_socialapp+" "+obj[i].followers+"</li><li>"+subscriber_socialapp+" "+obj[i].subscribers+"</li><li>post:  "+obj[i].posts+"</li></ul></div></a></div>";
					}
					else
					{

						output+="<div class='socialpost-box top100'><a onclick='userProfile("+obj[i].id+");'><img width='74' height='54' src='"+avatarr+"' alt='' class='f-left'><div class='video_text'><h4>"+obj[i].name+"</h4></div><div class='right-content'><ul class='listing'><li>"+followers_socialapp+" "+obj[i].followers+"</li><li>"+subscriber_socialapp+" "+obj[i].subscribers+"</li><li>"+post_socialapp+"  "+obj[i].posts+"</li></ul></div></a></div>";

					}
				}
			}

			var html="<section class='magentocl whoFollow' style='' data-role='none'><div id='appypie-search-section' class='social-search'><input type='text' id='searchsocialtext14' data-role='none' class='filled_inp' value='' placeholder="+placeholder_search_socialapp+"><a href='#' onclick='searchsocialfunction(\"searchsocialtext14\");' class='searchBtn' data-role='none'>"+without_palceholder_search_socialapp+"</a><a href='#' class='social-uploadBtn' onclick='capturepage();'><img src='images/social-upload.png' alt=''/></a></div><div id='middle_page' class='social-inner-page'>"+output+"</div></section>";
			$('#contentHolder22').css('background', '#edf0f5');
			appendHtml(html+" "+socialMenu,22,3,'food');


		},
		error: function(response, textStatus, errorThrown)
		{
			console.log("Error : "+JSON.stringify(response));
			console.log("Error : "+textStatus);
			console.log("Error : "+errorThrown.responseText);
		}
	});


}

function MYProfile()
{


	if(window.localStorage.getItem("layout")=="slidemenu"){
		snapper.close();
	}

	$('.appypie-loader').show();
	var wsUrll="http://"+window.localStorage.getItem("reseller")+"/services/social-soap#userProfileJson";
	var soapRequestt ='<?xml version="1.0" encoding="utf-8"?> <soap:Envelope xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"  xmlns:xsd="http://www.w3.org/2001/XMLSchema" xmlns:soap="http://schemas.xmlsoap.org/soap/envelope/"> <soap:Body><userProfileJson xmlns=\"http://'+window.localStorage.getItem("reseller")+'/services/social-soap#userProfileJson\"><appId>'+localStorage.getItem('applicationID')+'</appId><userId>'+localStorage.getItem('userid')+'</userId><profileId>'+localStorage.getItem('userid')+'</profileId></userProfileJson></soap:Body></soap:Envelope>';

	console.log("SoapRequest : "+ soapRequestt);
	$.ajax({
		type: "POST",
		url: wsUrll,
		contentType: "text/xml",
		dataType: "text",
		data: soapRequestt,
		success: function(data, status, req)
		{
			var strJSON = $(req.responseText).find("return").text();
			console.log("success MYprofile gaurav : "+strJSON);
			var obj = JSON.parse(strJSON);
			var output="";
			var avatarr="http://"+window.localStorage.getItem("reseller")+obj.user.avatar;
			var gender="";

			if(obj.user.gender=='m')
			{
				gender=gender_male_socialapp;
			}
			else
			{
				gender=gender_female_socialapp;
			}
			var commentoutput="";
			var likeoutput="";
			if(obj.comments!=null)
			{

				for(var i=0; i<obj.comments.length; i++)
				{
					commentoutput+="<li onclick='postpage("+obj.comments[i].id+");'><strong class='Disblock'>"+obj.comments[i].comment+"</strong><span class='Disblock'>"+obj.comments[i].comment_date+"</span><span class='orng-txt Disblock'><strong>on "+obj.comments[i].username+"'s post</strong> </span></li>";
				}

			}
			if(obj.likes!=null)
			{
				for(var i=0; i<obj.likes.length; i++)
				{
					var countryflag="http://"+window.localStorage.getItem("reseller")+obj.likes[i].country_flag;
					likeoutput+="";
					if(obj.likes[i].attached!="0")
					{
						if(obj.likes[i].post_type=="video")
						{
							var imageshow="http://"+window.localStorage.getItem("reseller")+obj.likes[i].image;
							if(obj.likes[i].show_flag==1)
							{

								likeoutput+="<li onclick='postpage("+obj.likes[i].id+");'><img class='f-left' width='74' height='54' alt='' src="+imageshow+"> <span class='right-content'> <h2><a name='what'>"+obj.likes[i].message+"</a></h2> <span>"+obj.likes[i].addedon+" by <a class='' href='#'>"+obj.likes[i].username+"</a></span> <span class='flag Disblock'><img width='16' height='16' src="+countryflag+" alt=''>"+obj.likes[i].country+"</span> </span> <span class='right-like'> <a class='like-icon' href='#'>"+obj.likes[i].count_like+"</a> <a href='#' class='coment-icon'>"+obj.likes[i].count_comments+"</a> </span> </li>";
							}
							else
							{
								likeoutput+="<li onclick='postpage("+obj.likes[i].id+");'><img class='f-left' width='74' height='54' alt='' src="+imageshow+"> <span class='right-content'> <h2><a name='what'>"+obj.likes[i].message+"</a></h2> <span>"+obj.likes[i].addedon+" by <a class='' href='#'>"+obj.likes[i].username+"</a></span></span> <span class='right-like'> <a class='like-icon' href='#'>"+obj.likes[i].count_like+"</a> <a href='#' class='coment-icon'>"+obj.likes[i].count_comments+"</a> </span> </li>";
							}
						}
						else if(obj.likes[i].post_type=="image")
						{
							var imageshow="http://"+window.localStorage.getItem("reseller")+obj.likes[i].image;
							if(obj.likes[i].show_flag==1)
							{

								likeoutput+="<li onclick='postpage("+obj.likes[i].id+");'><img class='f-left' width='74' height='54' alt='' src="+imageshow+"> <span class='right-content'> <h2><a name='what'>"+obj.likes[i].message+"</a></h2> <span>"+obj.likes[i].addedon+" by <a class='' href='#'>"+obj.likes[i].username+"</a></span> <span class='flag Disblock'><img width='16' height='16' src="+countryflag+" alt=''>"+obj.likes[i].country+"</span> </span> <span class='right-like'> <a class='like-icon' href='#'>"+obj.likes[i].count_like+"</a> <a href='#' class='coment-icon'>"+obj.likes[i].count_comments+"</a> </span> </li>";
							}
							else
							{
								likeoutput+="<li onclick='postpage("+obj.likes[i].id+");'><img class='f-left' width='74' height='54' alt='' src="+imageshow+"> <span class='right-content'> <h2><a name='what'>"+obj.likes[i].message+"</a></h2> <span>"+obj.likes[i].addedon+" by <a class='' href='#'>"+obj.likes[i].username+"</a></span></span> <span class='right-like'> <a class='like-icon' href='#'>"+obj.likes[i].count_like+"</a> <a href='#' class='coment-icon'>"+obj.likes[i].count_comments+"</a> </span> </li>";
							}
						}
					}
					else
					{
						if(obj.likes[i].show_flag==1)
						{
							likeoutput+="<li onclick='postpage("+obj.likes[i].id+");'><span class='right-content'> <h2><a name='what'>"+obj.likes[i].message+"</a></h2> <span>"+obj.likes[i].addedon+" by <a class='' href='#'>"+obj.likes[i].username+"</a></span> <span class='flag Disblock'><img width='16' height='16' src="+countryflag+" alt=''>"+obj.likes[i].country+"</span> </span> <span class='right-like'> <a class='like-icon' href='#'>"+obj.likes[i].count_like+"</a> <a href='#' class='coment-icon'>"+obj.likes[i].count_comments+"</a> </span> </li>";

						}
						else
						{
							likeoutput+="<li onclick='postpage("+obj.likes[i].id+");'> <span class='right-content'> <h2><a name='what'>"+obj.likes[i].message+"</a></h2> <span>"+obj.likes[i].addedon+" by <a class='' href='#'>"+obj.likes[i].username+"</a></span></span> <span class='right-like'> <a class='like-icon' href='#'>"+obj.likes[i].count_like+"</a> <a href='#' class='coment-icon'>"+obj.likes[i].count_comments+"</a> </span> </li>";
						}
					}
				}
			}
               
			   else
               {
                 likeoutput+="<li > <span class='right-content'>"+nolike_found_socialapp+"</li>";
               }
			//Post

			var postoutput="";
			if(obj.posts!=null)
			{
				for(var i=0; i<obj.posts.length; i++)
				{
					var countryflag="http://"+window.localStorage.getItem("reseller")+obj.posts[i].country_flag;
					postoutput+="";

					if(obj.posts[i].attached!="0")
					{
						if(obj.posts[i].post_type=="video")
						{

							var imageshow="http://"+window.localStorage.getItem("reseller")+obj.posts[i].image;
							if(obj.posts[i].show_flag==1)
							{

								postoutput+="<li onclick='postpage("+obj.posts[i].id+");'><img class='f-left' width='74' height='54' alt='' src="+imageshow+"> <span class='right-content'> <h2><a name='what'>"+obj.posts[i].message+"</a></h2> <span>"+obj.posts[i].addedon+" by <a class='' href='#'>"+obj.posts[i].username+"</a></span> <span class='flag Disblock'><img width='16' height='16' src="+countryflag+" alt=''>"+obj.posts[i].country+"</span> </span> <span class='right-like'> <a class='like-icon' href='#'>"+obj.posts[i].likes+"</a> <a href='#' class='coment-icon'>"+obj.posts[i].comments+"</a> </span> </li>";
							}
							else
							{
								postoutput+="<li onclick='postpage("+obj.posts[i].id+");'><img class='f-left' width='74' height='54' alt='' src="+imageshow+"> <span class='right-content'> <h2><a name='what'>"+obj.posts[i].message+"</a></h2> <span>"+obj.posts[i].addedon+" by <a class='' href='#'>"+obj.posts[i].username+"</a></span></span> <span class='right-like'> <a class='like-icon' href='#'>"+obj.posts[i].likes+"</a> <a href='#' class='coment-icon'>"+obj.posts[i].comments+"</a> </span> </li>";
							}
						}
						else if(obj.posts[i].post_type=="image")
						{
							var imageshow="http://"+window.localStorage.getItem("reseller")+obj.posts[i].image;
							if(obj.posts[i].show_flag==1)
							{

								postoutput+="<li onclick='postpage("+obj.posts[i].id+");'><img class='f-left' width='74' height='54' alt='' src="+imageshow+"> <span class='right-content'> <h2><a name='what'>"+obj.posts[i].message+"</a></h2> <span>"+obj.posts[i].addedon+" by <a class='' href='#'>"+obj.posts[i].username+"</a></span> <span class='flag Disblock'><img width='16' height='16' src="+countryflag+" alt=''>"+obj.posts[i].country+"</span> </span> <span class='right-like'> <a class='like-icon' href='#'>"+obj.posts[i].likes+"</a> <a href='#' class='coment-icon'>"+obj.posts[i].comments+"</a> </span> </li>";

							}
							else
							{
								postoutput+="<li onclick='postpage("+obj.posts[i].id+");'><img class='f-left' width='74' height='54' alt='' src="+imageshow+"> <span class='right-content'> <h2><a name='what'>"+obj.posts[i].message+"</a></h2> <span>"+obj.posts[i].addedon+" by <a class='' href='#'>"+obj.posts[i].username+"</a></span></span> <span class='right-like'> <a class='like-icon' href='#'>"+obj.posts[i].likes+"</a> <a href='#' class='coment-icon'>"+obj.posts[i].comments+"</a> </span> </li>";
							}
						}
					}
					else
					{
						if(obj.posts[i].show_flag==1)
						{
							postoutput+="<li onclick='postpage("+obj.posts[i].id+");'><span class='right-content'> <h2><a name='what'>"+obj.posts[i].message+"</a></h2> <span>"+obj.posts[i].addedon+" by <a class='' href='#'>"+obj.posts[i].username+"</a></span> <span class='flag Disblock'><img width='16' height='16' src="+countryflag+" alt=''>"+obj.posts[i].country+"</span> </span> <span class='right-like'> <a class='like-icon' href='#'>"+obj.posts[i].likes+"</a> <a href='#' class='coment-icon'>"+obj.posts[i].comments+"</a> </span> </li>";

						}
						else
						{
							postoutput+="<li onclick='postpage("+obj.posts[i].id+");'> <span class='right-content'> <h2><a name='what'>"+obj.posts[i].message+"</a></h2> <span>"+obj.posts[i].addedon+" by <a class='' href='#'>"+obj.posts[i].username+"</a></span></span> <span class='right-like'> <a class='like-icon' href='#'>"+obj.posts[i].likes+"</a> <a href='#' class='coment-icon'>"+obj.posts[i].comments+"</a> </span> </li>";
						}
					}

				}
			}
			var followbutton="";
			var countryflag="http://"+window.localStorage.getItem("reseller")+obj.user.country_flag;
			var html='<section class=" magentocl socialApp" data-role="none"><div id="appypie-search-section" class="social-search"><input type="text" id="searchsocialtext15" data-role="none" class="filled_inp" value="" placeholder='+placeholder_search_socialapp+'><a href="#" onclick="searchsocialfunction(\'searchsocialtext15\');" class="searchBtn" data-role="none">'+without_palceholder_search_socialapp+'</a><a href="#" class="social-uploadBtn" onclick="capturepage();"><img src="images/social-upload.png" width="32" height="32" alt=""/></a></div><div id="middle_page" class="social-inner-page"><div class="socialpost-box"><h4>'+obj.user.name+'</h4></div> <div class="socialpost-box"> <img width="74" height="54" src='+avatarr+' alt="" class="f-left"> <div class="video_text full"><button class="unfollow" data-role="none"  onclick="EditProfile();">'+edit_profile_socialapp+'</button></div> <div class="video_text full clearAll"> <div class="follow-boxes"><ul><li onclick="followers('+obj.user.userId+');"> <span class="cont">'+obj.user.num_followers+'</span> <span >'+follower_without_colon_socialapp+'</span></li> <li onclick="Following('+obj.user.userId+');"> <span class="cont">'+obj.user.num_following+'</span> <span>'+following_socialapp+'</span></li> <li onclick="Subscribers('+obj.user.userId+');"> <span class="cont">'+obj.user.num_subscriber+'</span> <span>'+subscribe_without_colon_socialapp+'</span></li> </ul> </div></div> </div> <div class="domtab"> <ul class="domtabs"> <li><a href="#play"><span class="play">2</span></a></li> <li><a href="#user"><span class="user">2</span></a></li> <li><a href="#love"><span class="love">2</span></a></li> <li><a href="#chat"><span class="chat">2</span></a></li> </ul> <div> <ul class="play" id="play">'+postoutput+'</ul> </div> <div> <ul class="play user" id="user"> <li>'+obj.user.name+' is '+gender+'</li><li><span class="flag Disblock Disblock"><img width="16" height="16" src='+countryflag+' alt=""> '+obj.user.country+'</span></li><li><span><strong> '+post_socialapp+' </strong>'+obj.user.num_posts+'</span></li><li><span><strong>'+decription_socialapp+' </strong></span><br><span>'+obj.user.aboutme+'</span></li>  <li><span><strong> "+member_since_socialapp+" </strong>'+obj.user.addedon+'</span></li> </ul> </div> <div> <ul class="play" id="love"> '+likeoutput+' </ul></div> <div> <ul class="play chat" id="chat">'+commentoutput+'</ul> </div> </div>  </div> </section>';
			$('#contentHolder21').css('background', '#edf0f5');
			appendHtml(html+" "+socialMenu,21,1,'food');
			domtab.init();


		},
		error: function(response, textStatus, errorThrown)
		{
			console.log("Error : "+JSON.stringify(response));
			console.log("Error : "+textStatus);
			console.log("Error : "+errorThrown.responseText);
		}
	});
}

function likeunlikepostpage(postid)
{
	$('.appypie-loader').show();
	var wsUrll="http://"+window.localStorage.getItem("reseller")+"/services/social-soap#likeUnlikeJson";
	var soapRequestt ='<?xml version="1.0" encoding="utf-8"?> <soap:Envelope xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"  xmlns:xsd="http://www.w3.org/2001/XMLSchema" xmlns:soap="http://schemas.xmlsoap.org/soap/envelope/"> <soap:Body><likeUnlikeJson xmlns=\"http://'+window.localStorage.getItem("reseller")+'/services/social-soap#likeUnlikeJson\"><postId>'+postid+'</postId><appId>'+localStorage.getItem('applicationID')+'</appId><userId>'+localStorage.getItem('userid')+'</userId></likeUnlikeJson></soap:Body></soap:Envelope>';

	console.log("SoapRequest : "+ soapRequestt);
	$.ajax({
		type: "POST",
		url: wsUrll,
		contentType: "text/xml",
		dataType: "text",
		data: soapRequestt,
		success: function(data, status, req)
		{
			var strJSON = $(req.responseText).find("return").text();
			console.log("success postpage gaurav : "+req);
			postpage(postid);

		},
		error: function(response, textStatus, errorThrown)
		{
			console.log("Error : "+JSON.stringify(response));
			console.log("Error : "+textStatus);
			console.log("Error : "+errorThrown.responseText);
		}
	});

}

function commentpostpage(postid)
{
	 var html="<section class=' magentocl' style=''>\
         <div id='middle_page' class='social-inner-page'>\
         <div class='socialpost-box'>\
         <h1 class='heading'>Comment</h1>\
         <ul class='login-box'>\
         <form action='' method='get' class='caption'>\
         <div  class='caption_inner'><textarea name='' id='commentsTextareaPostpage' cols='' rows='' placeholder="+add_comment_socialapp+"></textarea></div>\
         </form>\
         <li><button onclick='Savecommentpostpage("+postid+");'>Save</button></li>\
         </ul>\
         <br clear='all'>\
         </div>\
         </div>\
         </section>";
	 $('#contentHolder23').css('background', '#edf0f5');
	appendHtml(html+" "+socialMenu,23,3,'food');


}
function  Savecommentpostpage(postid)
{
	if(document.getElementById("commentsTextareaPostpage").value!="")
	{
		$('.appypie-loader').show();
		var wsUrll="http://"+window.localStorage.getItem("reseller")+"/services/social-soap#saveCommentJson";
		var soapRequestt ='<?xml version="1.0" encoding="utf-8"?> <soap:Envelope xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"  xmlns:xsd="http://www.w3.org/2001/XMLSchema" xmlns:soap="http://schemas.xmlsoap.org/soap/envelope/"> <soap:Body><saveCommentJson xmlns=\"http://'+window.localStorage.getItem("reseller")+'/services/social-soap#saveCommentJson\"><postId>'+postid+'</postId><appId>'+localStorage.getItem('applicationID')+'</appId><userId>'+localStorage.getItem('userid')+'</userId><comment>'+document.getElementById("commentsTextareaPostpage").value+'</comment></saveCommentJson></soap:Body></soap:Envelope>';

		console.log("SoapRequest : "+ soapRequestt);
		$.ajax({
			type: "POST",
			url: wsUrll,
			contentType: "text/xml",
			dataType: "text",
			data: soapRequestt,
			success: function(data, status, req)
			{
				var strJSON = $(req.responseText).find("return").text();
				console.log("success postpage gaurav : "+req);
				postpage(postid);

			},
			error: function(response, textStatus, errorThrown)
			{
				console.log("Error : "+JSON.stringify(response));
				console.log("Error : "+textStatus);
				console.log("Error : "+errorThrown.responseText);
			}
		});
	}
	else
	{
		var message=alert_enter_comment_socialapp;
		navigator.notification.alert(
				message,  // message
				alertDismissed,         // callback
				alert_message_socialapp,            // title
				social_login_fb_alert_ok_socialapp                  // buttonName
		);
	}
}

function commentpostpagenotallowed()
{
	var message=alert_not_allowed_comment_socialapp;
	navigator.notification.alert(
			message,  // message
			alertDismissed,         // callback
			alert_message_socialapp,            // title
			social_login_fb_alert_ok_socialapp                  // buttonName
	);
}
//13/01/16 change
function postpage(postid)
{

	$('.appypie-loader').show();
	var wsUrll="http://"+window.localStorage.getItem("reseller")+"/services/social-soap#postdetailJson";
	var soapRequestt ='<?xml version="1.0" encoding="utf-8"?> <soap:Envelope xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"  xmlns:xsd="http://www.w3.org/2001/XMLSchema" xmlns:soap="http://schemas.xmlsoap.org/soap/envelope/"> <soap:Body><postdetailJson xmlns=\"http://'+window.localStorage.getItem("reseller")+'/services/social-soap#postdetailJson\"><appId>'+localStorage.getItem('applicationID')+'</appId><userId>'+localStorage.getItem('userid')+'</userId><postId>'+postid+'</postId></postdetailJson></soap:Body></soap:Envelope>';

	console.log("SoapRequest : "+ soapRequestt);
	$.ajax({
		type: "POST",
		url: wsUrll,
		contentType: "text/xml",
		dataType: "text",
		data: soapRequestt,
		success: function(data, status, req)
		{
			var strJSON = $(req.responseText).find("return").text();
			console.log("success postpage gaurav : "+strJSON);
			var obj = JSON.parse(strJSON);
			var output="";
			var avatarr="http://"+window.localStorage.getItem("reseller")+obj.avatar;
			var countryflag="";
		    var iddd = obj.id
                   
                     if(iddd == null)
                      {
                      
                      latestsocial()
                      }
                      else
                      {
			 if(obj.show_flag==0)
                      {
                      if(obj.country_flag)
                      {
                      countryflag="http://"+localStorage.getItem("reseller")+obj.country_flag;
                      }
                      else
                      {
                      
                      }
                      }
                      else
                      {
                            countryflag="";
                      }
                     
                      if(countryflag=="")
                      {
						
                         var displyimagenone = 'none';
                      }
                      else
                      {
						  
                         var displyimagenone = 'block';
                      }
			var bottompostpage="";
			var commentdeside=""
				if(obj.ntfCommentCheck==0)
				{
					commentdeside="<button data-role='none'  onclick='commentpostpage("+postid+");'>"+comment_socialapp+"</button>";
				}
				else
				{
					commentdeside="<button data-role='none'  onclick='commentpostpagenotallowed();'>"+comment_socialapp+"</button>";
				}
			if(obj.like==0)
			{
				bottompostpage="<li data-role='none'><button data-role='none' onclick='likeunlikepostpage("+postid+");'>"+like_socialapp+"</button>"+commentdeside+"</li>";
			}
			else
			{
				bottompostpage="<li data-role='none'><button data-role='none' class='orng-txt ' onclick='likeunlikepostpage("+postid+");'>"+unlike_socialapp+"</button>"+commentdeside+"</li>";
			}

			var html="<section class=' magentocl socialApp'>\
	               <div id='middle_page' class='comment-page social-inner-page'>\
	               <div class='socialpost-box'>\
	               <img width='74' height='54' class='f-left' alt='' src="+avatarr+">\
	               <div class='like-comment'><h4><img style='display:"+displyimagenone+"' width='16' height='16' src="+countryflag+" alt=''>"+obj.username+"</h4>\
	                    <strong style='color: black;'>"+obj.addedon+"</strong>\
	               </div>\
	               <p class='clearAll'>";
			if(obj.posttype=="video")
			{
				var videoshow="http://"+window.localStorage.getItem("reseller")+obj.video;
				html+="<video width='280' controls>\
					<source src="+videoshow+" type='video/mp4'></video>";
				html+=obj.message;
			}
			else if(obj.posttype=="image")
			{
				var imageshow="http://"+window.localStorage.getItem("reseller")+obj.image;
				html+= "<img src="+imageshow+" alt='' class='video' width='280'/>";
				html+=obj.message;
			}
			else
			{
				html+=obj.message;
			}
			html+="</p> </div><div class='domtab'><ul class='domtabs'>\
				<li><a href='#comments'>Comments</a></li>\
				<li><a href='#liking'>Likes</a></li>\
				</ul>\
				<div>\
				<ul class='play' id='comments'>";
			if(obj.comments!=null)
			{
				if(obj.comments=="")
				{
					html+=no_comments_there_socialapp;
				}
				else
				{
					for(var i=0; i<obj.comments.length; i++)
					{

						html+="<li ><strong class='Disblock'>"+obj.comments[i].message+"</strong><span class=''>"+obj.comments[i].addedon+"</span><span class='orng-txt '><strong> "+by_socialapp+" "+obj.comments[i].username+"</strong> </span></li>";
					}
				}
			}
			else
			{
				html+="+no_comments_there_socialapp+";
			}
			html+=bottompostpage+"</ul></div>\
			<div>\
			<ul class='play user' id='liking'>";
			if(obj.likes!=null)
			{
				if(obj.likes=="")
				{
					html+=no_likes_there_socialapp;
				}
				else
				{
					for(var i=0; i<obj.likes.length; i++)
					{
						html+="<li>"+obj.likes[i].addedon+" "+by_socialapp+" <strong class='orng-txt'>"+obj.likes[i].username+"</strong></li>";
					}
				}

			}
			else
			{
				html+=no_likes_there_socialapp;
			}
			html+=bottompostpage +"</ul>\
			</div>\
			</div>\
			</div>\
			</section>";
			$('#contentHolder22').css('background', '#edf0f5');
			appendHtml(html+" "+socialMenu,22,2,'food');

			domtab.init();
          }	
		},
		error: function(response, textStatus, errorThrown)
		{
			console.log("Error : "+JSON.stringify(response));
			console.log("Error : "+textStatus);
			console.log("Error : "+errorThrown.responseText);
		}
	});

}
function changefiltermystream()
{
	var e = document.getElementById("filtermystream");
	var filtervalue = e.options[e.selectedIndex].value;

	filtermystream=filtervalue;

	mystream();

}
var filtermystream="";
function mystream()
{


	if(window.localStorage.getItem("layout")=="slidemenu"){
		snapper.close();
	}
	$('.appypie-loader').show();

	var wsUrll="http://"+window.localStorage.getItem("reseller")+"/services/social-soap#mystreamJson";
	var soapRequestt ='<?xml version="1.0" encoding="utf-8"?> <soap:Envelope xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"  xmlns:xsd="http://www.w3.org/2001/XMLSchema" xmlns:soap="http://schemas.xmlsoap.org/soap/envelope/"> <soap:Body><mystreamJson xmlns=\"http://'+window.localStorage.getItem("reseller")+'/services/social-soap#mystreamJson\"><appId>'+localStorage.getItem('applicationID')+'</appId><userId>'+localStorage.getItem('userid')+'</userId><filter>'+filtermystream+'</filter><page>1</page></mystreamJson></soap:Body></soap:Envelope>';
	console.log("SoapRequest : "+ soapRequestt);
	$.ajax({
		type: "POST",
		url: wsUrll,
		contentType: "text/xml",
		dataType: "text",
		data: soapRequestt,
		success: function(data, status, req)
		{
			var strJSON = $(req.responseText).find("return").text();
			console.log("success postpage gaurav : "+strJSON);
			var obj = JSON.parse(strJSON);
			var totalpages=obj.count/obj.pagesize;
			var outputpagination="";
			var output="";
			if(totalpages>1)
			{
				outputpagination="<div class='socialpost-box'><div class='pager'><span class='pager-item title'>"+social_post_socialapp+"</span>";
				var totalpagesint = parseInt(totalpages)
				if(totalpages>totalpagesint)
				{
					totalpagesint+=1;
				}
				for(var k=1;k<=totalpagesint;k++)
				{
					if(k==1)
					{
						outputpagination+="<a class='pager-item current' href='#'>"+k+"</a>"
					}
					else
					{
						outputpagination+="<a id='"+k+"' class='pager-item' href='#' onclick='pagechangemystream(this.id);'>"+k+"</a>"
					}
				}
				outputpagination+="</div></div>";
			}
			if(obj.data!=null)
			{
				for(var i=0; i<obj.data.length; i++)
				{
					var output_flag=""
					if(obj.data[i].show_flag==1)
					{
						var countryflag="http://"+window.localStorage.getItem("reseller")+obj.data[i].from_country_flag;
						output_flag="<span class='flag Disblock'><img width='16' height='16' src="+countryflag+" alt=''></span>";
					}
					if(obj.data[i].stream_type=="like")
					{

						var avatarr="http://"+window.localStorage.getItem("reseller")+obj.data[i].from_avatar;
						output+="<div onclick='postpage("+obj.data[i].post_id+");' class='socialpost-box my-streamBox'>\
						<a href='#' >\
						<img width='74' height='54' src='"+avatarr+"' alt=''>\
						</a>\
						<div class='video_text'>\
						<a href='#'>"+output_flag+" "+obj.data[i].from_name+"</a>\
						<p>Likes Post</p>\
						<p><a href='#' >"+obj.data[i].post+"</a></p>\
						<p>"+obj.data[i].addedon+"</p>\
						</div>\
						</div>";
					}
					if(obj.data[i].stream_type=="follow")
					{
						var avatarr="http://"+window.localStorage.getItem("reseller")+obj.data[i].from_avatar;
						output+="<div class='socialpost-box my-streamBox'>\
							<a href='#'>\
							<img width='74' height='54' src='"+avatarr+"' alt=''>\
							</a>\
							<div class='video_text'>\
							<a href='#' >"+output_flag+" "+obj.data[i].from_name+"</a>\
							<p>is now following <a href='#' >"+obj.data[i].streamUser+"</a></p>\
							<p>"+obj.data[i].addedon+"</p>\
							<p><a href='#' onclick='userProfile("+obj.data[i].streamUser_id+");'>View "+obj.data[i].streamUser+"'s Profile</a></p>\
							</div>\
							</div>";
					}
					if(obj.data[i].stream_type=="comment")
					{
						var avatarr="http://"+window.localStorage.getItem("reseller")+obj.data[i].from_avatar;
						output+="<div class='socialpost-box my-streamBox' onclick='postpage("+obj.data[i].post_id+");'>\
						<a href='#' >\
						<img width='74' height='54' src='"+avatarr+"' alt=''>\
						</a>\
						<div class='video_text'>\
						<a href='#' >"+output_flag+" "+obj.data[i].from_name+"</a>\
						<p>commented on <a href='#' >"+obj.data[i].streamUser+"'s</a> post</p>\
						<p><a href='#' >"+obj.data[i].post+"</a></p>\
						<p>"+obj.data[i].addedon+"</p>\
						</div>\
						</div>";
					}
					if(obj.data[i].stream_type=="subscribe")
					{
						var avatarr="http://"+window.localStorage.getItem("reseller")+obj.data[i].from_avatar;
						output+="<div class='socialpost-box my-streamBox'>\
							<a href='#'>\
							<img width='74' height='54' src='"+avatarr+"' alt=''>\
							</a>\
							<div class='video_text'>\
							<a href='#' >"+output_flag+" "+obj.data[i].from_name+"</a>\
							<p>is subscribed to <a href='#' >"+obj.data[i].streamUser+"</a></p>\
							<p>"+obj.data[i].addedon+"</p>\
							<p><a href='#' onclick='userProfile("+obj.data[i].streamUser_id+");'>View abhi's Profile</a></p>\
							</div>\
							</div>";
					}
					if(obj.data[i].stream_type=="post")
					{
						var avatarr="http://"+window.localStorage.getItem("reseller")+obj.data[i].from_avatar;
						output+="<div class='socialpost-box my-streamBox' onclick='postpage("+obj.data[i].post_id+");'>\
						<a href='#' >\
						<img width='74' height='54' src='"+avatarr+"' alt=''>\
						</a>\
						<div class='video_text'>\
						<a href='#' >"+output_flag+" "+obj.data[i].from_name+"</a>\
						<p>have new post</p>\
						<p><a href='#' >"+obj.data[i].post+"</a></p>\
						<p>"+obj.data[i].addedon+"</p>\
						</div>\
						</div>";
					}
				}
			}
			else
			{

			}
			var html="<section class=' magentocl' style='' data-role='none'><div id='appypie-search-section' class='social-search '><input type='text' id='searchsocialtext16' data-role='none' class='filled_inp' value='' placeholder="+placeholder_search_socialapp+"><a href='#' onclick='searchsocialfunction(\"searchsocialtext16\");' class='searchBtn' data-role='none'>"+without_palceholder_search_socialapp+"</a><a href='#' class='social-uploadBtn' onclick='capturepage();'><img src='images/social-upload.png' alt=''/></a></div><div id='middle_page' class='social-inner-page'><div class='socialpost-box ' data-role='none'>  <a data-role='none'  href='#' class='filters-refresh'>"+mystream_socialapp+"</a>  <select data-role='none' class='filter-select' onchange='changefiltermystream();' id='filtermystream'><option value=''>"+all_socialapp+"</option><option value='post'>"+post_without_colon+"</option><option value='comment'>"+comments_socialapp+"</option><option value='follow'>"+follows_socialapp+"</option><option value='like'>"+likes_socialapp+"</option><option value='subscribe'>"+subscribe_socialapp+"</option></select></div>"+output+"\
	          </div>"+outputpagination+"</section>";
			$('#contentHolder21').css('background', '#edf0f5');
			setTimeout(function(){

				appendHtml(html+" "+socialMenu,21,1,'food');

				var e3 = document.getElementById("filtermystream");
				e3.value = filtermystream;
			},1000);

		},
		error: function(response, textStatus, errorThrown)
		{
			console.log("Error : "+JSON.stringify(response));
			console.log("Error : "+textStatus);
			console.log("Error : "+errorThrown.responseText);
		}
	});

}

function pagechangemystream(pageid)
{

	$('.appypie-loader').show();
	var wsUrll="http://"+window.localStorage.getItem("reseller")+"/services/social-soap#mystreamJson";
	var soapRequestt ='<?xml version="1.0" encoding="utf-8"?> <soap:Envelope xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"  xmlns:xsd="http://www.w3.org/2001/XMLSchema" xmlns:soap="http://schemas.xmlsoap.org/soap/envelope/"> <soap:Body><mystreamJson xmlns=\"http://'+window.localStorage.getItem("reseller")+'/services/social-soap#mystreamJson\"><appId>'+localStorage.getItem('applicationID')+'</appId><userId>'+localStorage.getItem('userid')+'</userId><filter>'+filtermystream+'</filter><page>'+pageid+'</page></mystreamJson></soap:Body></soap:Envelope>';
	console.log("SoapRequest : "+ soapRequestt);
	$.ajax({
		type: "POST",
		url: wsUrll,
		contentType: "text/xml",
		dataType: "text",
		data: soapRequestt,
		success: function(data, status, req)
		{
			var strJSON = $(req.responseText).find("return").text();
			console.log("success postpage gaurav : "+strJSON);
			var obj = JSON.parse(strJSON);
			var totalpages=obj.count/obj.pagesize;
			var outputpagination="";
			var output="";
			if(totalpages>1)
			{
				outputpagination="<div class='socialpost-box'><div class='pager'><span class='pager-item title'>"+social_post_socialapp+"</span>";
				var totalpagesint = parseInt(totalpages)
				if(totalpages>totalpagesint)
				{
					totalpagesint+=1;
				}
				for(var k=1;k<=totalpagesint;k++)
				{
					if(k==pageid)
					{
						outputpagination+="<a class='pager-item current' href='#'>"+k+"</a>"
					}
					else
					{
						outputpagination+="<a id='"+k+"' class='pager-item' href='#' onclick='pagechangemystream(this.id)'>"+k+"</a>"
					}
				}
				outputpagination+="</div></div>";
			}
			if(obj.data!=null)
			{
				for(var i=0; i<obj.data.length; i++)
				{
					var output_flag=""
						if(obj.data[i].show_flag==1)
						{
							var countryflag="http://"+window.localStorage.getItem("reseller")+obj.data[i].from_country_flag;
							output_flag="<span class='flag Disblock'><img width='16' height='16' src="+countryflag+" alt=''></span>";
						}
					if(obj.data[i].stream_type=="like")
					{
						var avatarr="http://"+window.localStorage.getItem("reseller")+obj.data[i].from_avatar;
						output+="<div onclick='postpage("+obj.data[i].post_id+");' class='socialpost-box my-streamBox'>\
						<a href='#' >\
						<img width='74' height='54' src='"+avatarr+"' alt=''>\
						</a>\
						<div class='video_text'>\
						<a href='#'>"+output_flag+" "+obj.data[i].from_name+"</a>\
						<p>Like Post</p>\
						<p><a href='#' >"+obj.data[i].post+"</a></p>\
						<p>"+obj.data[i].addedon+"</p>\
						</div>\
						</div>";
					}
					if(obj.data[i].stream_type=="follow")
					{
						var avatarr="http://"+window.localStorage.getItem("reseller")+obj.data[i].from_avatar;
						output+="<div class='socialpost-box my-streamBox'>\
							<a href='#'>\
							<img width='74' height='54' src='"+avatarr+"' alt=''>\
							</a>\
							<div class='video_text'>\
							<a href='#' >"+output_flag+" "+obj.data[i].from_name+"</a>\
							<p>is now following <a href='#' >"+obj.data[i].streamUser+"</a></p>\
							<p>"+obj.data[i].addedon+"</p>\
							<p><a href='#' onclick='userProfile("+obj.data[i].streamUser_id+");'>View "+obj.data[i].streamUser+"'s Profile</a></p>\
							</div>\
							</div>";
					}
					if(obj.data[i].stream_type=="comment")
					{
						var avatarr="http://"+window.localStorage.getItem("reseller")+obj.data[i].from_avatar;
						output+="<div class='socialpost-box my-streamBox' onclick='postpage("+obj.data[i].post_id+");'>\
						<a href='#' >\
						<img width='74' height='54' src='"+avatarr+"' alt=''>\
						</a>\
						<div class='video_text'>\
						<a href='#' >"+output_flag+" "+obj.data[i].from_name+"</a>\
						<p>commented on <a href='#' >"+obj.data[i].streamUser+"'s</a> post</p>\
						<p><a href='#' >"+obj.data[i].post+"</a></p>\
						<p>"+obj.data[i].addedon+"</p>\
						</div>\
						</div>";
					}
					if(obj.data[i].stream_type=="subscribe")
					{
						var avatarr="http://"+window.localStorage.getItem("reseller")+obj.data[i].from_avatar;
						output+="<div class='socialpost-box my-streamBox'>\
							<a href='#'>\
							<img width='74' height='54' src='"+avatarr+"' alt=''>\
							</a>\
							<div class='video_text'>\
							<a href='#' >"+output_flag+" "+obj.data[i].from_name+"</a>\
							<p>is subscribed to <a href='#' >"+obj.data[i].streamUser+"</a></p>\
							<p>"+obj.data[i].addedon+"</p>\
							<p><a href='#' onclick='userProfile("+obj.data[i].streamUser_id+");'>View abhi's Profile</a></p>\
							</div>\
							</div>";
					}
					if(obj.data[i].stream_type=="post")
					{
						var avatarr="http://"+window.localStorage.getItem("reseller")+obj.data[i].from_avatar;
						output+="<div class='socialpost-box my-streamBox' onclick='postpage("+obj.data[i].post_id+");'>\
						<a href='#' >\
						<img width='74' height='54' src='"+avatarr+"' alt=''>\
						</a>\
						<div class='video_text'>\
						<a href='#' >"+output_flag+" "+obj.data[i].from_name+"</a>\
						<p>have new post</p>\
						<p><a href='#' >"+obj.data[i].post+"</a></p>\
						<p>"+obj.data[i].addedon+"</p>\
						</div>\
						</div>";
					}
				}
			}
			else
			{

			}
			var html="<section class=' magentocl' style='' data-role='none'><div id='appypie-search-section' class='social-search'><input type='text' id='searchsocialtext17' data-role='none' class='filled_inp' value='' placeholder="+placeholder_search_socialapp+" ><a href='#' onclick='searchsocialfunction(\"searchsocialtext17\");' class='searchBtn' data-role='none'>'+without_palceholder_search_socialapp+'</a><a href='#' class='social-uploadBtn' onclick='capturepage();'><img src='images/social-upload.png' alt=''/></a></div><div id='middle_page'><div class='socialpost-box ' data-role='none'>  <a data-role='none'  href='#' class='filters-refresh'>"+mystream_socialapp+"</a>  <select data-role='none' class='filter-select' onchange='changefiltermystream();' id='filtermystream'><option value=''>"+all_socialapp+"</option><option value='post'>"+post_without_colon+"</option><option value='comment'>"+comments_socialapp+"</option><option value='follow'>"+follows_socialapp+"</option><option value='like'>"+likes_socialapp+"</option><option value='subscribe'>"+subscribe_socialapp+"</option></select></div>"+output+"\
		      </div>"+outputpagination+"</section>";
			$('#contentHolder22').css('background', '#edf0f5');
			setTimeout(function(){
				appendHtml(html+" "+socialMenu,22,2,'food');

				var e3 = document.getElementById("filtermystream");
				e3.value = filtermystream;

			},1000);

		},
		error: function(response, textStatus, errorThrown)
		{
			console.log("Error : "+JSON.stringify(response));
			console.log("Error : "+textStatus);
			console.log("Error : "+errorThrown.responseText);
		}
	});

}

function searchsocialfunction(idsearch)
{

	if(document.getElementById(idsearch).value!="")
	{

		$('.appypie-loader').show();
		var wsUrll="http://"+window.localStorage.getItem("reseller")+"/services/social-soap#serachUserListJson";
		var soapRequestt ='<?xml version="1.0" encoding="utf-8"?> <soap:Envelope xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"  xmlns:xsd="http://www.w3.org/2001/XMLSchema" xmlns:soap="http://schemas.xmlsoap.org/soap/envelope/"> <soap:Body><serachUserListJson xmlns=\"http://'+window.localStorage.getItem("reseller")+'/services/social-soap#serachUserListJson\"><appId>'+localStorage.getItem('applicationID')+'</appId><userId>'+localStorage.getItem('userid')+'</userId><search>'+document.getElementById(idsearch).value+'</search><page>1</page></serachUserListJson></soap:Body></soap:Envelope>';
		console.log("SoapRequest : "+ soapRequestt);
		$.ajax({
			type: "POST",
			url: wsUrll,
			contentType: "text/xml",
			dataType: "text",
			data: soapRequestt,
			success: function(data, status, req)
			{
				var strJSON = $(req.responseText).find("return").text();
				console.log("success setting gaurav : "+strJSON);
				var obj = JSON.parse(strJSON);
				var output="";
				var postoutput="";
				if(obj.user.data!=null)
				{
					for(var i=0; i<obj.user.data.length; i++)
					{
						var avatarr="http://"+window.localStorage.getItem("reseller")+obj.user.data[i].avatar
						if(obj.user.data[i].show_flag==1)
						{
							var countryflag="http://"+window.localStorage.getItem("reseller")+obj.user.data[i].country_flag;
							output+="<li onclick='userProfile("+obj.user.data[i].userId+");'><span style='float:left;'><img width='74' height='54' src='"+avatarr+"' alt='' class='f-left'></span><span class='right-content'><span> <a href='#' class=''>"+obj.user.data[i].name+"</a></span><span class='flag Disblock Disblock'><img width='16' height='16' alt='' src='"+countryflag+"'> "+obj.user.data[i].country+"</span></span><ul class='listing right'><li >"+followers_socialapp+" "+obj.user.data[i].followers+"</li><li >"+subscriber_socialapp+" "+obj.user.data[i].subscribers+"</li><li>"+post_socialapp+" "+obj.user.data[i].posts+"</li></ul></li>";


						}
						else
						{
							output+="<li onclick='userProfile("+obj.user.data[i].userId+");'><span style='float:left;'><img width='74' height='54' src='"+avatarr+"' alt='' class='f-left'></span><span class='right-content'><span> <a href='#' class=''>"+obj.user.data[i].name+"</a></span></span><ul class='listing right'><li >"+followers_socialapp+" "+obj.user.data[i].followers+"</li><li >"+subscriber_socialapp+" "+obj.user.data[i].subscribers+"</li><li>"+post_socialapp+" "+obj.user.data[i].posts+"</li></ul></li>";


						}
					}
				}
				if(obj.post.data!=null)
				{
					for(var i=0; i<obj.post.data.length; i++)
					{
						var countryflag="http://"+window.localStorage.getItem("reseller")+obj.post.data[i].country_flag;
						postoutput+="";
						if(obj.post.data[i].attached!="0")
						{
							if(obj.post.data[i].post_type=="video")
							{

								var imageshow="http://"+window.localStorage.getItem("reseller")+obj.post.data[i].image;
								if(obj.post.data[i].show_flag==1)
								{

									postoutput+="<li onclick='postpage("+obj.post.data[i].id+");'><img class='f-left' width='74' height='54' alt='' src="+imageshow+"> <span class='right-content'> <h2><a>"+obj.post.data[i].message+"</a></h2> <span>"+obj.post.data[i].addedon+" by <a class='' href='#'>"+obj.post.data[i].username+"</a></span> <span class='flag Disblock'><img width='16' height='16' src="+countryflag+" alt=''>"+obj.post.data[i].country+"</span> </span></li>";
								}
								else
								{
									postoutput+="<li onclick='postpage("+obj.post.data[i].id+");'><img class='f-left' width='74' height='54' alt='' src="+imageshow+"> <span class='right-content'> <h2><a>"+obj.post.data[i].message+"</a></h2> <span>"+obj.post.data[i].addedon+" by <a class='' href='#'>"+obj.post.data[i].username+"</a></span></span></li>";
								}
							}
							else if(obj.post.data[i].post_type=="image")
							{
								var imageshow="http://"+window.localStorage.getItem("reseller")+obj.post.data[i].image;
								if(obj.post.data[i].show_flag==1)
								{

									postoutput+="<li onclick='postpage("+obj.post.data[i].id+");'><img class='f-left' width='74' height='54' alt='' src="+imageshow+"> <span class='right-content'> <h2><a>"+obj.post.data[i].message+"</a></h2> <span>"+obj.post.data[i].addedon+" by <a class='' href='#'>"+obj.post.data[i].username+"</a></span> <span class='flag Disblock'><img width='16' height='16' src="+countryflag+" alt=''>"+obj.post.data[i].country+"</span> </span></li>";

								}
								else
								{
									postoutput+="<li onclick='postpage("+obj.post.data[i].id+");'><img class='f-left' width='74' height='54' alt='' src="+imageshow+"> <span class='right-content'> <h2><a>"+obj.post.data[i].message+"</a></h2> <span>"+obj.post.data[i].addedon+" by <a class='' href='#'>"+obj.post.data[i].username+"</a></span></span></li>";
								}
							}
						}
						else
						{

							if(obj.post.data[i].show_flag==1)
							{
								postoutput+="<li onclick='postpage("+obj.post.data[i].id+");'><span class='right-content'> <h2><a>"+obj.post.data[i].message+"</a></h2> <span>"+obj.post.data[i].addedon+" by <a class='' href='#'>"+obj.post.data[i].username+"</a></span> <span class='flag Disblock'><img width='16' height='16' src="+countryflag+" alt=''>"+obj.post.data[i].country+"</span> </span></li>";

							}
							else
							{

								postoutput+="<li onclick='postpage("+obj.post.data[i].id+");'> <span class='right-content'> <h2><a >"+obj.post.data[i].message+"</a></h2> <span>"+obj.post.data[i].addedon+" by <a class='' href='#'>"+obj.post.data[i].username+"</a></span></span></li>";

							}
						}

					}
				}
				 var html="<section class=' magentocl socialApp'> \
                     <div id='appypie-search-section' class='social-search'><input type='text' id='searchsocialtext18' data-role='none' class='filled_inp' value='' placeholder="+placeholder_search_socialapp+" ><a href='#' onclick='searchsocialfunction(\"searchsocialtext18\");' class='searchBtn' data-role='none'>"+without_palceholder_search_socialapp+"</a><a href='#' class='social-uploadBtn' onclick='capturepage();'><img src='images/social-upload.png' alt=''/></a></div>\
                     <div id='middle_page' class='search-page social-inner-page'>\
                     <div class='domtab'>\
                     <ul class='domtabs'>\
                     <li><a href='#posts'>Post</a></li>\
                     <li><a href='#users'>People</a></li>\
                     </ul>\
                     <div>\
                     <ul  class='play' id='posts'>"
                     html+=postoutput;
                     html+="</ul>\
                     </div>\
                     <div>\
                     <ul id='users' class='play people'>"
                     html+=output;
                     html+="</ul>\
                     </div>\
                     </div>\
                     </div>\
                     </section>";
                     
                     $('#contentHolder21').css('background', '#edf0f5');
				appendHtml(html+" "+socialMenu,21,1,'food');



				domtab.init();



			},
			error: function(response, textStatus, errorThrown)
			{
				console.log("Error : "+JSON.stringify(response));
				console.log("Error : "+textStatus);
				console.log("Error : "+errorThrown.responseText);
			}
		});
	}
}

function EditProfile()
{

	$('.appypie-loader').show();
	var countrylist="";
	var wsUrll="http://"+window.localStorage.getItem("reseller")+"/services/social-soap#getCountryListJson";
	var soapRequestt ='<?xml version="1.0" encoding="utf-8"?> <soap:Envelope xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"  xmlns:xsd="http://www.w3.org/2001/XMLSchema" xmlns:soap="http://schemas.xmlsoap.org/soap/envelope/"> <soap:Body><getCountryListJson xmlns=\"http://'+window.localStorage.getItem("reseller")+'/services/social-soap#getCountryListJson\"></getCountryListJson></soap:Body></soap:Envelope>';
	console.log("SoapRequest : "+ soapRequestt);
	$.ajax({
		type: "POST",
		url: wsUrll,
		contentType: "text/xml",
		dataType: "text",
		data: soapRequestt,
		success: function(data, status, req)
		{
			var strJSON2 = $(req.responseText).find("return").text();
			console.log("success country list : "+strJSON2);
			var objcountry = JSON.parse(strJSON2);
			for(var l=0; l<objcountry.length; l++)
			{

				countrylist+="<option value="+objcountry[l].id+">"+objcountry[l].country+"</option>";
			}
			var wsUrll="http://"+window.localStorage.getItem("reseller")+"/services/social-soap#editprofile";
			var soapRequestt ='<?xml version="1.0" encoding="utf-8"?> <soap:Envelope xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"  xmlns:xsd="http://www.w3.org/2001/XMLSchema" xmlns:soap="http://schemas.xmlsoap.org/soap/envelope/"> <soap:Body><editprofile xmlns=\"http://'+window.localStorage.getItem("reseller")+'/services/social-soap#editprofile\"><appId>'+localStorage.getItem('applicationID')+'</appId><userId>'+localStorage.getItem('userid')+'</userId></editprofile></soap:Body></soap:Envelope>';
			console.log("SoapRequest : "+ soapRequestt);
			$.ajax({
				type: "POST",
				url: wsUrll,
				contentType: "text/xml",
				dataType: "text",
				data: soapRequestt,
				success: function(data, status, req)
				{

					var strJSON = $(req.responseText).find("return").text();
					console.log("success Edit Profile  : "+strJSON);
					var obj = JSON.parse(strJSON);
					var avatarr="http://"+window.localStorage.getItem("reseller")+obj.avatar;
					 var html="<section class=' magentocl' style=''>\
                         <div id='middle_page' class='new-edit-profile social-inner-page'>\
                         <div class='socialpost-box'>\
                         <h1 class='heading' style='color: #000;'>Edit profile</h1>\
                         <div class='socialpost-box edit-profile'>\
                         <div class='edit-profile-pic' id='edit_page_Image' onclick='image_upload_edit_page();' style='background-image: url(http://apps.appypie.com/images/Female.png); background-attachment: scroll; background-color: rgba(0, 0, 0, 0); background-position: 50% 50%; background-repeat: no-repeat no-repeat;'></div>\
                         <div class='video_text'><h3 style='color: #000;'>Add a profile picture </h3>\
                         </div> \
                         </div>\
                         <div class='socialpost-box edit-profile'><div class='video_textt'><h3 style='color: #000;'>Settings and Information</h3>\
                         </div> </div>\
                         <ul class='login-box'>\
                          \
                         <li><label>Name:</label></li>\
                          <li><input data-role='none'; type='text' value='"+obj.name+"' id='name_edit_page'></li>\
                         <li><label>Gender</label></li>\
                         <li><select data-role='none' id='genderEditPage'><option value=''>Not selected</option><option value='m'>Male</option><option value='f'>Female</option></select></li>\
                         <li><label>Date of birth</label></li>\
                         <li class='birthday'><select data-role='none' id='birthdayEditPage' >\
                          <option value=''>Day</option>\
                          <option value='01'>1</option>\
                          <option value='02'>2</option>\
                          <option value='03'>3</option>\
                          <option value='04'>4</option>\
                          <option value='05'>5</option>\
                          <option value='06'>6</option>\
                          <option value='07'>7</option>\
                          <option value='08'>8</option>\
                          <option value='09'>9</option>\
                          <option value='10'>10</option>\
                          <option value='11'>11</option>\
                          <option value='12'>12</option>\
                          <option value='13'>13</option>\
                          <option value='14'>14</option>\
                          <option value='15'>15</option>\
                          <option value='16'>16</option>\
                          <option value='17'>17</option>\
                          <option value='18'>18</option>\
                          <option value='19'>19</option>\
                          <option value='20'>20</option>\
                          <option value='21'>21</option>\
                          <option value='22'>22</option>\
                          <option value='23'>23</option>\
                          <option value='24'>24</option>\
                          <option value='25'>25</option>\
                          <option value='26'>26</option>\
                          <option value='27'>27</option>\
                          <option value='28'>28</option>\
                          <option value='29'>29</option>\
                          <option value='30'>30</option>\
                          <option value='31'>31</option>\
                         </select>\
                         <br />\
                         <select data-role='none' id='birthmonthEditPage' >\
                          <option value=''>Month</option>\
                          <option value='01'>Jan</option>\
                          <option value='02'>Feb</option>\
                          <option value='03'>Mar</option>\
                          <option value='04'>Apr</option>\
                          <option value='05'>May</option>\
                          <option value='06'>Jun</option>\
                          <option value='07'>Jul</option>\
                          <option value='08'>Aug</option>\
                          <option value='09'>Sep</option>\
                          <option value='10'>Oct</option>\
                          <option value='11'>Nov</option>\
                          <option value='12'>Dec</option>\
                         </select> \
                         <br />\
                         <select data-role='none' id='birthyearEditPage'>\
                          <option value=''>Year</option>\
                          <option value='1950'>1950</option>\
                          <option value='1951'>1951</option>\
                          <option value='1952'>1952</option>\
                          <option value='1953'>1953</option>\
                          <option value='1954'>1954</option>\
                          <option value='1955'>1955</option>\
                          <option value='1956'>1956</option>\
                          <option value='1957'>1957</option>\
                          <option value='1958'>1958</option>\
                          <option value='1959'>1959</option>\
                          <option value='1960'>1960</option>\
                          <option value='1961'>1961</option>\
                          <option value='1962'>1962</option>\
                          <option value='1963'>1963</option>\
                          <option value='1964'>1964</option>\
                          <option value='1965'>1965</option>\
                          <option value='1966'>1966</option>\
                          <option value='1967'>1967</option>\
                          <option value='1968'>1968</option>\
                          <option value='1969'>1969</option>\
                          <option value='1970'>1970</option>\
                          <option value='1971'>1971</option>\
                          <option value='1972'>1972</option>\
                          <option value='1973'>1973</option>\
                          <option value='1974'>1974</option>\
                          <option value='1975'>1975</option>\
                          <option value='1976'>1976</option>\
                          <option value='1977'>1977</option>\
                          <option value='1978'>1978</option>\
                          <option value='1979'>1979</option>\
                          <option value='1980'>1980</option>\
                          <option value='1981'>1981</option>\
                          <option value='1982'>1982</option>\
                          <option value='1983'>1983</option>\
                          <option value='1984'>1984</option>\
                          <option value='1985'>1985</option>\
                          <option value='1986'>1986</option>\
                          <option value='1987'>1987</option>\
                          <option value='1988'>1988</option>\
                          <option value='1989'>1989</option>\
                          <option value='1990'>1990</option>\
                          <option value='1991'>1991</option>\
                          <option value='1992'>1992</option>\
                          <option value='1993'>1993</option>\
                          <option value='1994'>1994</option>\
                          <option value='1995'>1995</option>\
                          <option value='1996'>1996</option>\
                          <option value='1997'>1997</option>\
                          <option value='1998'>1998</option>\
                          <option value='1999'>1999</option>\
                          <option value='2000'>2000</option>\
                         </select>\
                         </li>\
                         <li><label>Country</label></li>\
                         <li><select data-role='none' id='selectcountryeditPage'><option value='0'>None</option>"+countrylist+"</select></li>\
                         <li><label>Phone number:</label></li>\
                         <li><input data-role='none'; type='tel'  id='phone_edit_page' value="+obj.phone+"></li>\
                         <li><label>Description</label></li>\
                         <li><textarea data-role='none'; id='description_edit_page'>"+obj.about_me+"</textarea></li>\
                         <li><button onclick='save_edit_page();'>Save</button></li>\
                         </ul>\
                         <br clear='all'>\
                         </div>\
                         <br clear='all'>\
                         </div>\
                         </section>";

					 $('#contentHolder22').css('background', '#edf0f5');
					appendHtml(html+" "+socialMenu,22,2,'food');

					var e3 = document.getElementById("genderEditPage");
					e3.value = obj.gender;
					var e4 = document.getElementById("selectcountryeditPage");
					e4.value = obj.country;
					$("#edit_page_Image").css('background', 'url('+avatarr+') no-repeat scroll center center rgba(0, 0, 0, 0)');
					var birthDateEditpage=obj.birthdate;
					var birthdatearray = birthDateEditpage.split("-");
					var dateSelect = document.getElementById("birthdayEditPage");
					dateSelect.value = birthdatearray[2];
					var MonthSelect = document.getElementById("birthmonthEditPage");
					MonthSelect.value = birthdatearray[1];
					var yearSelect = document.getElementById("birthyearEditPage");
					yearSelect.value = birthdatearray[0];



				},
				error: function(response, textStatus, errorThrown)
				{
					console.log("Error : "+JSON.stringify(response));
					console.log("Error : "+textStatus);
					console.log("Error : "+errorThrown.responseText);
				}
			});
		},
		error: function(response, textStatus, errorThrown)
		{
			console.log("Error : "+JSON.stringify(response));
			console.log("Error : "+textStatus);
			console.log("Error : "+errorThrown.responseText);
		}
	});
}

function image_upload_edit_page()
{
	navigator.notification.confirm(
			alert_msg_selectfrom_where_want_socialapp,  // message
			onConfirm_edit_page,              // callback to invoke with index of button pressed
			alert_message_socialapp,            // title
			alert_gallery_camera_socialapp
	);
}

function onConfirm_edit_page(buttonIndex)
{
	if(buttonIndex==2)
	{
		var options = {
				quality: 50,
				sourceType : Camera.PictureSourceType.PHOTOLIBRARY,
				destinationType: navigator.camera.DestinationType.FILE_URI,
		}
		navigator.camera.getPicture(win_image_lib_edit_page, fail, options);
	}
	else
	{
		Image_capture_edit_page();
	}
}

function win_image_lib_edit_page(imageURI)
{
	localStorage.edit_page_imageURI=imageURI;
	flag4save_edit_page=1;
	$("#edit_page_Image").css('background', 'url('+imageURI+') no-repeat scroll center center rgba(0, 0, 0, 0)');
}

function Image_capture_edit_page()
{
	var options = {
			limit: 1
	};
	navigator.device.capture.captureImage(captureSuccess_edit_page, captureError, options);
}


function captureSuccess_edit_page(mediaFiles)
{
    setTimeout(function(){ window.location="hidestatusbar:";},100);
    localStorage.local_imageURI = mediaFiles[0].fullPath;
    mediaFiles = goToNativeForRotation(mediaFiles[0].fullPath);
    localStorage.local_imageURI = mediaFiles;
	
	flag4save_edit_page=1;
     
	//flag4save_edit_page=1;
	//localStorage.edit_page_imageURI=mediaFiles[0].fullPath;
	//show_image_on_box();
	$("#edit_page_Image").css('background', 'url('+mediaFiles+') no-repeat scroll center center rgba(0, 0, 0, 0)');
}
var flag4save_edit_page=0;
function save_edit_page()
{
	$('.appypie-loader').show();
	var ee1 = document.getElementById("genderEditPage");
	var genderEditPage = ee1.options[ee1.selectedIndex].value;
	var ee2 = document.getElementById("birthdayEditPage");
	var birthdayEditPage = ee2.options[ee2.selectedIndex].value;
	var ee3 = document.getElementById("birthmonthEditPage");
	var birthmonthEditPage = ee3.options[ee3.selectedIndex].value;
	var ee4 = document.getElementById("birthyearEditPage");
	var birthyearEditPage = ee4.options[ee4.selectedIndex].value;
	var ee5 = document.getElementById("selectcountryeditPage");
	var selectcountryeditPage = ee5.options[ee5.selectedIndex].value;
	if(flag4save_edit_page==1)
	{
		var mediaFiles=localStorage.edit_page_imageURI;
		var fileName='profilepic.jpg';
		var fileURI;
		fileURI=mediaFiles;
		var ft = new FileTransfer();
		var options = new FileUploadOptions();
		options.fileKey="file";
		options.fileName =  fileName;
		options.mimeType="text/plain";
		var params = new Object();
		params.appId = localStorage.getItem('applicationID');
		params.userId = localStorage.getItem('userid');
		params.name=document.getElementById('name_edit_page').value;
		params.gender=genderEditPage;
		params.birthday=birthdayEditPage;
		params.birthmonth=birthmonthEditPage;
		params.birthyear=birthyearEditPage;
		params.country=selectcountryeditPage;
		params.phone=document.getElementById('phone_edit_page').value;
		params.about_me=document.getElementById('description_edit_page').value;
		options.params = params;
		ft.upload(fileURI,encodeURI("http://"+window.localStorage.getItem("reseller")+"/socialnetwork/save-profile"), successFn_image_edit_page, errorFn, options);
	}
	else
	{
		var wsUrll="http://"+window.localStorage.getItem("reseller")+"/services/social-soap#saveprofile";
		var merge_birthdate=birthyearEditPage+"-"+birthmonthEditPage+"-"+birthdayEditPage;
		var soapRequestt ='<?xml version="1.0" encoding="utf-8"?> <soap:Envelope xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"  xmlns:xsd="http://www.w3.org/2001/XMLSchema" xmlns:soap="http://schemas.xmlsoap.org/soap/envelope/"> <soap:Body><saveprofile xmlns=\"http://'+window.localStorage.getItem("reseller")+'/services/social-soap#saveprofile\"><appId>'+localStorage.getItem('applicationID')+'</appId><userId>'+localStorage.getItem('userid')+'</userId><name>'+document.getElementById('name_edit_page').value+'</name><gender>'+genderEditPage+'</gender><birthdate>'+merge_birthdate+'</birthdate><country>'+selectcountryeditPage+'</country><phone>'+document.getElementById('phone_edit_page').value+'</phone><about_me>'+document.getElementById('description_edit_page').value+'</about_me><profilepic></profilepic></saveprofile></soap:Body></soap:Envelope>';
		console.log("SoapRequest : "+ soapRequestt);
		$.ajax({
			type: "POST",
			url: wsUrll,
			contentType: "text/xml",
			dataType: "text",
			data: soapRequestt,
			success: function(data, status, req)
			{
				console.log("success  gaurav : "+req.responseText);
				var strJSON = $(req.responseText).find("return").text();
				console.log("success  gaurav : "+strJSON);
				$('.appypie-loader').hide();
				if(strJSON=='success')
				{
					var message=alert_msg_for_successfully_updated_socialapp;
					navigator.notification.alert(
							message,  // message
							alertDismissed,         // callback
							alert_message_socialapp,            // title
							social_login_fb_alert_ok_socialapp                  // buttonName
					);
					EditProfile();
				}
			},
			error: function(response, textStatus, errorThrown)
			{
				console.log("Error : "+JSON.stringify(response));
				console.log("Error : "+textStatus);
				console.log("Error : "+errorThrown.responseText);
			}
		});
	}
}

function successFn_image_edit_page(r)
{

	console.log("Response = " + r.response);
	if(r.response=='Information has been updated')
	{
		      // latestsocial();
               MYProfile();
		  var message=alert_msg_for_successfully_updated_socialapp;
		 navigator.notification.alert(
				message,  // message
				alertDismissed,         // callback
				alert_message_socialapp,            // title
				social_login_fb_alert_ok_socialapp                  // buttonName
		);
		//EditProfile();
	}
	$('.appypie-loader').hide();
}
//setting
function mysetting()
{


	if(window.localStorage.getItem("layout")=="slidemenu"){
		snapper.close();
	}

	$('.appypie-loader').show();
	var wsUrll="http://"+window.localStorage.getItem("reseller")+"/services/social-soap#userProfileSettingJson";
	var soapRequestt ='<?xml version="1.0" encoding="utf-8"?> <soap:Envelope xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"  xmlns:xsd="http://www.w3.org/2001/XMLSchema" xmlns:soap="http://schemas.xmlsoap.org/soap/envelope/"> <soap:Body><userProfileSettingJson xmlns=\"http://'+window.localStorage.getItem("reseller")+'/services/social-soap#userProfileSettingJson\"><userId>'+localStorage.getItem('userid')+'</userId></userProfileSettingJson></soap:Body></soap:Envelope>';
	console.log("SoapRequest : "+ soapRequestt);
	$.ajax({
		type: "POST",
		url: wsUrll,
		contentType: "text/xml",
		dataType: "text",
		data: soapRequestt,
		success: function(data, status, req)
		{
			var strJSON = $(req.responseText).find("return").text();
			console.log("success setting gaurav : "+strJSON);
			strJSON = JSON.parse(strJSON);
			var emailofuser=strJSON.email;
			console.log("success setting gaurav : "+strJSON.ntf_comment);

			 var html="<section data-role='none' class=' magentocl socialApp' style=''>\
                 <div id='middle_page' class='notification-setting social-inner-page'>\
                 <div class='socialpost-box '>\
                 <a href='#' class='notify' id="+emailofuser+" onclick='Account(this.id);'>\<strong>Account</strong></a>\
                 <a href='#' class='notify' onclick='emailSetting();'> <strong>Email Notification</strong></a>\
                 </div>\
                 <div class='socialpost-box '>\
                 <p>Receive comments from</p>\
                 <select id='comment_sel' onchange='getSettingMessage(this.id);' data-role='none'>\
                 <option value='0'>AnyOne</option>\
                 <option value='1'>People I'm following & People I'm subscribed</option>\
                 <option value='2'>No one</option>\
                 </select>\
                 </div></div></section>";
			 $('#contentHolder21').css('background', '#edf0f5');
			setTimeout(function(){
				appendHtml(html+" "+socialMenu,21,1,'food');

				var e2 = document.getElementById("comment_sel");
				if(strJSON.ntf_comment)
				{
					e2.value = strJSON.ntf_comment;
				}
				else
				{
					e2.value =0;
				}
			},1000);
  },
		error: function(response, textStatus, errorThrown)
		{
			console.log("Error : "+JSON.stringify(response));
			console.log("Error : "+textStatus);
			console.log("Error : "+errorThrown.responseText);
		}
	});


}



function getSettingMessage(type)
{
	var valueid='';
	var fieldname=''
		if(type=='mentions_sel')
		{
			var e0 = document.getElementById("mentions_sel");
			valueid=e0.options[e0.selectedIndex].value;
			fieldname='ntf_mentions';
		}
		else if(type=='message_sel')
		{
			var e0 = document.getElementById("message_sel");
			valueid=e0.options[e0.selectedIndex].value;
			fieldname='ntf_message';
		}
		else if(type=='comment_sel')
		{
			var e0 = document.getElementById("comment_sel");
			valueid=e0.options[e0.selectedIndex].value;
			fieldname='ntf_comment';
		}
	$('.appypie-loader').show();
	var wsUrll="http://"+window.localStorage.getItem("reseller")+"/services/social-soap#messageSettingJson";
	var soapRequestt ='<?xml version="1.0" encoding="utf-8"?> <soap:Envelope xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"  xmlns:xsd="http://www.w3.org/2001/XMLSchema" xmlns:soap="http://schemas.xmlsoap.org/soap/envelope/"> <soap:Body><messageSettingJson xmlns=\"http://'+window.localStorage.getItem("reseller")+'/services/social-soap#messageSettingJson\"><appId>'+localStorage.getItem('applicationID')+'</appId><userId>'+localStorage.getItem('userid')+'</userId><fieldname>'+fieldname+'</fieldname><value>'+valueid+'</value></messageSettingJson></soap:Body></soap:Envelope>';
	console.log("SoapRequest : "+ soapRequestt);
	$.ajax({
		type: "POST",
		url: wsUrll,
		contentType: "text/xml",
		dataType: "text",
		data: soapRequestt,
		success: function(data, status, req)
		{
			var strJSON = $(req.responseText).find("return").text();
			console.log("success setting dropdown gaurav : "+strJSON);
			$('.appypie-loader').hide();

		},
		error: function(response, textStatus, errorThrown)
		{
			console.log("Error : "+JSON.stringify(response));
			console.log("Error : "+textStatus);
			console.log("Error : "+errorThrown.responseText);
		}
	});
}
function Account(email)
{

	$('.appypie-loader').show();
	var wsUrll="http://"+window.localStorage.getItem("reseller")+"/services/social-soap#userProfileSettingJson";
	var soapRequestt ='<?xml version="1.0" encoding="utf-8"?> <soap:Envelope xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"  xmlns:xsd="http://www.w3.org/2001/XMLSchema" xmlns:soap="http://schemas.xmlsoap.org/soap/envelope/"> <soap:Body><userProfileSettingJson xmlns=\"http://'+window.localStorage.getItem("reseller")+'/services/social-soap#userProfileSettingJson\"><userId>'+localStorage.getItem('userid')+'</userId></userProfileSettingJson></soap:Body></soap:Envelope>';
	console.log("SoapRequest : "+ soapRequestt);
	$.ajax({
		type: "POST",
		url: wsUrll,
		contentType: "text/xml",
		dataType: "text",
		data: soapRequestt,
		success: function(data, status, req)
		{

			var strJSON = $(req.responseText).find("return").text();
			console.log("success setting gaurav : "+strJSON);
			strJSON = JSON.parse(strJSON);
			var html="<section class=' magentocl' style=''>\
	               <div id='middle_page' class='account-page social-inner-page' data-role='none'>\
	               <div class='socialpost-box' data-role='none'>\
	               <ul class='login-box' data-role='none'>\
	               <li data-role='none'><label>Username</label>\
	               <span class='check-availability' data-role='none' id='Usernamevalidation' style='visibility:hidden;'>Username already exist!</span></li>\
	               <li><input data-role='none' type='text' value='"+strJSON.username+"' id='accoutUsername'></li>\
	               <li data-role='none'>\
	               <label>Email Address</label>\
	               <span class='check-availability' data-role='none' id='Emailvalidation' style='visibility:hidden;'  >Email-id already exist!</span>\
	               </li>\
	               <li><input data-role='none' type='text' value="+strJSON.email+" id='accoutEmail'></li>\
	               <li data-role='none'><button class='socailBtn-save' onclick='SaveAccount();'>Save</button>\
	               <button class='change-pass f-left' onclick='ChangePass();'>Change Password</button>\
	               </li>\
	               </ul>\
	               </div>\
	               <br clear='all'>\
	               </div></div>\
	               </section>";

			setTimeout(function(){
				$('#contentHolder22').css('background', '#edf0f5');
				appendHtml(html+" "+socialMenu,22,2,'food');

				document.getElementById("useremailsocial").value=email;
			},1000);
		},
		error: function(response, textStatus, errorThrown)
		{
			console.log("Error : "+JSON.stringify(response));
			console.log("Error : "+textStatus);
			console.log("Error : "+errorThrown.responseText);
		}
	});
}

function SaveAccount()
{

	var Acccount_Email=document.getElementById("accoutEmail").value;
	var Acccount_Username=document.getElementById("accoutUsername").value;
	var atpos = Acccount_Email.indexOf("@");
	var dotpos = Acccount_Email.lastIndexOf(".");

	if(Acccount_Username=="")
	{
		navigator.notification.alert(
				alert_msg_usrname_cant_blank_socialapp,
				alertDismissed,
				social_login_fb_alert_socialapp,
				social_login_fb_alert_ok_socialapp
		);
	}
	else if(Acccount_Email=="")
	{
		navigator.notification.alert(
				alert_msg_email_cant_blank_socialapp,
				alertDismissed,
				social_login_fb_alert_socialapp,
				social_login_fb_alert_ok_socialapp
		);
	}

	else if (atpos< 1 || dotpos<atpos+2 || dotpos+2>=Acccount_Email.length) {
		document.getElementById("Emailvalidation").innerHTML="+inner_msg_not_valid_email_address_socialapp+";
		document.getElementById("Usernamevalidation").style.visibility="hidden";
		document.getElementById("Emailvalidation").style.visibility="visible";

	}
	else
	{
		$('.appypie-loader').show();
		var wsUrll="http://"+window.localStorage.getItem("reseller")+"/services/social-soap#accountSettingJson";
		var soapRequestt ='<?xml version="1.0" encoding="utf-8"?> <soap:Envelope xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"  xmlns:xsd="http://www.w3.org/2001/XMLSchema" xmlns:soap="http://schemas.xmlsoap.org/soap/envelope/"> <soap:Body><accountSettingJson xmlns=\"http://'+window.localStorage.getItem("reseller")+'/services/social-soap#accountSettingJson\"><userId>'+localStorage.getItem('userid')+'</userId><username>'+Acccount_Username+'</username><email>'+Acccount_Email+'</email></accountSettingJson></soap:Body></soap:Envelope>';
		console.log("SoapRequest : "+ soapRequestt);
		$.ajax({
			type: "POST",
			url: wsUrll,
			contentType: "text/xml",
			dataType: "text",
			data: soapRequestt,
			success: function(data, status, req)
			{
				var strJSON = $(req.responseText).find("return").text();
				console.log("success setting dropdown gaurav : "+strJSON);
				$('.appypie-loader').hide();
				if(strJSON=='Username already exist')
				{

					document.getElementById("Usernamevalidation").style.visibility="visible";
					document.getElementById("Emailvalidation").style.visibility="hidden";
				}
				else if(strJSON=='Email already exist')
				{

					document.getElementById("Emailvalidation").innerHTML="Email-id already exist!";
					document.getElementById("Usernamevalidation").style.visibility="hidden";
					document.getElementById("Emailvalidation").style.visibility="visible";

				}
				else
				{
					document.getElementById("Usernamevalidation").style.visibility="hidden";
					document.getElementById("Emailvalidation").style.visibility="hidden";
				}


			},
			error: function(response, textStatus, errorThrown)
			{
				console.log("Error : "+JSON.stringify(response));
				console.log("Error : "+textStatus);
				console.log("Error : "+errorThrown.responseText);
			}
		});
	}

}

function alertDismissed()
{
	$('.appypie-loader').hide();
}
function ChangePass()
{

	 var html="<section class=' magentocl' style=''> \
         <div id='middle_page' class='change-password social-inner-page'> \
         <div class='socialpost-box'> \
         <ul class='login-box'> \
         <li> \
         <label>Current Password</label></li> \
         <li><input data-role='none' id='accoutCurrentPassword' type='password' value=''></li> \
         <li> \
         <label>New Password</label></li> \
         <li><input data-role='none' id='accoutNewPassword' type='password' value=''></li> \
         <li><label>Confirm Password</label></li> \
         <li><input data-role='none' id='accoutConfirmPassword' type='password' value=''></li> \
         <li data-role='none'><button class='socailBtn-save' onclick='ChangePassSave();'>Save</button>\
         </ul> \
         <br clear='all'> \
         </div></div> \
         </section> ";
	 $('#contentHolder23').css('background', '#edf0f5');
	appendHtml(html+" "+socialMenu,23,3,'food');

}

function ChangePassSave()
{
	var accoutCurrentPassword=document.getElementById("accoutCurrentPassword").value;
	var accoutNewPassword=document.getElementById("accoutNewPassword").value;
	var accoutConfirmPassword=document.getElementById("accoutConfirmPassword").value;

	if(accoutCurrentPassword=="")
	{
		navigator.notification.alert(
				alert_msg_enter_current_password_socialapp,
				alertDismissed,
				social_login_fb_alert_socialapp,
				social_login_fb_alert_ok_socialapp
		);
	}
	else if(accoutNewPassword=="")
	{
		navigator.notification.alert(
				alert_msg_enter_new_pass_socialapp,
				alertDismissed,
				social_login_fb_alert_socialapp,
				social_login_fb_alert_ok_socialapp
		);
	}
	else if(accoutConfirmPassword=="")
	{
		navigator.notification.alert(
				alert_msg_enter_confirm_password_socialapp,
				alertDismissed,
				social_login_fb_alert_socialapp,
				social_login_fb_alert_ok_socialapp
		);
	}
	else if(accoutNewPassword!=accoutConfirmPassword)
	{
		navigator.notification.alert(
				alert_msg_password_doesnt_match_socialapp,
				alertDismissed,
				social_login_fb_alert_socialapp,
                social_login_fb_alert_ok_socialapp
		);
	}
	else
	{
		$('.appypie-loader').show();
		var wsUrll="http://"+window.localStorage.getItem("reseller")+"/services/social-soap#changePassJson";
		var soapRequestt ='<?xml version="1.0" encoding="utf-8"?> <soap:Envelope xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"  xmlns:xsd="http://www.w3.org/2001/XMLSchema" xmlns:soap="http://schemas.xmlsoap.org/soap/envelope/"> <soap:Body><changePassJson xmlns=\"http://'+window.localStorage.getItem("reseller")+'/services/social-soap#changePassJson\"><appId>'+localStorage.getItem('applicationID')+'</appId><userId>'+localStorage.getItem('userid')+'</userId><cpass>'+accoutCurrentPassword+'</cpass><newpass>'+accoutNewPassword+'</newpass><repass>'+accoutConfirmPassword+'</repass></changePassJson></soap:Body></soap:Envelope>';
		console.log("SoapRequest : "+ soapRequestt);
		$.ajax({
			type: "POST",
			url: wsUrll,
			contentType: "text/xml",
			dataType: "text",
			data: soapRequestt,
			success: function(data, status, req)
			{
				var strJSON = $(req.responseText).find("return").text();
				console.log("success setting change password gaurav : "+strJSON);
				navigator.notification.alert(
						strJSON,
						alertDismissed,
						social_login_fb_alert_socialapp,
                        social_login_fb_alert_ok_socialapp
				);
				document.getElementById("accoutCurrentPassword").value="";
				document.getElementById("accoutNewPassword").value="";
				document.getElementById("accoutConfirmPassword").value="";
				$('.appypie-loader').hide();
			},
			error: function(response, textStatus, errorThrown)
			{
				console.log("Error : "+JSON.stringify(response));
				console.log("Error : "+textStatus);
				console.log("Error : "+errorThrown.responseText);
			}
		});
	}
}
function emailSetting()
{

	$('.appypie-loader').show();
	var wsUrll="http://"+window.localStorage.getItem("reseller")+"/services/social-soap#userProfileSettingJson";
	var soapRequestt ='<?xml version="1.0" encoding="utf-8"?> <soap:Envelope xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"  xmlns:xsd="http://www.w3.org/2001/XMLSchema" xmlns:soap="http://schemas.xmlsoap.org/soap/envelope/"> <soap:Body><userProfileSettingJson xmlns=\"http://'+window.localStorage.getItem("reseller")+'/services/social-soap#userProfileSettingJson\"><userId>'+localStorage.getItem('userid')+'</userId></userProfileSettingJson></soap:Body></soap:Envelope>';
	console.log("SoapRequest : "+ soapRequestt);
	$.ajax({
		type: "POST",
		url: wsUrll,
		contentType: "text/xml",
		dataType: "text",
		data: soapRequestt,
		success: function(data, status, req)
		{
			var strJSON = $(req.responseText).find("return").text();
			console.log("success setting gaurav : "+strJSON);
			strJSON = JSON.parse(strJSON);

			 var html="<section class=' magentocl socialApp' style='' data-role='none'>\
                 <div id='middle_page' class='notification-email social-inner-page'>\
                 <div class='socialpost-box letest' id='checkboxes'>\
                 \
                 <div class='email-wrapper'><div class='video_text'>\
                 <strong>Send me an email for these events:</strong>\
                 </div>\
                 </div>\
                 <div class='email-wrapper'><div class='f-left' style='margin-right:4px; margin-top:2px'>\
                 <input type='checkbox' data-role='none' id='checkbox1social'>\
                 </div><div class='video_text'>\
                 <strong> When someone follows me</strong>\
                 </div>\
                 </div>\
                 \
                 <div class='email-wrapper'><div class='f-left' style='margin-right:4px; margin-top:2px'>\
                 <input type='checkbox' data-role='none' id='checkbox2social'>\
                 </div><div class='video_text'>\
                 <strong>When someone subscribes to me</strong>\
                 </div> \
                 </div>\
                 \
                 <div class='email-wrapper'><div class='f-left' style='margin-right:4px; margin-top:2px'>\
                 <input type='checkbox' data-role='none' id='checkbox3social'>\
                 </div><div class='video_text'>\
                 <strong> When someone comments on my post</strong>\
                 </div> \
                 </div>\
                 \
                 <div class='email-wrapper'><div class='f-left' style='margin-right:4px; margin-top:2px'>\
                 <input type='checkbox' data-role='none' id='checkbox5social'>\
                 </div><div class='video_text'>\
                 <strong>When someone likes my post</strong>\
                 </div> \
                 </div>\
                 \
                 <div class='email-wrapper' data-role='none'>\
                 <button data-role='none' onclick='getSettingEmail();'>SAVE</button></div>\
                 </div>\
                 </div>\
                 </section>";
			 $('#contentHolder22').css('background', '#edf0f5');
			setTimeout(function(){

				appendHtml(html+" "+socialMenu,22,2,'food');


				if(strJSON.mail_them_when_follow=='1')
				{
					document.getElementById("checkbox1social").checked=true;
				}
				else
				{
					document.getElementById("checkbox1social").checked=false;
				}
				if(strJSON.mail_them_when_subscribe=='1')
				{
					document.getElementById("checkbox2social").checked=true;
				}
				else
				{
					document.getElementById("checkbox2social").checked=false;
				}
				if(strJSON.mail_them_when_comment_on_posts=='1')
				{
					document.getElementById("checkbox3social").checked=true;
				}
				else
				{
					document.getElementById("checkbox3social").checked=false;
				}
				if(strJSON.mail_them_when_like_posts=='1')
				{
					document.getElementById("checkbox5social").checked=true;
				}
				else
				{
					document.getElementById("checkbox5social").checked=false;
				}
			},1000);


		},
		error: function(response, textStatus, errorThrown)
		{
			console.log("Error : "+JSON.stringify(response));
			console.log("Error : "+textStatus);
			console.log("Error : "+errorThrown.responseText);
		}
	});

}

function getSettingEmail()
{
	var follow="0",subscribe="0",comment="0",like="0";
	var selected = new Array();

	$('#checkboxes input:checked').each(function() {
		if($(this).attr('id')=='checkbox1social')
		{
			follow="1";
		}

		else if($(this).attr('id')=='checkbox2social')
		{
			subscribe="1";
		}
		else if($(this).attr('id')=='checkbox3social')
		{
			comment="1";
		}
		else if($(this).attr('id')=='checkbox5social')
		{
			like="1";
		}
	});
	$('.appypie-loader').show();
	var wsUrll="http://"+window.localStorage.getItem("reseller")+"/services/social-soap#emailSettingJson";
	var soapRequestt ='<?xml version="1.0" encoding="utf-8"?> <soap:Envelope xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"  xmlns:xsd="http://www.w3.org/2001/XMLSchema" xmlns:soap="http://schemas.xmlsoap.org/soap/envelope/"> <soap:Body><emailSettingJson xmlns=\"http://'+window.localStorage.getItem("reseller")+'/services/social-soap#emailSettingJson\"><appId>'+localStorage.getItem('applicationID')+'</appId><userId>'+localStorage.getItem('userid')+'</userId><follow>'+follow+'</follow><subscribe>'+subscribe+'</subscribe><posts>'+comment+'</posts><mentions>1</mentions><likePosts>'+like+'</likePosts><update>1</update></emailSettingJson></soap:Body></soap:Envelope>';
	console.log("SoapRequest : "+ soapRequestt);
	$.ajax({
		type: "POST",
		url: wsUrll,
		contentType: "text/xml",
		dataType: "text",
		data: soapRequestt,
		success: function(data, status, req)
		{
			var strJSON = $(req.responseText).find("return").text();
			console.log("success setting gaurav : "+ strJSON);
			// emailSetting();
			$('.appypie-loader').hide();
		},
		error: function(response, textStatus, errorThrown)
		{
			console.log("Error : "+JSON.stringify(response));
			console.log("Error : "+textStatus);
			console.log("Error : "+errorThrown.responseText);
		}
	});
}
//upload

function capturepage()
{

	localStorage.uploadtype='';
	var html="<section class=' magentocl socialApp' style='' data-role='none'><div id='middle_page' class='uplaodPage'><div class='socialpost-box '><video id = 'video_add' controls src='' style='display:none;'></video><img src='' style='display:none;' id = 'image_add' width='260' height='161' alt=''/><ul class='login-box'><li><textarea  id='captionnn' data-role='none'></textarea></li></ul><button class='gren' onclick='upload();' data-role='none'>Save</button><button onclick='image_upload();' data-role='none'>Image Upload</button><button onclick='confirm_box();' data-role='none'>"+vedio_upload_socialapp+"</button></div></div></section>";
	$('#contentHolder21').css('background', '#edf0f5');
	appendHtml(html+" "+socialMenu,21,1,'food');


}

function confirm_box()
{

	navigator.notification.confirm(
			alert_msg_selectfrom_where_want_socialapp,  // message
			onConfirm,              // callback to invoke with index of button pressed
			alert_message_socialapp,            // title
			alert_gallery_camera_socialapp
	);
}

function onConfirm(buttonIndex)
{
	if(buttonIndex==2)
	{
		var options = {
				quality: 100,
				destinationType: navigator.camera.DestinationType.FILE_URI,
				sourceType: navigator.camera.PictureSourceType.PHOTOLIBRARY,
				mediaType: navigator.camera.MediaType.VIDEO
		}
		navigator.camera.getPicture(win_video_lib, fail, options);
	}
	else
	{
		video_capture();
	}
}
function win_video_lib(videoURI)
{
	localStorage.local_mediaFiles=videoURI;
	show_video_on_box();
}

function video_capture()
{
 var options = {duration:10,correctOrientation:true};
 navigator.device.capture.captureVideo(captureSuccess, captureError, options);
}

function captureSuccess(mediaFiles)
{
	localStorage.local_mediaFiles=mediaFiles[0].fullPath;
	show_video_on_box();
}
function captureError()
{

}

function show_video_on_box()
{
	localStorage.uploadtype='video';
	var mediaFiles=localStorage.local_mediaFiles;
	 document.getElementById("image_add_wallPost_social").style.display = 'none';
	    document.getElementById("video_add_wallpost_social").style.display = 'block';
	    document.getElementById('photo_video_selection_social').style.display = 'none';
	    document.getElementById('video_add_wallPost_show_social').src = mediaFiles;
}

function image_upload()
{


	navigator.notification.confirm(
			alert_msg_selectfrom_where_want_socialapp,  // message
			onConfirm2_social,              // callback to invoke with index of button pressed
			alert_message_socialapp,            // title
			alert_gallery_camera_socialapp
	);
}

function onConfirm2_social(buttonIndex)
{

	if(buttonIndex==2)
	{
		var options = {
				quality: 50,
				sourceType : Camera.PictureSourceType.PHOTOLIBRARY,
				destinationType: navigator.camera.DestinationType.FILE_URI,
		}
		navigator.camera.getPicture(win_image_lib_social, fail, options);
	}
	else
	{
		Image_capture_social();
	}
}
function win_image_lib_social(imageURI)
{
	localStorage.local_imageURI=imageURI;

	show_image_on_box_social();
}

function Image_capture_social()
{
	var options = {
			limit: 1
	};
	navigator.device.capture.captureImage(captureSuccess2_social, captureError, options);
}

function captureSuccess2_social(mediaFiles)
{
    setTimeout(function(){ window.location="hidestatusbar:";},100);
    localStorage.local_imageURI = mediaFiles[0].fullPath;
    mediaFiles = goToNativeForRotation(mediaFiles[0].fullPath);
    localStorage.local_imageURI = mediaFiles;
    show_image_on_box_social();
	//localStorage.local_imageURI=mediaFiles[0].fullPath;
	//show_image_on_box_social();
}

function show_image_on_box_social()
{
	localStorage.uploadtype='image';
	var mediaFiles=localStorage.local_imageURI;
	
	 document.getElementById("video_add_wallpost_social").style.display = 'none';
	    document.getElementById("image_add_wallPost_social").style.display = 'block';
	    document.getElementById('photo_video_selection_social').style.display = 'none';
	    document.getElementById('image_add_wallPost_show_social').src = mediaFiles;
	
	/*document.getElementById("video_add").style.display='none';
	document.getElementById("image_add").style.display='block';
	document.getElementById('image_add').src=mediaFiles;*/
}
function fail()
{

}
function upload()
{
	$('.appypie-loader').show();
	if(localStorage.getItem('uploadtype')=='video')
	{
		var captionnn=document.getElementById('captionnnWallPost_video_social').value;
		captionnn = captionnn.trim();
		if(captionnn!="")
		{

			//document.getElementById("upload_btn").href = "javascript:void(0)";
			var mediaFiles=localStorage.local_mediaFiles;
			var fileName='23456.mp4';
			var fileURI=mediaFiles;
			var ft = new FileTransfer();
			var options = new FileUploadOptions();
			options.fileKey="file";
			options.fileName =  fileName;
			options.mimeType="text/plain";
			var params = new Object();
			params.appId = localStorage.getItem('applicationID');
			params.userId = localStorage.getItem('userid');
			params.caption=document.getElementById('captionnnWallPost_video_social').value;
			params.type='video';
			options.params = params;
			ft.upload(fileURI,encodeURI("http://"+window.localStorage.getItem("reseller")+"/socialnetwork/upload-video"), successFn_social, errorFn, options);
		}
		else
		{
			$('.appypie-loader').hide();
			var message=alert_msg_addtext_toupload_video_socialapp;
			navigator.notification.alert(
					message,  // message
					alertDismissed,         // callback
					alert_message_socialapp,            // title
					social_login_fb_alert_ok_socialapp                  // buttonName
			);
		}

	}

	else if(localStorage.getItem('uploadtype')=='image')
	{
		var captionnn=document.getElementById('captionnnWallPost_image_social').value;
		captionnn = captionnn.trim();
		if(captionnn!="")
		{
			var mediaFiles=localStorage.local_imageURI;
			var fileName='23456.jpg';
			var fileURI;
			fileURI=mediaFiles;
			var ft = new FileTransfer();
			var options = new FileUploadOptions();
			options.fileKey="file";
			options.fileName =  fileName;
			options.mimeType="text/plain";
			var params = new Object();
			params.appId = localStorage.getItem('applicationID');
			params.userId = localStorage.getItem('userid');
			params.caption=document.getElementById('captionnnWallPost_image_social').value;
			params.type='image';
			options.params = params;
			ft.upload(fileURI,encodeURI("http://"+window.localStorage.getItem("reseller")+"/socialnetwork/upload-video"), successFn_social_image, errorFn, options);
		}
		else
		{
			$('.appypie-loader').hide();
			var message=alert_msg_addtext_toupload_image_socialapp;
			navigator.notification.alert(
					message,  // message
					alertDismissed,         // callback
					alert_message_socialapp,            // title
					social_login_fb_alert_ok_socialapp                  // buttonName
			);
		}
	}

	else
	{
		var captionnn=document.getElementById('captionnnWallPost_social').value;
		captionnn = captionnn.trim();
		if(captionnn!="")
		{

			var textUploaddata={'appId':localStorage.getItem('applicationID'),'userId':'134','message':document.getElementById("captionnnWallPost_social").value,'attached':'0'};
			console.log("success textupload gaurav4 : "+JSON.stringify(textUploaddata));
			var wsUrll="http://"+window.localStorage.getItem("reseller")+"/services/social-soap#savePostJson";
			var soapRequestt ='<?xml version="1.0" encoding="utf-8"?> <soap:Envelope xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"  xmlns:xsd="http://www.w3.org/2001/XMLSchema" xmlns:soap="http://schemas.xmlsoap.org/soap/envelope/"> <soap:Body><savePostJson xmlns=\"http://'+window.localStorage.getItem("reseller")+'/services/social-soap#savePostJson\"><appId>'+localStorage.getItem('applicationID')+'</appId><userId>'+localStorage.getItem('userid')+'</userId><message><![CDATA['+document.getElementById("captionnnWallPost_social").value+']]></message></savePostJson></soap:Body></soap:Envelope>';
			console.log("SoapRequest : "+ soapRequestt);
			$.ajax({
				type: "POST",
				url: wsUrll,
				contentType: "text/xml",
				dataType: "text",
				data: soapRequestt,
				success: function(data, status, req)
				{
					var strJSON = $(req.responseText).find("return").text();
					console.log("success textupload gaurav : "+strJSON);
					$('.appypie-loader').hide();
					indexsocial();
				},
				error: function(response, textStatus, errorThrown)
				{
					console.log("Error : "+JSON.stringify(response));
					console.log("Error : "+textStatus);
					console.log("Error : "+errorThrown.responseText);
				}
			});
		}
		else
		{
			var message=alert_msg_addtext_toupload_socialapp;
			navigator.notification.alert(
					message,  // message
					alertDismissed,         // callback
					alert_message_socialapp,            // title
					social_login_fb_alert_ok_socialapp                  // buttonName
			);
			$('.appypie-loader').hide();
		}
	}
}

function successFn_social(r)
{
	console.log("Response = " + r.response);
	$('.appypie-loader').hide();
	if(r.response=='success')
	{
		var message=alert_msg_successfully_uploaded_socialapp;
		navigator.notification.alert(
				message,  // message
				alertDismissed,         // callback
				alert_message_socialapp,            // title
				social_login_fb_alert_ok_socialapp                  // buttonName
		);
		indexsocial();
		// window.location.href='main.html';
	}
	else{
		var message=alert_msg_some_error_occured_socialapp;
		navigator.notification.alert(
				message,  // message
				alertDismissed,         // callback
				social_login_fb_alert_socialapp,            // title
				social_login_fb_alert_ok_socialapp                  // buttonName
		);
		//window.location.href='main.html';
	}
}

function successFn_social_image(r)
{
	$('.appypie-loader').hide();
	console.log("Response = " + r.response);
	if(r.response=='success')
	{
		var message=alert_msg_successfully_uploaded_socialapp;
		navigator.notification.alert(
				message,  // message
				alertDismissed,         // callback
				alert_message_socialapp,            // title
				social_login_fb_alert_ok_socialapp                  // buttonName
		);
		indexsocial();
	}
}
function errorFn(error) {
	$('.appypie-loader').hide();
	console.log("upload error source " + error.source);
	console.log("upload error target " + error.target);
}
function deletepost_social(Staticpostid)
{
              
        if (confirm("Are you sure you wish to delete this post ? ") == true)
        {
            deletepost_social_delete(Staticpostid)
        }
        else {
              
             }
             
}
               
               
function deletepost_social_delete(Staticpostid)
{
               $('.appypie-loader').show();
               var postidd = Staticpostid.split("$$$");
               
               postid=postidd[1];
               var wsUrll="http://"+localStorage.getItem("reseller")+"/services/social-soap#deletePostJson";
               var soapRequestt ='<?xml version="1.0" encoding="utf-8"?> <soap:Envelope xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"  xmlns:xsd="http://www.w3.org/2001/XMLSchema" xmlns:soap="http://schemas.xmlsoap.org/soap/envelope/"> <soap:Body><deletePostJson xmlns=\"http://'+localStorage.getItem("reseller")+'/services/social-soap#deletePostJson\"><appId>' + localStorage.getItem('applicationID') + '</appId><postId>' + postid + '</postId></deletePostJson></soap:Body></soap:Envelope>';
               console.log("SoapRequest delete : " + soapRequestt);

               
               $.ajax({
                      type: "POST",
                      url: wsUrll,
                      contentType: "text/xml",
                      dataType: "text",
                      data: soapRequestt,
                      success: function(data, status, req) {
                      var strJSON = $(req.responseText).find("return").text();
                      console.log("success textupload gaurav : " + strJSON);
                      $('.appypie-loader').hide();
                      var el = document.getElementById(postid);
                      el.parentNode.removeChild(el);
                      },
                      error: function(response, textStatus, errorThrown) {
                      $('.appypie-loader').hide();
                      // document.getElementById(Staticpostid).innerHTML="<img src='images/sociel-reported.png'> Report Abuse";
                      console.log("Error : " + JSON.stringify(response));
                      console.log("Error : " + textStatus);
                      console.log("Error : " + errorThrown.responseText);
                      }
                      });
}
function reportpost_social(Staticpostid)
{
   $('.appypie-loader').show();
   var postidd = Staticpostid.split("$$$");
               
   postid=postidd[1];
   var wsUrll="http://"+localStorage.getItem("reseller")+"/services/social-soap#report";
   var soapRequestt ='<?xml version="1.0" encoding="utf-8"?> <soap:Envelope xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"  xmlns:xsd="http://www.w3.org/2001/XMLSchema" xmlns:soap="http://schemas.xmlsoap.org/soap/envelope/"> <soap:Body><report xmlns=\"http://'+localStorage.getItem("reseller")+'/services/social-soap#report\"><userId>'+localStorage.getItem('userid')+'</userId><appId>' + localStorage.getItem('applicationID') + '</appId><reportId>' + postid + '</reportId><reportType>post</reportType></report></soap:Body></soap:Envelope>';
   console.log("SoapRequest : " + soapRequestt);
   $.ajax({
          type: "POST",
          url: wsUrll,
          contentType: "text/xml",
          dataType: "text",
          data: soapRequestt,
          success: function(data, status, req) {
                      var strJSON = $(req.responseText).find("return").text();
                      console.log("success textupload gaurav : " + strJSON);
                      $('.appypie-loader').hide();
                      document.getElementById(Staticpostid).innerHTML="<img src='images/sociel-reported.png'> Report Abuse";
      },
      error: function(response, textStatus, errorThrown) {
      $('.appypie-loader').hide();
         // document.getElementById(Staticpostid).innerHTML="<img src='images/sociel-reported.png'> Report Abuse";
      console.log("Error : " + JSON.stringify(response));
      console.log("Error : " + textStatus);
      console.log("Error : " + errorThrown.responseText);
      }
      });
}

function reportpost_social(Staticpostid)
{
	$('.appypie-loader').show();
	var postidd = Staticpostid.split("$$$");

	postid=postidd[1];
	var wsUrll="http://"+window.localStorage.getItem("reseller")+"/services/social-soap#report";
	var soapRequestt ='<?xml version="1.0" encoding="utf-8"?> <soap:Envelope xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"  xmlns:xsd="http://www.w3.org/2001/XMLSchema" xmlns:soap="http://schemas.xmlsoap.org/soap/envelope/"> <soap:Body><report xmlns=\"http://'+window.localStorage.getItem("reseller")+'/services/social-soap#report\"><userId>'+localStorage.getItem('userid')+'</userId><appId>' + localStorage.getItem('applicationID') + '</appId><reportId>' + postid + '</reportId><reportType>post</reportType></report></soap:Body></soap:Envelope>';
	console.log("SoapRequest : " + soapRequestt);
	$.ajax({
		type: "POST",
		url: wsUrll,
		contentType: "text/xml",
		dataType: "text",
		data: soapRequestt,
		success: function(data, status, req) {
			var strJSON = $(req.responseText).find("return").text();
			console.log("success textupload gaurav : " + strJSON);
			$('.appypie-loader').hide();
			document.getElementById(Staticpostid).innerHTML="<img src='images/sociel-reported.png'> Report Abuse";
		},
		error: function(response, textStatus, errorThrown) {
			$('.appypie-loader').hide();
			$('.appypie-loader').hide();
			// document.getElementById(Staticpostid).innerHTML="<img src='images/sociel-reported.png'> Report Abuse";
			console.log("Error : " + JSON.stringify(response));
			console.log("Error : " + textStatus);
			console.log("Error : " + errorThrown.responseText);
		}
	});
}

function reportcomment_social(Staticcommentid)
{
	$('.appypie-loader').show();
	var commentidd = Staticcommentid.split("$$$");
	var commentid = commentidd[1];
	var wsUrll = "http://"+window.localStorage.getItem("reseller")+"/services/social-soap#report";
	var soapRequestt = '<?xml version="1.0" encoding="utf-8"?> <soap:Envelope xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"  xmlns:xsd="http://www.w3.org/2001/XMLSchema" xmlns:soap="http://schemas.xmlsoap.org/soap/envelope/"> <soap:Body><report xmlns=\"http://'+window.localStorage.getItem("reseller")+'/services/social-soap#report\"><userId>'+localStorage.getItem('userid')+'</userId><appId>' + localStorage.getItem('applicationID') + '</appId><reportId>' + commentid + '</reportId><reportType>comment</reportType></report></soap:Body></soap:Envelope>';
	console.log("SoapRequest : " + soapRequestt);
	$.ajax({
		type: "POST",
		url: wsUrll,
		contentType: "text/xml",
		dataType: "text",
		data: soapRequestt,
		success: function(data, status, req) {
			var strJSON = $(req.responseText).find("return").text();
			console.log("success textupload gaurav : " + strJSON);
			$('.appypie-loader').hide();
			document.getElementById(Staticcommentid).innerHTML="<img src='images/sociel-reported.png'> Report Abuse";
		},
		error: function(response, textStatus, errorThrown) {
			$('.appypie-loader').hide();
			//document.getElementById(Staticcommentid).innerHTML="<img src='images/sociel-reported.png'> Report Abuse";
			console.log("Error : " + JSON.stringify(response));
			console.log("Error : " + textStatus);
			console.log("Error : " + errorThrown.responseText);
		}
	});
}

function select_for_post_upload_social() {

    $("#updatestatus_social").addClass("sociel-active")
    $("#addphotovideo_social").removeClass();
    document.getElementById('photo_video_selection_social').style.display = 'block';
    document.getElementById("textUploadWall_social").style.display = 'none';
    document.getElementById("video_add_wallpost_social").style.display = 'none';
    document.getElementById("image_add_wallPost_social").style.display = 'none';

}
           
function select_for_status_update_social() {

localStorage.uploadtype = 'text';
$("#addphotovideo_social").addClass("sociel-active")
$("#updatestatus_social").removeClass();
document.getElementById("textUploadWall_social").style.display = 'block';
document.getElementById('photo_video_selection_social').style.display = 'none';
document.getElementById("video_add_wallpost_social").style.display = 'none';
document.getElementById("image_add_wallPost_social").style.display = 'none';

}
function select_for_img_post_upload_social() {
navigator.notification.confirm(
                              '+alert_msg_selectfrom_where_want_socialapp+', // message
                              onConfirm_img_for_post_upload_social, // callback to invoke with index of button pressed
                              '+alert_message_socialapp+', // title
                              '+alert_gallery_camera_cancel_socialapp+'
                              );
}

function onConfirm_img_for_post_upload_social(buttonIndex) {
if (buttonIndex == 2) {
var options = {
quality: 50,
sourceType: Camera.PictureSourceType.PHOTOLIBRARY,
destinationType: navigator.camera.DestinationType.FILE_URI,
}
navigator.camera.getPicture(win_lib_image_post_upload_social, fail_wallpost_social, options);
} else if (buttonIndex == 1) {
Image_capture_post_upload_social();
}
else
{

}
}
           
function win_lib_image_post_upload_social(imageURI) {
//setTimeout(function(){ window.location="hidestatusbar:";},100);
localStorage.local_imageURI_wallPost_post_social = imageURI;
show_image_on_box_wallpost_post_social();
}
           
function Image_capture_post_upload_social() {
var options = {
limit: 1
};
navigator.device.capture.captureImage(captureSuccess_img_post_upload_social, captureError_wallpost_social, options);
}
           
function captureSuccess_img_post_upload_social(mediaFiles) {
setTimeout(function(){ window.location="hidestatusbar:";},100);
localStorage.local_imageURI_wallPost_post_social = mediaFiles[0].fullPath;
show_image_on_box_wallpost_post_social();
}
           
function show_image_on_box_wallpost_post_social() {
	//localStorage.uploadtype='image';
    localStorage.uploadtypeWallPost_social = 'image';
    var mediaFiles = localStorage.local_imageURI_wallPost_post_social;
    document.getElementById("video_add_wallpost_social").style.display = 'none';
    document.getElementById("image_add_wallPost_social").style.display = 'block';
    document.getElementById('photo_video_selection_social').style.display = 'none';
    document.getElementById('image_add_wallPost_show_social').src = mediaFiles;
}

function select_for_video_post_upload_social() {
navigator.notification.confirm(
                              alert_msg_selectfrom_where_want_socialapp, // message
                              onConfirm_video_for_post_upload_social, // callback to invoke with index of button pressed
                              alert_message_socialapp, // title
                              alert_gallery_camera_cancel_socialapp
                              );
}

function onConfirm_video_for_post_upload_social(buttonIndex) {
if (buttonIndex == 2) {

var options = {
quality: 100,
destinationType: navigator.camera.DestinationType.FILE_URI,
sourceType: navigator.camera.PictureSourceType.PHOTOLIBRARY,
mediaType: navigator.camera.MediaType.VIDEO
}
navigator.camera.getPicture(win_lib_video_post_upload_social, fail_wallpost_social, options);
} else if (buttonIndex == 1){
video_capture_post_upload_social();
}
else{

}
}


